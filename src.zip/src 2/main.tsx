import { createRoot } from "react-dom/client";
import "./index.css";
import "swiper/swiper-bundle.css";
import "flatpickr/dist/flatpickr.css";
import App from "./App.tsx";
import { AppWrapper } from "./components/common/PageMeta.tsx";
import { ThemeProvider } from "./context/ThemeContext.tsx";
import { Provider } from "react-redux";
import store from "./redux/store.ts"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { StrictMode } from "react";
import  { AppKitProvider } from "./lib/Web3Modal.tsx";
// import { LoaderOverlay } from "./components/shared/loaderSpinner.tsx";

const queryClient = new QueryClient();

createRoot(document.getElementById("root")!).render(
  <Provider store={store}>
     <StrictMode>
     <AppKitProvider>
      <ThemeProvider>
      <AppWrapper>
      <QueryClientProvider client={queryClient}>
      {/* <LoaderOverlay/> */}
      <App />
      
      </QueryClientProvider>
      </AppWrapper>
    </ThemeProvider>
    </AppKitProvider>
      </StrictMode>
      </Provider>
    

);
