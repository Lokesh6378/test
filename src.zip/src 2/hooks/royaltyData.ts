import { useQuery } from "@tanstack/react-query";
import { getNftHolders, getNftQualification, getRoyaltyTransaction, getRoyaltyUsers, getRoyaltyUsersId, getRoyaltyUsersTagTimer } from "../apis/programs/royalty/main";


export const useRoyaltyUserTag = () =>
    useQuery({
        queryKey: ["royaltyUserTag"],
        queryFn: getRoyaltyUsers,
        staleTime: 2 * 60 * 1000,
    });

export const useRoyaltyUserId = () =>
    useQuery({
        queryKey: ["royaltyUserId"],
        queryFn: getRoyaltyUsersId,
        enabled: false,
        staleTime: 2 * 60 * 1000,
    });



export const useRoyaltyData = (address: string) =>
    useQuery({
        queryKey: ["royalty", address],
        queryFn: () => getRoyaltyUsersTagTimer(address),
        enabled: !!address, 
        staleTime: 2 * 60 * 1000,// only fetch if address exists
    });


export const RoyaltyTransaction = (address: string) =>
    useQuery({
        queryKey: ["royaltyTransactions", address],
        queryFn: () => getRoyaltyTransaction(address),
        enabled: !!address, // only fetch if address exists
        staleTime: 2 * 60 * 1000, // 5 minutes
    });



export const getNftQualificationUser = (address: string) =>
    useQuery({
        queryKey: ["getNftQualificationData", address],
        queryFn: () => getNftQualification(address),
        enabled: !!address, // only fetch if address exists
        staleTime: 2 * 60 * 1000,
    });


export const getNftHoldersQualification = () =>
    useQuery({
        queryKey: ["getNftHolders"],
        queryFn: () => getNftHolders(),
        staleTime: 2 * 60 * 1000,
    });






