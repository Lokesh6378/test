import { useMemo } from "react";
import { BigNumber, ethers } from "ethers";

const LEVELS = [
  { level: 1, percent: 50 },
  { level: 2, percent: 10 },
  { level: 3, percent: 15 },
  { level: 4, percent: 11 },
  { level: 5, percent: 10 },
  { level: 6, percent: 4 },
];

export const useMpsLevelEarning = (
  transactions: any[],
  address?: string
) => {
  return useMemo(() => {
    if (!address || !Array.isArray(transactions)) {
      return { total: 0, list: [] };
    }

    const myAddr = address.toLowerCase();

    const earnings = transactions.reduce((acc: any[], trx: any) => {
      const uplines = trx?.decoded?.uplinesData || [];
      if (!uplines.length) return acc;

      const amount = trx?.decoded?.amount?._hex
        ? Number(
            ethers.utils.formatEther(
              BigNumber.from(trx.decoded.amount._hex)
            )
          )
        : 0;

      const pool = amount * 0.5;

      uplines.forEach((upline: string, index: number) => {
        if (upline?.toLowerCase() !== myAddr) return;

        const cfg = LEVELS[index];
        if (!cfg) return;

        acc.push((pool * cfg.percent) / 100);
      });

      return acc;
    }, []);

    const total = earnings.reduce((s, v) => s + v, 0);

    return { total, list: earnings };
  }, [transactions, address]);
};
