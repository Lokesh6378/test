import axios, { AxiosError } from "axios";

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
});

apiClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    let message = "Something went wrong";

    if (error.response) {
      const status = error.response.status;

      if (status === 400) message = "Invalid request";
      else if (status === 401) message = "Wallet authorization failed";
      else if (status === 500) message = "Server error";
    } else if (error.request) {
      message = "Network error. Please check internet.";
    }

    return Promise.reject(new Error(message));
  }
);

export default apiClient;