import { useQuery } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import { getMusdLevel } from "../apis/mining/main";

export function useMusdData() {
    const currentUser = useSelector((state: any) => state.global.currentUser);

    const {
        data: MusdData,
        isError: isMusdError,
        error: MusdError,
    } = useQuery({
        queryKey: ["getMusdLevelEarning", currentUser?.address],
        queryFn: () => getMusdLevel(currentUser?.address),
        enabled: !!currentUser?.address,
        refetchOnWindowFocus: false,
        staleTime: 1000 * 60 * 2,

    });

    
    return {
        MusdData,
        isMusdError,
        MusdError,
    };
}