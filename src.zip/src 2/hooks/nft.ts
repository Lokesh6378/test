import { useQuery } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import { getLevelNFT } from "../apis/gamingnft/main";

export function useNFTData() {
    const currentUser = useSelector((state: any) => state.global.currentUser);
    const oldAddress = currentUser?.old_address || currentUser?.address
    const {
        data: NFTdData,
        isError: isMusdError,
        error: MusdError,
    } = useQuery({
        queryKey: ["getNFTLevelEarning", oldAddress],
        queryFn: () => getLevelNFT(oldAddress),
        enabled: !!oldAddress,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,

    });

    
    return {
        NFTdData,
        isMusdError,
        MusdError,
    };
}