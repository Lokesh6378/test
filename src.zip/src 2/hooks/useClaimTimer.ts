import { useEffect, useState } from "react";

export const useClaimTimer = (key: string) => {
  const [remainingTime, setRemainingTime] = useState(0);

  const startTimer = (minutes = 2) => {
    const endTime =
      Date.now() + minutes * 60 * 1000;

    localStorage.setItem(
      key,
      endTime.toString()
    );

    setRemainingTime(minutes * 60);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      const saved =
        localStorage.getItem(key);

      if (!saved) {
        setRemainingTime(0);
        return;
      }

      const diff = Math.floor(
        (Number(saved) - Date.now()) / 1000
      );

      if (diff <= 0) {
        localStorage.removeItem(key);
        window.location.reload();
        setRemainingTime(0);
      } else {
        setRemainingTime(diff);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [key]);

  return {
    remainingTime,
    startTimer,
  };
};