   
        import { useState, useCallback } from "react";

        export const useModal = (initialState: boolean = false) => {
          const [isOpen, setIsOpen] = useState(initialState);
          const [isOpenSecend, setIsOpenSecend] = useState(initialState);
        
          const openModal = useCallback(() => setIsOpen(true), []);
          const closeModal = () => {
            setIsOpen(false);      
          };
          const toggleModal = useCallback(() => setIsOpen((prev) => !prev), []);
        
        
          const openModalSecend = useCallback(() => setIsOpenSecend(true), []);
          const closeModalSecend = () => {
            setIsOpenSecend(false);
          };
          const toggleModalSecend = useCallback(() => setIsOpenSecend((prev) => !prev), []);
        
        
          const closeBothModals = () => {
            setIsOpenSecend(false);
            setIsOpen(false);
          };
        
        
          return { isOpen, openModal, closeModal, toggleModal,isOpenSecend,openModalSecend,closeModalSecend,toggleModalSecend,closeBothModals };
        };
        