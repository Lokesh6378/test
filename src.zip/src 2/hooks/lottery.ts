import { useQuery } from "@tanstack/react-query";
import { getLotteryAllData } from "../apis/dashboard/main";
import { useSelector } from "react-redux";

export function useLotteryData() {
    const currentUser = useSelector((state: any) => state.global.currentUser);
    const oldAddress = currentUser?.old_address || currentUser?.address
    // const oldUniqueId = currentUser?.old_unique_id ||  currentUser?.id ;

    const {
        data: lotteryData,
        isError: isLotteryError,
        error: lotteryError,
    } = useQuery({
        queryKey: ["lotteryData", oldAddress],
        queryFn: () => getLotteryAllData(oldAddress),
        enabled: !!oldAddress,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,

    });
    return {
        lotteryData,
        isLotteryError,
        lotteryError,
    };
}