import { useQuery } from "@tanstack/react-query";

import { getTotalActiveBillionaire, getTotalActiveMillionaire, getTotalInactiveBillionaire, getTotalInactiveMillionaire } from "../apis/dashboard/main";
export const getTotalInactiveBillionaireUser =(address: any, page: any) =>

        useQuery({
            queryKey: ["inactiveUserBillionaire", address, page],
            queryFn: () => getTotalInactiveBillionaire(address, page),
            enabled: !!address,
        })

export const getTotalActiveBillionaireUser =(address: any, page: any) =>
    
        useQuery({
            queryKey: ["activeUserBillionaire", address, page],
            queryFn: () => getTotalActiveBillionaire(address, page),
            enabled: !!address,
        })

export const getTotalActiveMillionaireUser = (address: any, page: any) =>
    useQuery({
        queryKey: ["activeUserMillionaire", address, page],
        queryFn: () => getTotalActiveMillionaire(address, page),
        enabled: !!address
    })

export const getTotalInactiveMillionaireUser  =(address: any, page: any) =>

    useQuery({
        queryKey: ["inactiveUserMillionaire", address, page],
        queryFn: () => getTotalInactiveMillionaire(address, page),
        enabled: !!address
    })


