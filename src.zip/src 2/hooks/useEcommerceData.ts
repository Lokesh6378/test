import { useQuery } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import axios from "axios";
import {
    getUserDetails,
} from "../apis/auth/auth";
import {
    getDirectPartners,
    getTotalProfit,
    getTotalTeam,
} from "../apis/dashboard/main";



export function useEcommerceData() {
    const currentUser = useSelector((state: any) => state.global.currentUser);

    const oldAddress =
    currentUser?.old_address ||
    currentUser?.address ||
    null;
  
  // const oldUniqueId =
  //   currentUser?.old_unique_id ||
  //   currentUser?.uniqueId ||
  //   null;
//     const safeOldAddress =
//     currentUser?.old_address && currentUser?.old_address.trim() !== "" ? currentUser?.old_address : "";
  
//   const safeOldUniqueId =
//   currentUser?.old_unique_id && currentUser?.old_unique_id.trim() !== "" ? currentUser?.old_unique_id : """";

// const safeOldAddress =
//   currentUser?.old_address && currentUser.old_address.trim() !== ""
//     ? currentUser.old_address
//     : '""'; // 👈 FORCE ""

// const safeOldUniqueId =
//   currentUser?.old_unique_id && currentUser.old_unique_id.trim() !== ""
//     ? currentUser.old_unique_id
//     : '""'; // 👈 FORCE ""

  
   
    // const isReady = Boolean(oldAddress && oldUniqueId);

    
    
    const {
        data: userDetails,
        isError: isUserError,
        error: userError,
    } = useQuery({
        queryKey: ['userDetails', currentUser?.address, currentUser?.id],
        queryFn: () => getUserDetails(currentUser?.address, currentUser?.id),
        enabled: !!currentUser?.address || !!currentUser?.id,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });

    // const {
    //     data: miningData,
    //     isError: isMiningError,
    //     error: miningError,
    // } = useQuery({
    //     queryKey: ['miningData', currentUser?.address,currentUser?.id,oldAddress, oldUniqueId],
    //     queryFn: async () =>
    //         axios
    //             .get(`https://mining.meta-pro.in/api/get/coin/data?userAddress=${currentUser?.address}&uniqueId=${currentUser?.id}&oldAddress=${oldAddress}&oldUniqueId=${oldUniqueId}`)
    //             .then((res) => res.data),
    //       enabled: !!currentUser?.address|| !!currentUser?.id||!!oldAddress || !!oldUniqueId,
    //     refetchOnWindowFocus: false,
    //     refetchOnMount: false,
    //     staleTime: 1000 * 60 * 2,
    // })


    const {
        data: miningData,
        isError: isMiningError,
        error: miningError,
      } = useQuery({
        queryKey: [
          "miningData",
          currentUser?.address ?? "",
          currentUser?.id ?? "",

        ],
      
        queryFn: async () => {
          const res = await axios.get(
            "https://mining.meta-pro.in/api/get/coin/data",
            {
              headers: {
                "ngrok-skip-browser-warning": "true",
              },
              params: {
                userAddress: currentUser?.address ?? "",
                uniqueId: currentUser?.id ?? "",
              },
            }
          );
          return res.data;
        },
        enabled: !!(
          currentUser?.address &&
          currentUser?.id
        ),
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
      });
      
      

    const {
        data: totalTeamData,
        isError: isTotalTeamError,
        error: TotalTeamError,
    } = useQuery({
        queryKey: ['totalTeamData', currentUser?.address, currentUser?.id],
        queryFn: () => getTotalTeam(currentUser?.address, currentUser?.id),
        enabled: !!currentUser?.address||!!currentUser?.id,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,

    });

    const {
        data: totalTeamUpData,
        isError: isTotalTeamUpError,
        error: TotalTeamUpError,
    } = useQuery({
        queryKey: ['totalTeamUpDatasss', currentUser?.address],
        queryFn: () =>
            axios
                .get(`https://handler.meta-pro.space/api/get-total-team/24=hr?address=${currentUser?.address}`)
                .then((res) => res.data),
        enabled: !!currentUser?.address,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });



    const {
        data: totalProfits,
        isError: isTotalProfitError,
        error: TotalProfitError,
    } = useQuery({
        queryKey: ["totalProfit", currentUser?.address],
        queryFn: () => getTotalProfit(currentUser?.address),
        enabled: !!oldAddress,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });

    const {
        data: directPartners,
        isError: isDirectPartnerError,
        error: DirectPartnerError,
    } = useQuery({
        queryKey: ["direct_partners", currentUser?.address],
        queryFn: () => getDirectPartners(currentUser?.address),
        enabled: !!currentUser?.address,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });


    return {
        userDetails,
        miningData,
        totalTeamData,
        totalTeamUpData,
        totalProfits,
        directPartners,
        errors: {
            userError: isUserError ? userError?.message : null,
            miningCoinError: isMiningError ? miningError?.message : null,
            TotalTeamError: isTotalTeamError ? TotalTeamError?.message : null,
            TotalTeamUpError: isTotalTeamUpError ? TotalTeamUpError?.message : null,
            TotalProfitError: isTotalProfitError ? TotalProfitError?.message : null,
            DirectPartnerError: isDirectPartnerError ? DirectPartnerError?.message : null,
        },

    };
}
