import { useQuery } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import { getStackingLevelEarning } from "../apis/AiRobat/main";
import { getStatingDetails } from "../apis/dashboard/main";

export function usestaking() {
    const currentUser = useSelector((state: any) => state.global.currentUser);
    const oldAddress = currentUser?.old_address || currentUser?.address
    // const oldUniqueId = currentUser?.old_unique_id ||  currentUser?.id ;
    const {
        data: statkingEarning,
        isError: isStatkingEarningError,
        error: StatkingEarningError,

    } = useQuery({
        queryKey: ["statkingEarning", oldAddress],
        queryFn: () => getStackingLevelEarning(oldAddress),
        enabled: !!oldAddress,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });


    const {
        data: statkingDetails,
        isError: isStatkingDetailsError,
        error: StatkingDetailsError,
        isLoading: StatkingDetailsLoading,
    } = useQuery({
        queryKey: ["statkingDetails", oldAddress],
        queryFn: () => getStatingDetails(oldAddress),
        enabled: !!oldAddress,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });
    return {
        statkingEarning,
        isStatkingEarningError,
        StatkingEarningError,
        statkingDetails,
        isStatkingDetailsError,
        StatkingDetailsError,
       loaderss: StatkingDetailsLoading

    };
}