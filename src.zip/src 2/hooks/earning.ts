import { useQuery } from "@tanstack/react-query";
import { getBillionaireEarnings, getBillionaireLevelEarnings, getEarningData, getMillionaireLevelEarnings, getTrillionaireEarnings, getTrillionaireLevelEarnings } from "../apis/dashboard/main";
import { useSelector } from "react-redux";

export const useEarning = () => {
    const currentUser = useSelector((state: any) => state.global.currentUser);
    // const oldAddress = currentUser?.old_address || currentUser?.address
    // const oldUniqueId = currentUser?.old_unique_id ||  currentUser?.id ;
    const {
        data: millionaire_Earnings,
        isError: isMillionaireEarningError,
        error: MillionaireEarningError,
        isLoading: MillionaireEarningLoading,
    } = useQuery({
        queryKey: ["millionaire_Earning", currentUser?.address],
        queryFn: () => getEarningData(currentUser?.address),
        enabled: !!currentUser?.address,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });

    const {
        data: millionaire_level,
        isError: isMillionaireLevelError,
        error: MillionaireLevelError,
        isLoading: MillionaireLevelLoading,
    } = useQuery({
        queryKey: ["millionaire_level", currentUser?.address],
        queryFn: () => getMillionaireLevelEarnings(currentUser?.address),
        enabled: !!currentUser?.address,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });

    const {
        data: billionaire_Earnings,
        isError: isBillionaireEarningError,
        error: BillionaireEarningError,
        isLoading: BillionaireEarningLoading,
    } = useQuery({
        queryKey: ["billionaire_Earning", currentUser?.address],
        queryFn: () => getBillionaireEarnings(currentUser?.address),
        enabled: !!currentUser?.address,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });

    const {
        data: billionaire_level,
        isError: isBillionaireLevelError,
        error: BillionaireLevelError,
        isLoading: BillionaireLevelLoading,
    } = useQuery({
        queryKey: ["billionaire_level", currentUser?.address],
        queryFn: () => getBillionaireLevelEarnings(currentUser?.address),
        enabled: !!currentUser?.address,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });

    const {
        data: trillionaire_Earnings,
        isError: istrillionaireEarningError,
        error: TrillionaireEarningError,
        isLoading: TrillionaireEarningLoading,
    } = useQuery({
        queryKey: ["Triillionaire_Earning", currentUser?.address,currentUser?.id],
        queryFn: () => getTrillionaireEarnings(currentUser?.address,currentUser?.id),
        enabled: !!currentUser?.address,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });

    const {
        data: trillionaire_level,
        isError: isTrillionaireLevelError,
        error: TrillionaireLevelError,
        isLoading: TrillionaireLevelLoading,
    } = useQuery({
        queryKey: ["Trillionaire_level", currentUser?.address],
        queryFn: () => getTrillionaireLevelEarnings(currentUser?.address,currentUser?.id),
        enabled: !!currentUser?.address,
        refetchOnWindowFocus: false,
        refetchOnMount: false,
        staleTime: 1000 * 60 * 2,
    });

    return {
        millionaire_Earnings,
        millionaire_level,
        billionaire_Earnings,
        billionaire_level,
        trillionaire_Earnings,
        trillionaire_level,
        errorss: {

            MillionaireEarningError: isMillionaireEarningError ? MillionaireEarningError?.message : null,
            MillionaireLevelError: isMillionaireLevelError ? MillionaireLevelError?.message : null,
            BillionaireEarningError: isBillionaireEarningError ? BillionaireEarningError?.message : null,
            BillionaireLevelError: isBillionaireLevelError ? BillionaireLevelError?.message : null,
            TrillionaireLevelError:isTrillionaireLevelError?TrillionaireLevelError.message:null,
            TrillionaireEarningError: istrillionaireEarningError ? TrillionaireEarningError?.message : null,
              
        },
        loader: {
            MillionaireEarningLoader: MillionaireEarningLoading,
            MillionaireLevelLoader: MillionaireLevelLoading,
            BillionaireEarningLoader: BillionaireEarningLoading,
            BillionaireLevelLoader: BillionaireLevelLoading,

            TrillionaireEarningLoader: TrillionaireEarningLoading,
            TrillionaireLevelLoader: TrillionaireLevelLoading,

        }
    };

}
