import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import SignIn from "./pages/AuthPages/SignIn";
import SignUp from "./pages/AuthPages/SignUp";
import NotFound from "./pages/OtherPage/NotFound";
import UserProfiles from "./pages/UserProfiles";
import Videos from "./pages/UiElements/Videos";
import Images from "./pages/UiElements/Images";
import Alerts from "./pages/UiElements/Alerts";
import Badges from "./pages/UiElements/Badges";
import Avatars from "./pages/UiElements/Avatars";
import Buttons from "./pages/UiElements/Buttons";
import LineChart from "./pages/Charts/LineChart";
import BarChart from "./pages/Charts/BarChart";
import BasicTables from "./pages/Tables/BasicTables";
import FormElements from "./pages/Forms/FormElements";
import Blank from "./pages/Blank";
import AppLayout from "./layout/AppLayout";
import { ScrollToTop } from "./components/common/ScrollToTop";
import Home from "./pages/Dashboard/Home";
import "react-toastify/dist/ReactToastify.css";
import ProgramsList from "./pages/Programs/ProgramsList";

import ProPowerMatrix from "./pages/Programs/pro-power-matrix/page";
import CurrentLine from "./pages/Programs/CurrentLine";
import ProPowerGlobal from "./pages/Programs/pro-power-global/page";
import X_ProPowerGlobal from "./pages/Programs/x-power-global/page";
import X_ProPowerMatrix from "./pages/Programs/x-power-matrix/page";
import { Toaster } from "./components/ui/toast/toaster";
import Lottery from "./pages/Lottery/Lottery";
import ProPowerPage from "./components/ui/ProgramsModal/x-power-global";
import XMatrixSlotPageData from "./components/ui/ProgramsModal/x-power-martix";
import ProPowerPageMatrix from "./components/ui/ProgramsModal/pro-power-matrx";
import ProPowerPageGlobal from "./components/ui/ProgramsModal/pro-power-global";
import RoyaltyPage from "./pages/Royalty/royalty";
// import GamingNFTsCard from "./pages/GamingNFT/page";
import LevelPage from "./pages/LevelTeam/page";
import TransactionsTabs from "./pages/Transactions/transactionsTabs";
import LevelDetailsPage from "./pages/LevelData/page";
import UserProfileModal from "./components/ui/Edit/page";
// import CoinMiningPage from "./pages/CoinMining/page";
import LevelPageAiRobat from "./pages/TeamAiRobat/page";
import TransactionsAiRobat from "./pages/AIRobat/Transactions/Transactions";
// import AiRobotRoyaltyTag from "./pages/AIRobat/RoyaltyStacking/royalty";
import MaintanesmodeStacking from "./components/ui/maintanesmode/maintanesmodeStacking";
import CommingSoonPage from "./components/ui/commingsoon.tsx/page";
import InvestorTabs from './pages/Programs/investor/page'
import AiRobatInvestor from "./pages/AIRobat/investor";
import SkakingTAb from "./pages/AIRobat/stakingtab";
import MiningTAb from "./pages/CoinMining/cointab";
import DonationTAb from "./pages/Donation/donationtab";
import SkakingTAbRoyalty from "./pages/AIRobat/RoyaltyStacking/royaltyStakingTab";
import OfferTAb from "./pages/AIRobat/offerTab";
import GamingTAb from "./pages/Games/gamingtab";
import { Games1Page } from "./pages/Games1/page";
import GamingNftTAb from "./pages/GamingNFT/gamingTab";
import MpstabTAb from "./pages/Mpstoken/mpstokentab";
import ErrorBoundary from "./components/common/ErrorBoundary";
import AppLoader from "./components/system/AppLoader";
import { Suspense } from "react";
import X2ProPowerMatrix from "./pages/Programs/Trillionaire/2x-power-matrix/page";
import Tr2XPowerGlobalData from "./components/ui/ProgramsModal/2_x_power_global";
import Tr2XPowerMatrixdata from "./components/ui/ProgramsModal/2_x_power_martix";
  // import DonationPage from "./pages/Donation/page";



export default function App() {
  console.log("✅ APP RENDERED");
  return (

    <>
      <ErrorBoundary>
        <Router>
          <ScrollToTop />
          <Suspense fallback={<AppLoader />}>
          <Routes>
          <Route path="/" element={<SignIn />} />
          <Route path="/register" element={<SignUp />} />
            <Route element={<AppLayout />}>
              <Route index path="/dashboard" element={<Home />} />
              <Route path="/programs" element={<ProgramsList />} />
              <Route path="/programs/pro-power-matrix" element={<ProPowerMatrix />} />
              <Route path="/programs/pro-power-global" element={<ProPowerGlobal />} />
              <Route path="/programs/x-power-global" element={<X_ProPowerGlobal />} />
              <Route path="/programs/x-power-matrix" element={<X_ProPowerMatrix />} />            
              <Route path="/programs/pro-power-matrix/CurrentLine" element={<CurrentLine />} />         
              <Route path="/programs/x-power-global/:pkg" element={<ProPowerPage />} />
              <Route path="/programs/x-power-matrix/:pkg" element={<XMatrixSlotPageData />} />
              <Route path="/programs/pro-power-matrix/:pkg" element={<ProPowerPageMatrix />} />
              <Route path="/programs/pro-power-global/:pkg" element={<ProPowerPageGlobal  />} />
              <Route path="/transactions" element={<TransactionsTabs  />} />
              <Route path="/level" element={<LevelDetailsPage  />} />
              <Route path="/edit" element={<UserProfileModal />} />
              <Route path="/programs/2x-power" element={<X2ProPowerMatrix />} />
              <Route path="/programs/2x-pro-power-martix/:pkg" element={<Tr2XPowerMatrixdata />} />
              <Route path="/programs/2x-pro-power-global/:pkg" element={<Tr2XPowerGlobalData />} />
            
              {/* <Route path="/programs/x-power-matrix" element={<X_ProPowerMatrix />} />    */}
              {/*  */}
              {/*Ai robat */}
              <Route path="/pkgs" element={<SkakingTAb />} />
              {/* <Route path="/withdraw" element={<WithdrawClaimAiRobot />} /> */}
              {/* <Route path="/earning" element={<EarningsAiRobat />} /> */}
              <Route path="/level-robat" element={<LevelPageAiRobat  />} />  
              <Route path="/stacking-transaction" element={<TransactionsAiRobat  />} />
              <Route path="/stacking-royalty" element={<SkakingTAbRoyalty/>} />
              <Route path="/maintanesmode" element={<MaintanesmodeStacking  />} />   
              <Route path="/comming" element={<CommingSoonPage  />} /> 
              <Route path="/specialOffer" element={<OfferTAb/>} />
              {/* <Route path="/wallet" element={<WalletPage />} /> */}
              
              <Route path="/lottery" element={<Lottery />} />
              <Route path="/blastaroo" element={<GamingTAb />} /> 
              <Route path="/games" element={<Games1Page />} /> 
              <Route path="/donation" element={<DonationTAb />} />
              <Route path="/profile" element={<UserProfiles />} />
              <Route path="/blank" element={<Blank />} />
              <Route path="/royalty" element={<RoyaltyPage />} />
              <Route path="/coinMining" element={<MiningTAb />} />
              <Route path="earners-program" element={<InvestorTabs />} />
              <Route path="/earners-AiRobat" element={<AiRobatInvestor />} />
              <Route path="/level-team" element={<LevelPage />} />
              <Route path="/gaming-nft" element={<GamingNftTAb />} />
       
              <Route path="/form-elements" element={<FormElements />} />
              <Route path="/basic-tables" element={<BasicTables />} />
              <Route path="/mpsToken" element={<MpstabTAb />} />
              <Route path="/alerts" element={<Alerts />} />
              <Route path="/avatars" element={<Avatars />} />   
              <Route path="/badge" element={<Badges />} />
              <Route path="/buttons" element={<Buttons />} />
              <Route path="/images" element={<Images />} />
              <Route path="/videos" element={<Videos />} />
      
              <Route path="/line-chart" element={<LineChart />} />
              <Route path="/bar-chart" element={<BarChart />} />

              </Route>
              <Route path="*" element={<NotFound />} />

            </Routes>
          </Suspense>
          <Toaster />

        </Router>
      </ErrorBoundary>
    </>
  );
}
