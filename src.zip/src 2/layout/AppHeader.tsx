import { useLocation, useNavigate } from "react-router";
import { useSidebar } from "../context/SidebarContext";
import NotificationDropdown from "../components/header/NotificationDropdown";


import WalletPage from "../pages/wallet/page";
import { useEffect, useRef, useState } from "react";

const AppHeader: React.FC = () => {
  const { isMobileOpen, toggleSidebar, toggleMobileSidebar } = useSidebar();
  const [isWalletOpen, setWalletOpen] = useState(false);
  const [isNotificationOpen, setNotificationOpen] = useState(false);

  const walletRef = useRef<HTMLDivElement>(null);
  const notificationRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const handleToggle = () => {
    if (window.innerWidth >= 1024) {
      toggleSidebar();
    } else {
      toggleMobileSidebar();
    }
  };
  const navigate = useNavigate();
  const RedirectToUserDashboard = (e: any) => {
    const form = e.currentTarget;
    const userId = (form.elements.namedItem("user") as HTMLInputElement).value;
    if (userId) {
      const params = new URLSearchParams(location.search);
      params.set("user", userId);
      navigate(`${location.pathname}?${params.toString()}`, { replace: true });
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        walletRef.current &&
        !walletRef.current.contains(event.target as Node) &&
        notificationRef.current &&
        !notificationRef.current.contains(event.target as Node)
      ) {
        setWalletOpen(false);
        setNotificationOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);



  return (
    <header className="sticky top-0 flex w-full bg-white  z-99999   dark:bg-gray-900">
      <div className="flex  md:relative flex-col items-center justify-between grow lg:flex-row lg:px-6">
        <div className="flex items-center justify-between w-full gap-2  mt-2   sm:gap-4 lg:justify-normal  lg:px-0 lg:py-4">
          <button
            className="items-center justify-center w-10 h-10 text-gray-500 rounded-lg z-99999  lg:flex dark:text-gray-400 lg:h-11 lg:w-11 lg:border"
            onClick={handleToggle}
            aria-label="Toggle Sidebar"
          >
            {isMobileOpen ? (
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M6.21967 7.28131C5.92678 6.98841 5.92678 6.51354 6.21967 6.22065C6.51256 5.92775 6.98744 5.92775 7.28033 6.22065L11.999 10.9393L16.7176 6.22078C17.0105 5.92789 17.4854 5.92788 17.7782 6.22078C18.0711 6.51367 18.0711 6.98855 17.7782 7.28144L13.0597 12L17.7782 16.7186C18.0711 17.0115 18.0711 17.4863 17.7782 17.7792C17.4854 18.0721 17.0105 18.0721 16.7176 17.7792L11.999 13.0607L7.28033 17.7794C6.98744 18.0722 6.51256 18.0722 6.21967 17.7794C5.92678 17.4865 5.92678 17.0116 6.21967 16.7187L10.9384 12L6.21967 7.28131Z"
                  fill="currentColor"
                />
              </svg>
            ) : (
              <div className="" style={{ transform: 'perspective(100px) rotateX(10deg)', filter: 'drop-shadow(1px 1px 1px #999)' }}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="35"
                  height="35"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-align-justify-icon lucide-align-justify"
                >
                  <path d="M3 12h18" />
                  <path d="M3 18h18" />
                  <path d="M3 6h18" />
                </svg>
              </div>
            )}
            {/* Cross Icon */}
          </button>

          <div className="">
            <form onSubmit={(e) => RedirectToUserDashboard(e)}>
              <div className="relative">
                <span className="absolute -translate-y-1/2 pointer-events-none left-4 top-1/2">
                  <svg
                    className="fill-gray-500 dark:fill-gray-400"
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M3.04175 9.37363C3.04175 5.87693 5.87711 3.04199 9.37508 3.04199C12.8731 3.04199 15.7084 5.87693 15.7084 9.37363C15.7084 12.8703 12.8731 15.7053 9.37508 15.7053C5.87711 15.7053 3.04175 12.8703 3.04175 9.37363ZM9.37508 1.54199C5.04902 1.54199 1.54175 5.04817 1.54175 9.37363C1.54175 13.6991 5.04902 17.2053 9.37508 17.2053C11.2674 17.2053 13.003 16.5344 14.357 15.4176L17.177 18.238C17.4699 18.5309 17.9448 18.5309 18.2377 18.238C18.5306 17.9451 18.5306 17.4703 18.2377 17.1774L15.418 14.3573C16.5365 13.0033 17.2084 11.2669 17.2084 9.37363C17.2084 5.04817 13.7011 1.54199 9.37508 1.54199Z"
                      fill=""
                    />
                  </svg>
                </span>
                <input
                  type="text"
                  placeholder="User id"
                  name="user"
                  className="dark:bg-dark-900 h-11 border border-gray-200 dark:border-gray-800  rounded-lg   bg-transparent  pl-12  text-sm text-gray-800 shadow-theme-xs focus:outline-hidden focus:ring-3 focus:ring-brand-500/10  dark:bg-gray-900  dark:text-white/90 w-[180px] md:w-[300px]"
                />
              </div>
            </form>
          </div>
          <div ref={walletRef} className="flex  bg-[#0000000] gap-1">
            <WalletPage
              isOpen={isWalletOpen}
              setIsOpen={(val: any) => {
                setWalletOpen(val);
                if (val) setNotificationOpen(false);
              }}
            />
          </div>
          <div className="flex  gap-1 mr-[3%]">
            {/* <NotificationDropdown /> */}
            <NotificationDropdown
              isOpen={isNotificationOpen}
              setIsOpen={(val: boolean) => {
                setNotificationOpen(val);
                if (val) setWalletOpen(false); 
              }}
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default AppHeader;
