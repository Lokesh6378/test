import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useLocation, useNavigate, useSearchParams } from "react-router";

import {
  BoxCubeIcon,
  ChevronDownIcon,
  GridIcon,
  PieChartIcon,
  PlugInIcon,
  UserCircleIcon,
} from "../icons";
import { FaHandHoldingUsd, FaSignOutAlt } from "react-icons/fa";
import { useSidebar } from "../context/SidebarContext";
import { fav, levelTeamIcon, mpsToken1, navbarLogo, programImage, ticketImage ,worker} from "../assets";
import { Gamepad2, Pickaxe } from "lucide-react";
import { useDisconnect } from "wagmi";
import { getAddressByUniqueId } from "../apis/auth/auth";
import { useQuery } from "@tanstack/react-query";
import { getConfigData } from "../apis/AiRobat/main";
import { GiKangaroo } from "react-icons/gi"






const allowedAddresses = [
  "0x7b250D249CED0ACc451E359f14c598a9A8fF2479",
  "0x91050Ef95935069E9cB6e8D7834B42e0135D5F18",
  "0xE32A0f9332b903F9B381EFF55bA23Edc15d32184",
  "0x99DE30d8D1C56112Eb55975C36CE0C166E3D88fE",
  "0xea87e4aeB9d69B2fa52c605855e595F3e1bE65a6"
];


const AppSidebar: React.FC = () => {
  const { isExpanded, isMobileOpen, isHovered, setIsHovered, setIsMobileOpen } = useSidebar();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const { disconnectAsync } = useDisconnect();
  const pathname = location.pathname;
  const user = searchParams.get("user");
  const navigate = useNavigate();
  // const {
  //   gloabalData
  // } = useEcommerceData();

      const {
        data: gloabalData,
    } = useQuery({
        queryKey: ["gloabalData"],
        queryFn: () => getConfigData(),
        staleTime: 1000 * 60 * 2,
        refetchOnWindowFocus: false,


    });



  const getUserAddressFromToken = () => {
    try {
      const token = localStorage.getItem("jwttoken");
      if (!token) return null;
      const [, payload] = token.split(".");
      const decoded = JSON.parse(atob(payload));

      return decoded?.address?.toLowerCase();
    } catch (error) {
      return null;
    }
  };


  const connectedAddress = getUserAddressFromToken();
  const allowedAddressesLower = allowedAddresses.map((addr) => addr.toLowerCase());
  const isAllowedUser = allowedAddressesLower.includes(connectedAddress);


  type NavItem = {
    name: string;
    icon: React.ReactNode;
    path?: string;
    subItems?: { name: string; path: string; pro?: boolean; new?: boolean }[];
  };
  // useEffect(() => {
  //   if (!gloabalData?.data) return;

  //   const stakingMode = gloabalData.data.staking_maintenance_mode;
  //   const isLaunched = gloabalData.data.isAiRobotStakingLaunched;
  //   const currentPath = location.pathname;

  //   const aiRobotPaths = [
  //     "/robat",
  //     "/earning",
  //     "/withdraw",
  //     "/level-robat",
  //     "/stacking-transaction",
  //     "/stacking-royalty",
  //   ];

  //   if (isLaunched && aiRobotPaths.includes(currentPath)) {
  //     navigate("/comming", { replace: true });
  //     return;
  //   }

  //   if (!isLaunched && stakingMode && aiRobotPaths.includes(currentPath)) {
  //     navigate("/maintanesmode", { replace: true });
  //     return;
  //   }

  //   if (!isLaunched && !stakingMode && !isAllowedUser && aiRobotPaths.includes(currentPath)) {
  //     navigate("/comming", { replace: true });
  //     return;
  //   }

  //   // ✅ FIX: if user is on comming or maintenance but staking is ready and allowed
  //   if (
  //     !isLaunched &&
  //     !stakingMode &&
  //     isAllowedUser &&
  //     (currentPath === "/comming" || currentPath === "/maintanesmode")
  //   ) {
  //     navigate("/robat", { replace: true });
  //   }
  // }, [
  //   gloabalData?.data?.staking_maintenance_mode,
  //   gloabalData?.data?.isAiRobotStakingLaunched,
  //   location.pathname,
  //   isAllowedUser
  // ]);


  useEffect(() => {
    const checkAccess = async () => {
      if (!gloabalData?.data) return;

      const connectedAddress = getUserAddressFromToken();
      const allowedAddressesLower = allowedAddresses.map((addr) => addr.toLowerCase());

      let previewAddress: string | null = null;

      if (user) {
        try {
          const result: any = await getAddressByUniqueId(user);
          previewAddress = result?.address?.toLowerCase();
        } catch (error) {
          console.error("Error fetching preview address:", error);
        }
      }

      const isAllowedUser = connectedAddress && allowedAddressesLower.includes(connectedAddress);
      const isSameUser = previewAddress ? connectedAddress === previewAddress : true;

      const currentPath = location.pathname;
      const aiRobotPaths = [
        "/staking",
        // "/earning",
        // "/withdraw",
        "/level-robat",
        "/stacking-transaction",
        "/stacking-royalty",
        "/earners-AiRobat"
      ];
      const onAiRobotPage = aiRobotPaths.includes(currentPath);

      const isLaunched = gloabalData.data.isAiRobotStakingLaunched;
      const stakingMode = gloabalData.data.maintain_mode;

      if (stakingMode) {
        navigate("/maintanesmode", { replace: true });
        return;
      }
      if (!isLaunched && onAiRobotPage && (!isAllowedUser || !isSameUser)) {
        navigate("/comming", { replace: true });
        return;
      }

      if (isLaunched && (currentPath === "/comming" || currentPath === "/maintanesmode")) {
        navigate("/staking", { replace: true });
        return;
      }

      if (!stakingMode && currentPath === "/maintanesmode") {
        navigate("/staking", { replace: true });
        return;
      }

      if (!isLaunched && isAllowedUser && currentPath === "/comming") {
        navigate("/staking", { replace: true });
        return;
      }

      if (!isLaunched && currentPath === "/staking" && !isAllowedUser) {
        navigate("/comming", { replace: true });
        return;
      }
    };

    checkAccess();
  }, [
    gloabalData?.data?.maintain_mode,
    gloabalData?.data?.isAiRobotStakingLaunched,
    location.pathname,
    user
  ]);


  const isLaunched = gloabalData?.data?.isAiRobotStakingLaunched;
  const isInMaintenance = gloabalData?.data?.maintain_mode;
  //specialOffer
   const aiRobotSubItems =
    isLaunched || isAllowedUser
      ? isInMaintenance
        ? [{ name: "Maintenance Mode", path: "/maintanesmode", pro: false }]
        : [
          { name: "Level Team ", path: "/level-robat", pro: false },
          ...(isInMaintenance ? [] : [{ name: "Pkgs", path: "/pkgs", pro: false }]),
          // { name: "Earning ", path: "/earning", pro: false },
          // { name: "Withdraw ", path: "/withdraw", pro: false },
          { name: "Transactions", path: "/stacking-transaction", pro: false },
          // { name: "Weekly Salary", path: "/stacking-royalty", pro: false },
          // { name: "Special Offer", path: "/specialOffer", pro: false },
          // { name: "Top Earners ", path: "/earners-AiRobat", pro: false },s
        ]
      : [{ name: "Coming Soon", path: "/comming", pro: false }];


  // <Route path="/investor-program" element={<InvestorTabs />} />
  // <Route path="/investor-AiRobat" element={<AiRobatInvestor />} />
  const navItems: NavItem[] = [

    {
      icon: <GridIcon />,
      name: "Dashboard",
      path: "/dashboard",
    },
    {
      icon: <UserCircleIcon />,
      name: "User Profile",
      path: "/profile",
    },
    {
      icon: <img src={levelTeamIcon} alt="" className="w-6 h-6 invert grayscale opacity-70" />,
      name: "Level Team ",
      // path: "/",
      path: "/level-team"
    },
    {
      name: "MPS Token",
      icon: <img src={mpsToken1} alt="" className="w-6 h-6 " />,
      path: "/mpsToken",
    },
    {
      icon: <img src={programImage} alt="Logo" className="w-6 h-6 text-white bg-white" />,
      name: "Programs",
      subItems: [
        { name: "Slots", path: "/programs", pro: false },
        { name: "Team ", path: "/level", pro: false },
        { name: "Gaming NFT", path: "/gaming-nft", pro: false },
        { name: "Royalty Salary", path: "/royalty", pro: false },
        { name: "Transactions", path: "/transactions", pro: false },
        // { name: "Top Earners", path: "/earners-program", pro: false },
        // 

      ],


    },    


    {
      name: "Coin Mining",
      icon: <Pickaxe />,
      path: "/coinMining",
    },
    {
      icon: <img src={ticketImage} alt="Logo" className="w-6 h-6 text-white bg-white" />,
      name: "Lottery",
      path: "/lottery",
    },
    {
      name: "MUSD Mining",
     icon: <img src={worker} alt="Logo" className="w-6 h-6 text-white bg-white" />,
      subItems: aiRobotSubItems,
    },
    {
      name: "Donation",
      icon: <FaHandHoldingUsd />,
      path: "/donation",
    },
    // 
    {
      name: "Blastaroo",
      icon: <GiKangaroo />,
      path: "/blastaroo",
    },
    {
      name: "Games",
      icon: <Gamepad2 />,
      path: "/games",
    },

  ];

  const othersItems: NavItem[] = [
    {
      icon: <PieChartIcon />,
      name: "Charts",
      subItems: [
        { name: "Line Chart", path: "/line-chart", pro: false },
        { name: "Bar Chart", path: "/bar-chart", pro: false },
      ],
    },
    {
      icon: <BoxCubeIcon />,
      name: "UI Elements",
      subItems: [
        { name: "Alerts", path: "/alerts", pro: false },
        { name: "Avatar", path: "/avatars", pro: false },
        { name: "Badge", path: "/badge", pro: false },
        { name: "Buttons", path: "/buttons", pro: false },
        { name: "Images", path: "/images", pro: false },
        { name: "Videos", path: "/videos", pro: false },
      ],
    },
    {
      icon: <PlugInIcon />,
      name: "Authentication",
      subItems: [
        { name: "Sign In", path: "/signin", pro: false },
        { name: "Sign Up", path: "/signup", pro: false },
      ],
    },
  ];

  const activeClassName = (path: string) => pathname === path ? "text-foreground" : "";
  const pathWithUser = (path: string) => user ? `${path}?user=${user}` : path;

  const [openSubmenu, setOpenSubmenu] = useState<{ type: "main" | "others"; index: number } | null>(null);
  const [subMenuHeight, setSubMenuHeight] = useState<Record<string, number>>({});
  const subMenuRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const isActive = useCallback((path: string) => pathname === path, [pathname]);

  useEffect(() => {
    let submenuMatched = false;
    ["main", "others"].forEach((menuType) => {
      const items = menuType === "main" ? navItems : othersItems;
      items.forEach((nav, index) => {
        nav.subItems?.forEach((subItem) => {
          if (isActive(subItem.path)) {
            setOpenSubmenu({ type: menuType as "main" | "others", index });
            submenuMatched = true;
          }
        });
      });
    });

    if (!submenuMatched) {
      setOpenSubmenu(null);
    }
  }, [pathname, isActive]);

  useEffect(() => {
    if (openSubmenu !== null) {
      const key = `${openSubmenu.type}-${openSubmenu.index}`;
      if (subMenuRefs.current[key]) {
        setSubMenuHeight((prevHeights) => ({
          ...prevHeights,
          [key]: subMenuRefs.current[key]?.scrollHeight || 0,
        }));
      }
    }
  }, [openSubmenu]);

  const handleSubmenuToggle = (index: number, menuType: "main" | "others") => {
    setOpenSubmenu((prev) =>
      prev?.type === menuType && prev.index === index ? null : { type: menuType, index }
    );
  };

  const handleLinkClick = () => {
    if (isMobileOpen) {
      setIsMobileOpen(false);
    }
  };

  const handleLogout = async () => {
    try {
      await disconnectAsync();
      navigate("/");
    }
    catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const renderMenuItems = (items: NavItem[], menuType: "main" | "others") => (
    <ul className="flex flex-col gap-4">
      {items.map((nav, index) => (
        <li key={nav.name}>
          {nav.subItems ? (
            <button
              onClick={() => handleSubmenuToggle(index, menuType)}
              className={`menu-item group ${openSubmenu?.type === menuType && openSubmenu?.index === index
                ? "menu-item-active"
                : "menu-item-inactive"
                } cursor-pointer ${!isExpanded && !isHovered ? "lg:justify-center" : "lg:justify-start"}`}
            >
              <span className={`menu-item-icon-size  ${openSubmenu?.type === menuType && openSubmenu?.index === index
                ? "menu-item-icon-active"
                : "menu-item-icon-inactive "}`}>
                {nav.icon}
              </span>
              {(isExpanded || isHovered || isMobileOpen) && (
                <>
                  <span className="menu-item-text text-xl">{nav.name}</span>
                  <ChevronDownIcon
                    className={`ml-auto w-5 h-5 transition-transform duration-200 ${openSubmenu?.type === menuType && openSubmenu?.index === index
                      ? "rotate-180 text-[#86ff00]"
                      : ""
                      }`}
                  />
                </>
              )}
            </button>
          ) : nav.path && (
            <Link
              to={pathWithUser(nav.path)}
              onClick={handleLinkClick}
              className={`menu-item group ${isActive(nav.path) ? "menu-item-active" : "menu-item-inactive"} ${activeClassName(nav.path)}`}
            >
              <span className={`menu-item-icon-size  text-gray-400 ${isActive(nav.path)
                ? "menu-item-icon-active"
                : "menu-item-icon-inactive"}`}>
                {nav.icon}
              </span>
              {(isExpanded || isHovered || isMobileOpen) && (
                <span className="menu-item-text text-xl">{nav.name}</span>
              )}
            </Link>
          )}
          {nav.subItems && (isExpanded || isHovered || isMobileOpen) && (
            <div
              ref={(el) => {
                subMenuRefs.current[`${menuType}-${index}`] = el;
              }}
              className="overflow-hidden transition-all duration-300"
              style={{
                height:
                  openSubmenu?.type === menuType && openSubmenu?.index === index
                    ? `${subMenuHeight[`${menuType}-${index}`]}px`
                    : "0px",
              }}
            >
              <ul className="mt-2 space-y-1 ml-9">
                {nav.subItems.map((subItem) => (
                  <li key={subItem.name}>
                    <Link
                      to={pathWithUser(subItem.path)}
                      onClick={handleLinkClick}
                      className={`menu-dropdown-item ${isActive(subItem.path)
                        ? "menu-dropdown-item-active"
                        : "menu-dropdown-item-inactive"} ${activeClassName(subItem.path)}`}
                    >
                      <span className="text-lg">{subItem.name}</span>
                      <span className="flex items-center gap-1 ml-auto">
                        {subItem.new && (
                          <span className={`ml-auto ${isActive(subItem.path)
                            ? "menu-dropdown-badge-active"
                            : "menu-dropdown-badge-inactive"} menu-dropdown-badge`}>
                            new
                          </span>
                        )}
                        {subItem.pro && (
                          <span className={`ml-auto ${isActive(subItem.path)
                            ? "menu-dropdown-badge-active"
                            : "menu-dropdown-badge-inactive"} menu-dropdown-badge`}>
                            pro
                          </span>
                        )}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </li>
      ))}
    </ul>
  );
  // ${isExpanded || isMobileOpen || isHovered ? "w-[50%]" : "w-[90px]"}
  return (
    <aside
      className={`fixed  flex flex-col lg:mt-0 top-0 px-5 left-0 bg-white dark:bg-gray-900  border-gray-700 text-gray-600 h-screen transition-all duration-300 ease-in-out z-999999 border-r-[0.1px] 
        ${isExpanded || isMobileOpen || isHovered ? "md:w-[300px]" : "w-[90px]"}
        ${isMobileOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0`}
      onMouseEnter={() => !isExpanded && setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className={`py-8 flex ${!isExpanded && !isHovered ? "lg:justify-center" : "justify-start"}`}>
        <Link to="/" onClick={handleLinkClick}>
          {(isExpanded || isHovered || isMobileOpen) ? (
            <img className="md:dark:block" src={navbarLogo} alt="Logo" width={150} height={40} />
          ) : (
            <img src={fav} width={32} height={32} />
          )}
        </Link>
      </div>

      <div className="flex flex-col overflow-y-auto duration-300 ease-linear no-scrollbar">
        <nav className="mb-6">
          <div className="flex flex-col gap-4">
            <div>
              <h2 className={`mb-4 text-xs uppercase flex leading-[20px] text-gray-400 ${!isExpanded && !isHovered ? "lg:justify-center" : "justify-start"}`}>
                {(isExpanded || isHovered || isMobileOpen) ? "" : ""}
              </h2>
              {renderMenuItems(navItems, "main")}
            </div>
            <div className="flex gap-3 text-2xl ml-4 relative  cursor-pointer  text-gray-500   dark:text-gray-400 hover:text-white dark:hover:text-white">
              <FaSignOutAlt />
              <h2 onClick={handleLogout} className={`mb-4 text-xl  cursor-pointer text-red-400 flex leading-[20px]  ${!isExpanded && !isHovered ? "lg:justify-center" : "justify-start"}`}>
                {(isExpanded || isHovered || isMobileOpen) ? "Sign out" : ""}
              </h2>

            </div>
          </div>
        </nav>
      </div>
    </aside>
  );
};

export default AppSidebar;


