  import {
    GetReferralFromAddress,
    getuniqueid,
  } from "../lib/smartContract";

  import { SidebarProvider, useSidebar } from "../context/SidebarContext";
  import {  Outlet, useSearchParams } from "react-router-dom";
  import {  useEffect, useState } from "react";
  import { useAccount } from "wagmi";
  import { useDispatch } from "react-redux";
  import {
    setCurrentUser,
    setWalletUser,
    setPreviewMode,
    setMaintainMode,
  } from "../redux/UserSlice";
  import AppHeader from "./AppHeader";
  import AppSidebar from "./AppSidebar";
  import Backdrop from "./Backdrop";
  import {
    getAddressByUniqueId,
    getMaintainMode,
    getUserDetails,
    getUserJwtToken,
    isUserRegistered,
    signUserMessage,
    verifyJwtToken,
  } from "../apis/auth/auth";
  import { robotImage } from "../assets";
  import { useQuery } from "@tanstack/react-query";
  import { getConfigData } from "../apis/AiRobat/main";
  import { wagmiAdapter } from "../lib/Web3Modal";
  import ForcePopup from "../components/ui/ForcePopup/page";
  import PageLoader from "../components/common/PageLoader";
  import ErrorScreen from "../components/common/ErrorScreen";
  // import Button from "../components/ui/button/page";

  const LayoutContent = () => {
    const { isExpanded, isHovered, isMobileOpen } = useSidebar();
    const config = wagmiAdapter?.wagmiConfig
    const { address } = useAccount({ config });
    const {
      data: gloabalData,
    } = useQuery({
      queryKey: ["isgloabalDatasssssssss"],
      queryFn: () => getConfigData(),
      staleTime: 1000 * 60 * 2,
      refetchOnWindowFocus: false,


    });


    // console.log(gloabalData?.data?.text_show_leader);


    const shouldShowPopup =
      address === "0x4328B5C5746b1Dc0f6377466072ba0aB6Bc2F856" &&
      gloabalData?.data?.text_show_leader === true;

    return (
      <div className="min-h-screen xl:flex">
        <div>
          <AppSidebar />
          <Backdrop />
        </div>
        <div
          className={`flex-1 transition-all duration-300 ease-in-out ${isExpanded || isHovered ? "lg:ml-[290px]" : "lg:ml-[90px]"
            } ${isMobileOpen ? "ml-0" : ""}`}
        >
          <AppHeader />
          <div className="p-4 mx-auto max-w-screen-2xl md:p-6">
            <Outlet />
          </div>
          <ForcePopup show={shouldShowPopup} />
        </div>
      </div>
    );
  };

  const AppLayout = () => {
    const { isConnected, address,status} = useAccount();
    const [searchParams] = useSearchParams();
    const preview_user = searchParams.get("user");
    const [isNotFound, setIsNotFound] = useState(false);
    const [authReady, setAuthReady] = useState(false);
    const dispatchRedux = useDispatch();
    const [authChecked, setAuthChecked] = useState(false);
    // const { disconnectAsync } = useDisconnect();
    const formatDate = (dateString: any) => {
      const date = new Date(dateString);
      return `${String(date.getDate()).padStart(2, "0")}/${String(
        date.getMonth() + 1
      ).padStart(2, "0")}/${date.getFullYear()}`;
    };
    const walletReady =
  status === "connected" && !!address;


    const bypassMaintainModeAddresses: any = [
      "0xE32A0f9332b903F9B381EFF55bA23Edc15d32184".toLowerCase(),
      "0xea87e4aeB9d69B2fa52c605855e595F3e1bE65a6".toLowerCase(),
      "0x91050Ef95935069E9cB6e8D7834B42e0135D5F18".toLowerCase(),
      "0xe55cE6AfC530E85CAe20640F9337844d172B602B".toLowerCase(),
      "0x99DE30d8D1C56112Eb55975C36CE0C166E3D88fE".toLowerCase(),
      "0x7b250D249CED0ACc451E359f14c598a9A8fF2479".toLowerCase(),
      "0x267B1D791AA9021Dc637Cd17fED43aD1e46bF5f9".toLowerCase(),
      "0x2f420DEa0f5Ef54932a5FcaF49B365753B3843CF".toLowerCase(),
      "0x6d0BDF9b0bBd2a634c6131B7D02Fd4A88A15cd41".toLowerCase(),
    ];



    const fetchUserDetails = async () => {
      // if (!isConnected || !address) return null;
      if (!isConnected || !address) {
        throw new Error("Wallet not ready");
      }

      const user = await isUserRegistered(address);


      if (user?.oldWalletMatched) return { isRegistered: false };
      const uniqueId = await getuniqueid(address);
      const details = await getUserDetails(address, uniqueId);
      const unique_id = details?.uniqueId;
      const ref = details?.ref ?? "0x0";


      let refId =
        ref === "0x0000000000000000000000000000000000000000"
          ? unique_id
          : await GetReferralFromAddress(ref);

      // const verifyJwt = await verifyJwtToken(address);

      // if (!verifyJwt) {
      //   const signature = await signUserMessage(address);

      //   const jwt = signature ? await getUserJwtToken(address, signature) : null;

      //   if (!jwt) throw new Error("JWT not valid");
      // }

      const maintain_mode = await getMaintainMode();

      let previewDetails = null;
      let previewRefId = null;

      if (preview_user) {
        const previewAddress = await getAddressByUniqueId(preview_user);
        const previewUniqueId = await getuniqueid(previewAddress.data);
        previewDetails = await getUserDetails(
          previewAddress.data,
          previewUniqueId
        );
        const previewRef = previewDetails?.ref ?? "0x0";
        previewRefId =
          previewRef === "0x0000000000000000000000000000000000000000"
            ? previewDetails?.uniqueId
            : await GetReferralFromAddress(previewRef);
      }

      return {
        isRegistered: true,
        details,
        unique_id,
        ref,
        refId,
        maintainMode: maintain_mode?.data,
        previewDetails,
        previewRefId,
      };
    };


    useEffect(() => {
      const storedAddress = localStorage.getItem("walletAddress");
    
      if (
        storedAddress &&
        storedAddress !== address?.toLowerCase()
      ) {
        localStorage.removeItem("jwttoken");
        localStorage.removeItem("walletAddress");
      }
    }, [address]);


    useEffect(() => {

      const checkJwtFirst = async () => {
    
        if (!address) return;
    
        const storedJwt = localStorage.getItem("jwttoken");
        const storedAddress = localStorage.getItem("walletAddress");
    
        /* ✅ JWT already present */
        if (
          storedJwt &&
          storedAddress === address?.toLowerCase()
        ) {
          setAuthReady(true);
          return;
        }
        /* ✅ JWT verify from backend */
           const verifyJwt = await verifyJwtToken(address);

      if (!verifyJwt) {
        const signature = await signUserMessage(address);

        const jwt = signature ? await getUserJwtToken(address, signature) : null;

        if (!jwt) throw new Error("JWT not valid");
      }
    
        setAuthReady(true);
      };
    
      checkJwtFirst();
    
    }, [address]);

    const {
      data,
      isLoading,
      isError,
      error,
      refetch
    } = useQuery({
      queryKey: ["userDetails", address],
      queryFn: fetchUserDetails,
      enabled: walletReady && authReady,
      refetchOnWindowFocus: false,
    });


    useEffect(() => {
      if (!walletReady) return;
    
      if (!isLoading) {
        setAuthChecked(true);
      }
    }, [walletReady, isLoading]);


    // console.log("address",address);
    // const {
    //   data,
    //   isLoading,
    //   isError,
    //   error,
    //   refetch,
    // } = useQuery({
    //   queryKey: ["userDetailsss", address],
    //   queryFn: fetchUserDetails,
    //   enabled:!!walletReady,
    //   // staleTime: 1000 * 60 * 2,
    //   // retry: false,
    //   // retryDelay: 2000,
    //   refetchOnWindowFocus: false,  
    // });



    // useEffect(() => {
    //   if (status === "connected" && address) {
    //     refetch();
    //   }
    // }, [status, address, refetch]);

    // if (isConnecting || isLoading) {
    //   return <PageLoader />;
    // }

    // console.log("walletReady",walletLoading);
    // console.log("isLoading",isLoading);
  //   const walletLoading =
  // status === "connecting" ||
  // status === "reconnecting" ||
  // !address;
    
  // console.log("authReady",authReady);
  

  if (
    status === "connecting" ||
    status === "reconnecting" ||
    !walletReady ||
    isLoading ||
    !authChecked||!authReady
  ) {
    return <PageLoader />;
  }

    if (isError) {
      return (
        <ErrorScreen
          message={(error as Error)?.message}
          retry={() => refetch()}
        />
      );
    }

    if (
      data?.maintainMode &&
      !bypassMaintainModeAddresses.includes(address?.toLowerCase())
    ) {
      dispatchRedux(setMaintainMode(data?.maintainMode));
      return (
        <div className="flex flex-col gap-2">
          <div className="text-gray-600 flex flex-col h-full justify-center items-center">
            <img src={robotImage} alt="" />
            <h1 className="text-3xl text-white">We'll be back soon!</h1>
            <p className="text-2xl font-bold text-center">
              Our Website is currently under maintenance.
            </p>
            <p className="text-2xl font-bold text-center">
              We’re working hard to improve your experience
            </p>
            <p>"Thank you for your patience!</p>
          </div>
        </div>
      );
    }


    if (data?.isRegistered) {
      dispatchRedux(setWalletUser({ isRegistered: true, address }));

      if (preview_user) {
        if (data?.previewDetails) {
          dispatchRedux(
            setCurrentUser({
              ...data?.previewDetails,
              id: data?.previewDetails?.uniqueId,
              ref: data?.previewDetails?.ref,
              refId: data?.previewRefId,
              joinedOn: formatDate(data?.previewDetails?.joinedOn),
            })
          );
          dispatchRedux(setPreviewMode(true));
        } else {
          setIsNotFound(true);
        }
      } else {
        dispatchRedux(
          setCurrentUser({
            ...data?.details,
            id: data?.unique_id,
            ref: data?.ref,
            refId: data?.refId,
            joinedOn: formatDate(data?.details?.joinedOn),
          })
        );
        dispatchRedux(setPreviewMode(false));
      }

      if (isNotFound) {
        return (
          <div className="flex flex-col justify-center items-center h-screen text-destructive text-center gap-3">
            <h2 className="text-3xl font-bold">User not Found</h2>
          </div>
        );
      }

      return (
        <SidebarProvider>
          <LayoutContent />
        </SidebarProvider>
      );
    }

    return (
      <div className="flex w-full h-screen justify-center items-center">
        <p className="text-lg text-gray-600">This wallect is not authorised</p>

      </div>
    );
  };

  export default AppLayout;

