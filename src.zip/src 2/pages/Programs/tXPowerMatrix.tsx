"use client";

import { Users, Recycle } from "lucide-react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from "../../components/ui/card/page";
import { useSelector } from "react-redux";
import { BsCurrencyDollar } from "react-icons/bs";
import { getBackgroundOfPackagematrx } from "../../lib/utils";

export default function Tr2XPowerMatrix({ data }: any) {
  const currentUser = useSelector((state: any) => state.global.currentUser);
// console.log("data",data);

  const positions = [
    // Inner 3
    { cx: 250, cy: 140 },
    { cx: 340, cy: 290 },
    { cx: 160, cy: 290 },

    // Outer 9
    { cx: 250, cy: 70 },
    { cx: 340, cy: 110 },
    { cx: 420, cy: 200 },
    { cx: 380, cy: 330 },
    { cx: 300, cy: 420 },
    { cx: 200, cy: 420 },
    { cx: 120, cy: 330 },
    { cx: 80, cy: 200 },
    { cx: 160, cy: 110 },
  ];

  const matrixUsers = [
    ...(data?.data?.[0] || []),
    ...(data?.data?.[1] || []),
  ];

  return (
    <Card className="border p-2 border-[#FFD700] rounded-3xl h-full flex flex-col justify-between">
      <CardHeader>
        <CardTitle>
          <div className="flex justify-between items-center text-white">
            <div className="bg-blue-light-400 text-black rounded-full w-10 h-10 flex items-center justify-center font-bold">
              {data?.pkg}
            </div>

            <span>Matrix</span>

            <div className="text-center">
              <p className="text-gray-400 text-[50%]">Total Users</p>
              <p className="text-green-500 text-xl font-bold">
                {data?.overallUsers || 0}
              </p>
            </div>

            <div className="flex items-center gap-1 font-bold">
              <BsCurrencyDollar className="text-blue-light-400 text-2xl" />
              <span className="text-2xl">{data?.amount}</span>
            </div>
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent>
        <svg
          viewBox="0 0 500 500"
          className="w-full max-w-[220px] h-auto mx-auto"
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            <filter id={`glow-${data?.pkg}`}>
              <feGaussianBlur stdDeviation="5" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>

            <radialGradient id={`centerGrad-${data?.pkg}`}>
              <stop offset="0%" stopColor="#00ff99" />
              <stop offset="100%" stopColor="#003d2e" />
            </radialGradient>
          </defs>

          {/* Center User */}
          <circle
            cx="250"
            cy="250"
            r="55"
            fill={`url(#centerGrad-${data?.pkg})`}
            filter={`url(#glow-${data?.pkg})`}
          />

          {/* Center User Text */}
          <text
            x="250"
            y="260"
            textAnchor="middle"
            fill="white"
            fontSize="22"
            fontWeight="bold"
          >
            YOU
          </text>

          {/* Rings */}
          <circle
            cx="250"
            cy="250"
            r="110"
            stroke="#00ffcc"
            strokeOpacity="0.25"
            fill="none"
          />

          <circle
            cx="250"
            cy="250"
            r="180"
            stroke="#00ffcc"
            strokeOpacity="0.15"
            fill="none"
          />

          {/* Decorative Orbit Lines */}
          <g stroke="#00ffcc" strokeOpacity="0.15" fill="none">
            <ellipse cx="250" cy="250" rx="200" ry="120" />
            <ellipse cx="250" cy="250" rx="170" ry="80" />
            <ellipse cx="250" cy="250" rx="140" ry="60" />
          </g>

          {/* Dynamic Members */}
          <g filter={`url(#glow-${data?.pkg})`}>
  {positions.map((pos, index) => {
    const item = matrixUsers[index];

    return (
      <circle
        key={index}
        cx={pos.cx}
        cy={pos.cy}
        r="15"
        fill={
          item?.type
            ? getBackgroundOfPackagematrx(item.type)
            : "#2a2a2a"
        }
        stroke="#ffffff"
        strokeWidth="1"
      />
    );
  })}
</g>

          {/* Decorative dots */}
          <g fill="#00ffcc" opacity="0.5">
            <circle cx="310" cy="160" r="3" />
            <circle cx="180" cy="180" r="3" />
            <circle cx="350" cy="250" r="3" />
            <circle cx="140" cy="250" r="3" />
            <circle cx="250" cy="350" r="3" />
          </g>
        </svg>
      </CardContent>

      <CardFooter>
        <div className="flex justify-between w-full text-white">
          <div className="flex gap-2 items-center">
            <Users />
            <span className="text-blue-light-400">
              {data?.member || 0}
            </span>
          </div>

          <div className="flex gap-2 items-center">
            <Recycle />
            <span className="text-blue-light-400">
              {data?.recycle || 0}
            </span>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}