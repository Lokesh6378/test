import { getBackgroundOfPackagematrx } from "../../lib/utils";
import { Users, Recycle } from "lucide-react";

import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "../../components/ui/card/page";
import { UserProfiles } from "../../assets";
import { useSelector } from "react-redux";
import { useState } from "react";
import { BsCurrencyDollar } from "react-icons/bs";


type PackageData = {
  id: number;
  type: string | "upline" | "downline" | "working" | "";
};
type PackageProps = {
  pkg: number;
  recycle: number;
  amount: number;
  member: number;
  overallUsers: number;
  missed: boolean;
  data: Array<Array<PackageData>>;
};

export default function PropowerMatrixData({
  data,
}: {
  data: PackageProps;
}) {

  const currentUser = useSelector((state: any) => state.global.currentUser);
  const [profileSrc, setProfileSrc] = useState(
    currentUser?.profile?.length > 0 ? currentUser?.profile : UserProfiles
  );



  return <Card className="border p-2 border-[#FFD700] overflow-hidden rounded-3xl transition-colors h-full flex flex-col justify-between">
    <CardHeader>

      <CardTitle>

        <div className="flex flex-row justify-between items-center text-white w-full   gap-4">
          {/* Slot */}
          <div className="text-lg font-bold whitespace-nowrap">
            Slot{data?.pkg}
          </div>

          {/* Center: Total Users & Current Line */}
          <div className="flex flex-row items-center mb-2 justify-center gap-4">
            <div className="text-center">
              <p className="text-gray-400 text-[50%] ">Total Users</p>
              <p className="text-blue-light-400 text-2xl font-bold">{data?.overallUsers}</p>
            </div>
          </div>

          {/* Amount */}
          <div className="flex items-center gap-1 text-lg  mb-2font-bold whitespace-nowrap">
            <span className="text-blue-light-400 text-2xl md:text-4xl "><BsCurrencyDollar /></span>
            <span className="ml-[-6%] text-2xl md:text-4xl ">{data?.amount}</span>
          </div>
        </div>

      </CardTitle>
    </CardHeader>

    <CardContent className="p-0   w-[100%]  h-[100%] text-center    ">

      <svg viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <style>
            {`    .line {
        stroke: black;
        stroke-width: 5 ;
      }
         .line2 {
        stroke: black;
        stroke-width: 5 ;
      }
    
         .line3 {
        stroke: black;
        stroke-width: 2 ;
      }
      .text {
        fill: white;
        font-size: 18px;
        text-anchor: middle;
        font-family: Arial, sans-serif;
        dominant-baseline: middle;
      }`}
          </style>
        </defs>

        <circle className="line3" cx="300" cy="300" r="205" fill="black" />
        <circle className="line3" cx="300" cy="300" r="130" fill="none" />
        <g>
          <g transform="translate(300,300)">
            <g>
              <path d="M 0,-123 A 123 123 0 0 1 123,0 L 0,0 Z" fill={getBackgroundOfPackagematrx(data?.data[0][2]?.type)} />
              <path d="M -123,0 A 123 123 0 0 1 0,-123 L 0,0 Z" fill={getBackgroundOfPackagematrx(data?.data[0][1]?.type)} />
              <path d="M 0,123 A 123 123 0 0 1 -123,0 L 0,0 Z" fill={getBackgroundOfPackagematrx(data?.data[0][0]?.type)} />
              <path d="M 123,0 A 123 123 0 0 1 0,123 L 0,0 Z" fill={getBackgroundOfPackagematrx(data?.data[0][3]?.type)} />
            </g>

            <line x1="0" y1="-130" x2="0" y2="-60" stroke="black" stroke-width="5" />
            <line x1="0" y1="-130" x2="0" y2="-60" stroke="black" stroke-width="5" transform="rotate(90 0 0)" />
            <line x1="0" y1="-130" x2="0" y2="-60" stroke="black" stroke-width="5" transform="rotate(180 0 0)" />
            <line x1="0" y1="-130" x2="0" y2="-60" stroke="black" stroke-width="5" transform="rotate(270 0 0)" />

          </g>
        </g>
        <defs>
          <clipPath id="circleClip">
            <circle cx="300" cy="300" r="70" /> {/* Match radius with green circle */}
          </clipPath>
        </defs>

        <circle cx="300" cy="300" r="70" fill="green" />

        <image
          href={profileSrc}
          x="230"  // x = cx - (width / 2)
          y="230"  // y = cy - (height / 2)
          width="140"
          height="140"
          clipPath="url(#circleClip)"
          onError={() => setProfileSrc(UserProfiles)}
        />

        {/* <div className="w-full relative h-full rounded-full  bg-white dark:bg-[#242526] ">
                        <img
                            src={
                                currentUser?.profile
                                    //   UserProfiles
                                    ? currentUser.profile
                                    // ?UserProfiles
                                    : UserProfiles
                            }
                            alt="User"
                            className="w-4 h-4  bg-transparent rounded-full object-cover"
                        />
                    </div> */}
        {/* </text> */}
        <g transform="translate(300,300)">
          <g>
            <path d="M 0 -200 A 200 200 0 0 1 76 -185 L 49 -118 A 130 130 0 0 0 0 -130 Z" fill={getBackgroundOfPackagematrx(data?.data[1][8]?.type)} />
            <path d="M 76 -185 A 200 200 0 0 1 141 -141 L 91 -91 A 130 130 0 0 0 49 -118 Z" fill={getBackgroundOfPackagematrx(data?.data[1][9]?.type)} />
            <path d="M 141 -141 A 200 200 0 0 1 185 -76 L 118 -49 A 130 130 0 0 0 91 -91 Z" fill={getBackgroundOfPackagematrx(data?.data[1][10]?.type)} />
            <path d="M 185 -76 A 200 200 0 0 1 200 0 L 130 0 A 130 130 0 0 0 118 -49 Z" fill={getBackgroundOfPackagematrx(data?.data[1][11]?.type)} />
            <path d="M 200 0 A 200 200 0 0 1 185 76 L 118 49 A 130 130 0 0 0 130 0 Z" fill={getBackgroundOfPackagematrx(data?.data[1][12]?.type)} />
            <path d="M 185 76 A 200 200 0 0 1 141 141 L 91 91 A 130 130 0 0 0 118 49 Z" fill={getBackgroundOfPackagematrx(data?.data[1][13]?.type)} />
            <path d="M 141 141 A 200 200 0 0 1 76 185 L 49 118 A 130 130 0 0 0 91 91 Z" fill={getBackgroundOfPackagematrx(data?.data[1][14]?.type)} />
            <path d="M 76 185 A 200 200 0 0 1 0 200 L 0 130 A 130 130 0 0 0 49 118 Z" fill={getBackgroundOfPackagematrx(data?.data[1][15]?.type)} />
          </g>


          <g>
            <path d="M -76 185 A 200 200 0 0 0 0 200 L 0 130 A 130 130 0 0 1 -49 118 Z" fill={getBackgroundOfPackagematrx(data?.data[1][0]?.type)} />
            <path d="M -141 141 A 200 200 0 0 0 -76 185 L -49 118 A 130 130 0 0 1 -91 91 Z" fill={getBackgroundOfPackagematrx(data?.data[1][1]?.type)} />
            <path d="M -185 76 A 200 200 0 0 0 -141 141 L -91 91 A 130 130 0 0 1 -118 49 Z" fill={getBackgroundOfPackagematrx(data?.data[1][2]?.type)} />
            <path d="M -200 0 A 200 200 0 0 0 -185 76 L -118 49 A 130 130 0 0 1 -130 0 Z" fill={getBackgroundOfPackagematrx(data?.data[1][3]?.type)} />
            <path d="M -185 -76 A 200 200 0 0 0 -200 0 L -130 0 A 130 130 0 0 1 -118 -49 Z" fill={getBackgroundOfPackagematrx(data?.data[1][4]?.type)} />
            <path d="M -141 -141 A 200 200 0 0 0 -185 -76 L -118 -49 A 130 130 0 0 1 -91 -91 Z" fill={getBackgroundOfPackagematrx(data?.data[1][5]?.type)} />
            <path d="M -76 -185 A 200 200 0 0 0 -141 -141 L -91 -91 A 130 130 0 0 1 -49 -118 Z" fill={getBackgroundOfPackagematrx(data?.data[1][6]?.type)} />
            <path d="M 0 -200 A 200 200 0 0 0 -76 -185 L -49 -118 A 130 130 0 0 1 0 -130 Z" fill={getBackgroundOfPackagematrx(data?.data[1][7]?.type)} />







          </g>
          <g>
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(0)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(22.5)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(45)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(67.5)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(90)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(112.5)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(135)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(157.5)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(180)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(202.5)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(225)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(247.5)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(270)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(292.5)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(315)" />
            <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(337.5)" />
          </g>
        </g>
      </svg>


    </CardContent>
    <CardFooter>
      <div className="flex text-white gap-3 justify-between">
        <div className="flex gap-2">
          <Users />
          <div className="text-blue-light-400">{data?.member}</div>
        </div>
        <div className="flex  gap-2">
          <Recycle /> <span className="text-blue-light-400">{data?.recycle}</span>
        </div>
      </div>
    </CardFooter>
  </Card>
}

