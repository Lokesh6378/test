"use client";
// import { fillXpowerMatrixCircleColor } from "../../lib/utils";
import { Users, Recycle } from "lucide-react";

import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from "../../components/ui/card/page";
import { useState } from "react";
import { useSelector } from "react-redux";
import { UserProfiles } from "../../assets";
import { BsCurrencyDollar } from "react-icons/bs";
import { get2GlobalBackgroundOfPackageFillColor } from "../../lib/utils";

export default function Tr2XPowerGlobal({ data }: any) {
  const currentUser = useSelector((state: any) => state.global.currentUser);
  const getFillColor = (value: string) => {
    return get2GlobalBackgroundOfPackageFillColor(value);
  };
  const [profileSrc, setProfileSrc] = useState(
    currentUser?.profile || UserProfiles
  );

  const createArc = (
    cx: number,
    cy: number,
    rOuter: number,
    rInner: number,
    start: number,
    end: number
  ) => {
    const x1 = cx + rOuter * Math.cos(start);
    const y1 = cy + rOuter * Math.sin(start);

    const x2 = cx + rOuter * Math.cos(end);
    const y2 = cy + rOuter * Math.sin(end);

    const x3 = cx + rInner * Math.cos(end);
    const y3 = cy + rInner * Math.sin(end);

    const x4 = cx + rInner * Math.cos(start);
    const y4 = cy + rInner * Math.sin(start);

    return `
      M ${x1} ${y1}
      A ${rOuter} ${rOuter} 0 0 1 ${x2} ${y2}
      L ${x3} ${y3}
      A ${rInner} ${rInner} 0 0 0 ${x4} ${y4}
      Z
    `;
  };

  return (
    <Card className="border p-2 border-[#FFD700] rounded-3xl h-full flex flex-col justify-between">
      
      <CardHeader>
        <CardTitle>
          <div className="flex justify-between items-center text-white">
            <div className="bg-blue-light-400 text-black rounded-full w-10 h-10 flex items-center justify-center font-bold">
              {data?.pkg}
            </div>
            Global
            <div className="text-center">
              <p className="text-gray-400 text-[50%]">Total Users</p>
              <p className="text-green-500 text-xl font-bold">
                {data?.overallUsers}
              </p>
            </div>

            <div className="flex items-center gap-1 font-bold">
              <BsCurrencyDollar className="text-blue-light-400 text-2xl" />
              <span className="text-2xl">{data?.amount}</span>
            </div>
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent>
      <svg viewBox="0 0 400 400"   className="w-full max-w-[320px] h-auto mx-auto">

{/* CENTER */}
<circle cx="200" cy="200" r="40" fill="#00cc66" />
<text
  x="200"
  y="205"
  textAnchor="middle"
  fill="black"
  fontSize="14"
  fontWeight="bold"
>
  MPS
</text>

{/* INNER RING */}
<circle cx="200" cy="200" r="80" fill="none" stroke="#00ffcc33" />

{/* INNER 3 */}
{data?.data?.[0]?.map((item: any, i: number) => {
  const angle = (2 * Math.PI / 3) * i - Math.PI / 2;
  const r = 80;

  const x = 200 + r * Math.cos(angle);
  const y = 200 + r * Math.sin(angle);

  return (
    <circle
      key={i}
      cx={x}
      cy={y}
      r="12"
      fill={
        item?.type
          ? getFillColor(item.type)
          : "#555"
      }
      stroke="#fff"
      strokeWidth="1"
    />
  );
})}

{/* OUTER RING */}
<circle cx="200" cy="200" r="140" fill="none" stroke="#00ffcc33" />

{/* OUTER 9 */}
{data?.data?.[1]?.map((item: any, i: number) => {
  const angle = (2 * Math.PI / 9) * i - Math.PI / 2;
  const r = 140;

  const x = 200 + r * Math.cos(angle);
  const y = 200 + r * Math.sin(angle);

  return (
    <circle
      key={i}
      cx={x}
      cy={y}
      r="12"
      fill={
        item?.type
          ? getFillColor(item.type)
          : "#555"
      }
      stroke="#fff"
      strokeWidth="1"
    />
  );
})}

</svg>
      </CardContent>

      <CardFooter>
        <div className="flex text-white justify-between">
          <div className="flex gap-2">
            <Users />
            <div className="text-blue-light-400">{data?.member}</div>
          </div>
          <div className="flex gap-2">
            <Recycle />
            <div className="text-blue-light-400">{data?.recycle}</div>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}


    //    <svg viewBox="0 0 400 400">

    //       {/* OUTER 9 */}
    //       {data?.data[1]?.map((item: any, i: number) => {
    //         const total = 9;
    //         const angle = (2 * Math.PI) / total;
    //         const start = i * angle;
    //         const end = start + angle;

    //         const mid = start + angle / 2;

    //         return (
    //           <g key={i}>
    //             <path
    //               d={createArc(200, 200, 160, 110, start, end)}
    //               fill={fillXpowerMatrixCircleColor(item?.type)}
    //               stroke="#000"
    //               strokeWidth="4"
    //             />

    //             {/* ID TEXT */}
    //             <text
    //               x={200 + 135 * Math.cos(mid)}
    //               y={200 + 135 * Math.sin(mid)}
    //               textAnchor="middle"
    //               alignmentBaseline="middle"
    //               fontSize="12"
    //               fill="black"
    //               fontWeight="bold"
    //             >
    //               {item?.id}
    //             </text>
    //           </g>
    //         );
    //       })}

    //       {/* INNER 3 */}
    //       {data?.data[0]?.map((item: any, i: number) => {
    //         const total = 3;
    //         const angle = (2 * Math.PI) / total;
    //         const start = i * angle;
    //         const end = start + angle;

    //         const mid = start + angle / 2;

    //         return (
    //           <g key={i}>
    //             <path
    //               d={createArc(200, 200, 95, 55, start, end)}
    //               fill={fillXpowerMatrixCircleColor(item?.type)}
    //               stroke="#000"
    //               strokeWidth="4"
    //             />

    //             <text
    //               x={200 + 75 * Math.cos(mid)}
    //               y={200 + 75 * Math.sin(mid)}
    //               textAnchor="middle"
    //               alignmentBaseline="middle"
    //               fontSize="12"
    //               fill="black"
    //               fontWeight="bold"
    //             >
    //               {item?.id}
    //             </text>
    //           </g>
    //         );
    //       })}

    //       {/* CENTER */}
    //       <defs>
    //         <clipPath id="clip">
    //           <circle cx="200" cy="200" r="50" />
    //         </clipPath>
    //       </defs>

    //       <circle cx="200" cy="200" r="50" fill="#111" />

    //       <image
    //         href={profileSrc}
    //         x="150"
    //         y="150"
    //         width="100"
    //         height="100"
    //         clipPath="url(#clip)"
    //       />
    //     </svg>