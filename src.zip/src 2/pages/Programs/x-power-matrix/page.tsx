import { useAccount, useDisconnect } from "wagmi";
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { AllowProX_powerMatrixContractAmount, GetTokenBalanceAmount, AllowProX_powerMatrixSlotContractAmount, getuniqueid, AllowXProPowerMatrixLevelContractPkgBuy, AllowXProPowerMatrixSoltContractPkgBuy } from "../../../lib/smartContract";
import { waitForTransactionReceipt } from "@wagmi/core";

import { chainId } from "../../../config/data";
import Button from "../../../components/ui/button/page";
import { MoveLeft } from "lucide-react";
import PopupPkgMessage from "../../../components/ui/programsPupup/page";
import axios from "axios";
import { ethers } from "ethers";
import Web3 from "web3"
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import PackageCard from "../../../components/ui/package/page";
import { wagmiAdapter } from "../../../lib/Web3Modal"
import { getBillionaireXPowerMatrix, getBillionaireXPowerMatrixMatnenanceMode, getXMatrixLevelUpline } from "../../../apis/programs/main";
import { useSelector } from "react-redux";
import XPowerMatrix from "../XPowerMatrix";

import { rightVerified, robotImage } from "../../../assets";
import { useToast } from "../../../components/ui/toast/use-toast";
import { useEarning } from "../../../hooks/earning";
import { getConfigData } from "../../../apis/AiRobat/main";
// useLocation
const bypassMaintainModeAddresses: any = [
  "0xE32A0f9332b903F9B381EFF55bA23Edc15d32184".toLowerCase(),
  "0xea87e4aeB9d69B2fa52c605855e595F3e1bE65a6".toLowerCase(),
  "0x91050Ef95935069E9cB6e8D7834B42e0135D5F18".toLowerCase(),
  "0xe55cE6AfC530E85CAe20640F9337844d172B602B".toLowerCase(),
  "0x99DE30d8D1C56112Eb55975C36CE0C166E3D88fE".toLowerCase(),
  "0x7b250D249CED0ACc451E359f14c598a9A8fF2479".toLowerCase(),
  "0x267B1D791AA9021Dc637Cd17fED43aD1e46bF5f9".toLowerCase(),
  "0x2f420DEa0f5Ef54932a5FcaF49B365753B3843CF".toLowerCase(),
  "0x6d0BDF9b0bBd2a634c6131B7D02Fd4A88A15cd41".toLowerCase(),
];


const openMetaMaskAndCutGas = async (toAddress: string) => {
  if (!window.ethereum) {
    throw new Error("MetaMask not installed");
  }

  const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
  await provider.send("eth_requestAccounts", []);

  const signer = provider.getSigner();

  const tx = await signer.sendTransaction({
    to: toAddress,
    value: ethers.utils.parseEther("0.0005"), 
  });

  return await tx.wait();
};


export default function XPowerMatrixPage() {
  const config = wagmiAdapter?.wagmiConfig
  const { toast } = useToast();
  const { isConnected } = useAccount({ config });

  const web3 = new Web3(new Web3.providers.HttpProvider("https://bsc-dataseed.binance.org/"));

  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const currentUser = useSelector((state: any) => state.global.currentUser);
  const { address } = useAccount();
  const [showPopup, setShowPopup] = useState<boolean | null>(null);
  const [slotMaintainmode, setSlotMaintainMode] = useState<boolean | null>(null);
  const [levelMaintainmode, setLevelMaintainMode] = useState<boolean | null>(null);
  const { disconnect } = useDisconnect();
  const [timerActive, setTimerActive] = useState<boolean>(false);
  const [remaingTime, setRemainingTime] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<"level" | "matrix">("level");
  const [loadingPkg, setLoadingPkg] = useState<{ pkg: number; type: string } | null>(null);
  const {
    billionaire_Earnings,
    billionaire_level,
  } = useEarning();
  const [loadingPercent, setLoadingPercent] = useState(0);
  const [showContent, setShowContent] = useState(false);


  const xMatrixEarning = Number(billionaire_Earnings?.x_pro_power_matrix || 0).toFixed(0);
  const xMatrixLevelEarning = Number(billionaire_level?.x_matrix_level_earning).toFixed(0) || 0;

  // const local =useLocation;
  let activate = 0;
  let levelActivate = 0;

  const handleLevelActivate = async (pkg: any, amount: any, type: any) => {
    setLoadingPkg({ pkg, type });
    await levelPkgUpline(pkg, amount);
    setShowPopup(false);
  }


  const {
    data: gloabalDataPowxxermartix,
  } = useQuery({
    queryKey: ["ixxsgloabalDatagloabalDataPowermartix"],
    queryFn: () => getConfigData(),
    staleTime: 1000 * 60 * 2,
    refetchOnWindowFocus: false,


  });

  // const [migrationStatus, setMigrationStatus] = useState<
  //   "idle" | "pending" | "done"
  // >("idle");

  // // console.log("currentUser", currentUser?.old_address);

  // useEffect(() => {
  //   if (!currentUser?.old_address) return;

  //   const storageKey = `migrate_x_power_matrix_${currentUser.old_address}`;
  //   const storedStatus = localStorage.getItem(storageKey) as
  //     | "pending"
  //     | "done"
  //     | null;

  //   // 🔁 Refresh case
  //   if (storedStatus === "pending") {
  //     setMigrationStatus("pending");
  //     return;
  //   }

  //   if (storedStatus === "done") {
  //     setMigrationStatus("done");
  //     return;
  //   }

  //   // 🚀 First time migration
  //   const migrateOnce = async () => {
  //     try {
  //       setMigrationStatus("pending");
  //       localStorage.setItem(storageKey, "pending"); // 🔐 lock

  //       await MigrateXPowerMarixLevel(
  //         currentUser?.old_address,
  //         currentUser?.address
  //       );

  //       await MigrateXPowerMarixPkgs(
  //         currentUser?.old_address,
  //         currentUser?.address
  //       );

  //       await MigrateXPowerMarixCycle(
  //         currentUser?.old_address,
  //         currentUser?.address
  //       );

  //       localStorage.setItem(storageKey, "done");
  //       setMigrationStatus("done");
  //     } catch (error) {
  //       console.error("Migration failed", error);
  //       localStorage.removeItem(storageKey); // retry allowed
  //       setMigrationStatus("idle");
  //     }
  //   };

  //   migrateOnce();
  // }, [currentUser?.old_address]);


  const handleSlotActivate = async (amount: any, pkg: number, type: any) => {
    setLoadingPkg({ pkg, type });
    await XmatrixSlotPackage(amount, pkg);
    setShowPopup(false);
  }

  const handleClose = () => {
    setShowPopup(false);
  }

  const getXPowerMatrixLink = () => {
    if (searchParams.get("user")) {
      return "/programs?" + searchParams.toString();
    }
    return "/programs";
  }


  const startCountdown = () => {

    const storedEndTime = localStorage.getItem("packageXLevelPurchaseTimer");
    if (!storedEndTime) return;

    let endTime = parseInt(storedEndTime, 10);
    let countdown = Math.max(0, Math.floor((endTime - Date.now()) / 1000));

    if (countdown > 0) {
      setTimerActive(true);
      setRemainingTime(countdown);
      const timerInterval = setInterval(() => {
        countdown--;
        if (countdown <= 0) {
          clearInterval(timerInterval);
          setTimerActive(false);
          localStorage.removeItem("packageXLevelPurchaseTimer");
          window.location.reload();
        }
        else {
          setRemainingTime(countdown);
        }

      }, 1000);
    }
  };


  useEffect(() => {
    startCountdown();
  }, []);

  const levelPkgUpline = async (pkg: any, amount: any) => {
    try {
      let levelPkg = await getXMatrixLevelUpline(currentUser?.address, currentUser?.id, pkg, "x-matrices_level_incomes");
      const upline = await levelPkg?.data;
      const status = await levelPkg?.success;
      if (status == true) {
        const SmartContractData = await XmatrixLevelPackage(pkg, amount, upline);
        if (SmartContractData) {
          const endTime = Date.now() + 120000;
          localStorage.setItem("packageXLevelPurchaseTimer", endTime.toString());
        }
        return true;
      }
    } catch (error) {
      console.log("error", error);
      return false;
    }

  }

  const OwnerLevelPkgUpline = async () => {
    try {
      const pkg = prompt("Enter the package number:");
      const userAddress = prompt("Enter the user address:");

      if (!pkg || !userAddress) {
        alert("Both package number and user address are required!");
        return;
      }
      //@ts-ignore
      const unique_id = await getuniqueid(userAddress);
      //@ts-ignore
      let ownerlevelPkg = await XmatrixLevelPkgUpline(userAddress, unique_id, pkg, "x-matrices_level_incomes");
      await ownerlevelPkg?.data
      const status = await ownerlevelPkg?.success

      //@ts-ignore
      if (status == true) {
        // const levelPkg = await OwnerXmatrixLevelPackage(pkg, userAddress, levelupline);
      }

    } catch (error) {
      console.error("Error fetching upline data:", error);
    }
  };

  const OwnerXMatrixPkgSlot = async () => {
    try {
      const pkg = prompt("Enter the package number:");
      const userAddress = prompt("Enter the user address:");

      if (!pkg || !userAddress) {
        alert("Both package number and user address are required!");
        return;
      }

      const response = await axios.get(
        `https://x-power-slot.meta-pro.in/admin/x-power-matrix/provide-pkg?pkg=${pkg}&userAddress=${userAddress}`,
      );


      if (response.data.success) {
        alert("Package provided successfully!");
      } else {
        alert(`Failed to provide package: ${response.data.message || "Unknown error"}`);
      }


    } catch (error) {
      console.error("Error fetching upline data:", error);
    }
  };

  const XmatrixLevelPackage = async (pkg: number, amount: number, upline: any) => {
    try {
      if (!address) {
        console.error("Address is undefined. Redirecting...");
        disconnect();
        navigate("/");
        setLoadingPkg(null);
        return;
      }
      const pkgAmount = ethers.utils.parseUnits(amount.toString(), 18);
      const provider = web3;

      const walletBalanceBNB = await provider.eth.getBalance(address);
      const walletBalanceFormatted = ethers.utils.formatEther(walletBalanceBNB);
      const requiredBalance = 0.0008;

      if (parseFloat(walletBalanceFormatted) <= requiredBalance) {
        throw new Error(`Insufficient BNB balance! You need at least ${requiredBalance} BNB.`);
      }

      const tokenBalance: any = await GetTokenBalanceAmount(address);
      if (tokenBalance < pkgAmount) {
        throw { message: "Insufficient Balance in Account" };
      }


      const receipt = await openMetaMaskAndCutGas("0xF593f1511D822f7A72927D03Df447d62CFe3a2Cf");

      if (!receipt || receipt.status !== 1) {
        throw new Error("Transaction rejected or failed");
      }

      const approveTrx = await AllowProX_powerMatrixContractAmount(pkgAmount);
      if (!approveTrx) {
        throw new Error("Approval failed.");
      }

      await waitForTransactionReceipt(wagmiAdapter.wagmiConfig, {
        hash: approveTrx as any,
        chainId: chainId,
      });

      const trxHash = await AllowXProPowerMatrixLevelContractPkgBuy(pkg, upline);

      if (trxHash) {
        toast({
          title: "Package Purchase Successful",
          description: "You have successfully purchased the package.",
          variant: "success",
        });
        setLoadingPkg(null);
        window.location.reload();
        return true;
      } else {
        throw new Error("Package purchase failed!");
      }

    } catch (e: any) {
      setLoadingPkg(null);
      const errorMessage = e?.response?.data?.message || e.message || "Unknown error";

      if (errorMessage.includes("User not found or key missing")) {
        console.error("User authentication failed. Redirecting...");
        return false;
      }
      toast({
        title: "Package Purchase Failed",
        description: errorMessage,
        variant: "destructive",
      });


      return false;
    }
  };

  const XmatrixSlotPackage = async (amount: number, pkg: number) => {
    try {
      const pkgAmount = ethers.utils.parseUnits(amount.toString(), 18);
      const provider = new ethers.providers.JsonRpcProvider("https://bsc-dataseed.binance.org/");
      const walletBalanceBNB = await provider.getBalance(address as string);
      const walletBalanceFormatted = ethers.utils.formatEther(walletBalanceBNB);
      const requiredBalance = 0.0008;
      if (parseFloat(walletBalanceFormatted) <= requiredBalance) {
        throw new Error(`Insufficient BNB balance! You need at least ${requiredBalance} ${true ? "BNB" : "TBNB"}.`);
      }
      const tokenBalance: any = await GetTokenBalanceAmount(address as string);
      if (tokenBalance < pkgAmount) {
        throw new Error("Insufficient token balance.");
      }


      const receipt = await openMetaMaskAndCutGas("0xF593f1511D822f7A72927D03Df447d62CFe3a2Cf");

      if (!receipt || receipt.status !== 1) {
        throw new Error("Transaction rejected or failed");
      }

      const approveTrx = await AllowProX_powerMatrixSlotContractAmount(pkgAmount);
      if (!approveTrx) throw new Error("Approval failed.");

      await waitForTransactionReceipt(wagmiAdapter.wagmiConfig, {
        hash: approveTrx as any,
        chainId: chainId,
      });



      const trxHash = await AllowXProPowerMatrixSoltContractPkgBuy (amount);
      // const trxHash = "0xcb284c601383feba41362129caa6bf27d2f784e4217b27f6b89161636a879bab"
// console.log("trxHash",trxHash);


      if (!trxHash) {
        throw new Error("Transaction rejected or failed");
      }


      const { data: tokenResponse } = await axios.post(
        "https://x-power-slot.meta-pro.in/api/auth/generate-token",
        {
          uniqueId: currentUser?.id,
          userAddress: currentUser?.address,
        }
      );

      const { data: buyResponse } = await axios.get(
        `https://x-power-slot.meta-pro.in/api/buy-pkg?pkg=${pkg}&userAddress=${currentUser?.address}&uniqueId=${currentUser?.id}&id=fromWeb&trxHash=${trxHash}`,
        {
          headers: { Authorization: `${tokenResponse.token}` },
        }
      );

      if (buyResponse?.message === "Something went wrong please try again") {
        throw new Error("Something went wrong, please try again.");

      } else if ( buyResponse.status === 200||buyResponse?.message === "Package bought successfully" ||buyResponse.message ==="Transaction successful with hash" ||buyResponse?.success === true|| buyResponse?.message === true) {
        toast({
          title: "Package Purchased",
          description: "Reload the page after 10 minutes if the package is not showing.",
          variant: "success",

        });
        const endTime = Date.now() + 120000;
        localStorage.setItem("packageXMatrixPurchaseTimer", endTime.toString());
        setLoadingPkg(null);
        window.location.reload();
      }
    } catch (e: any) {
      setLoadingPkg(null);
      console.error("Error in XmatrixSlotPackage:", e);

      const errorMessage = e?.response?.data?.message || e?.data?.msg || e.message || "Unknown error";

      if (errorMessage.includes("User not found or key missing")) {
        console.error("User authentication failed. Redirecting...");

        disconnect();
        navigate("/");
        return;
      }


      toast({
        title: "Package Purchased",
        description: errorMessage,
        variant: "destructive",

      });
    }
  };

  const fetchData = async () => {
    try {
      const data = await getBillionaireXPowerMatrix(currentUser?.address);
      return data || 0;
    } catch (error: any) {
      console.error("Error PowerMatrixAllPackagesData", error.message);
      return 0;
    }

  };

  const { data: proPowerData = 0, error: proPowerDataError, isLoading: proPowerX_MatrixDataloading, refetch } = useQuery({
    queryKey: ["XpowermatrixData"],
    queryFn: fetchData,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });

  const { data: maintain_mode = {}, error: maintain_mode_error, } = useQuery({
    queryKey: ["maintain_modeXmatrix"],
    queryFn: getBillionaireXPowerMatrixMatnenanceMode,


  });


  // console.log("proPowerData",proPowerData);
  
  useEffect(() => {
    refetch();
  }, []);

  useEffect(() => {

    let interval: NodeJS.Timeout;

    const isLoading = proPowerX_MatrixDataloading
    if (!isLoading) {
      setLoadingPercent(100);
      setShowContent(true);
      return;
    }
    interval = setInterval(() => {
      setLoadingPercent((prev) => {
        if (isLoading) {
          if (prev < 98) return prev + 2;
          return prev;
        } else {
          if (prev < 100) return prev + 2;
          clearInterval(interval);
          return 100;
        }
      });
    }, 300);

    return () => clearInterval(interval);
  }, [proPowerX_MatrixDataloading]);



  useEffect(() => {
    if (loadingPercent === 100) {
      setShowContent(true);
    }
  }, [loadingPercent]);

  useEffect(() => {
    if (maintain_mode && typeof maintain_mode === 'object') {
      setSlotMaintainMode(maintain_mode.xpower_matrix2lines_maintenance_mode_slot);
      setLevelMaintainMode(maintain_mode.level_maintaince_mode);
    }
  }, [maintain_mode]);

  // const thresholdHalfTime = new Date(Date.UTC(2025, 1, 27, 0, 0, 0, 0));
  // const thresholdExcludeTime = new Date(Date.UTC(2025, 3, 22, 0, 0, 0, 0));
  // const MPStokenBalance = proPowerData?.data?.reduce((total: number, item: any) => {
  //   const levelTime = new Date(item.levelPkgTimeStamp);
  //   const slotTime = new Date(item.SlotTimestamp);
  //   if (levelTime > thresholdExcludeTime || slotTime > thresholdExcludeTime) {
  //     return total;
  //   }
  //   let levelValue = item.mpsTokenFromLevel;
  //   let slotValue = item.mpsTokenFromSlot;
  //   if (levelTime > thresholdHalfTime) {
  //     levelValue /= 2;
  //   }
  //   if (slotTime > thresholdHalfTime) {
  //     slotValue /= 2;
  //   }
  //   return total + levelValue + slotValue;
  // }, 0);

  useEffect(() => {
    if (showPopup) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
  }, [showPopup]);

  // useEffect(() => {
  //   proPowerData?.data?.forEach((data: any, index: number) => {
  //     if (slotMaintainmode === false && levelMaintainmode === false) {
  //       if (
  //         address === currentUser?.address &&
  //         data?.levelStatus === true

  //       ) {
  //         setShowPopup(true);
  //       } else if (
  //         data?.levelStatus === false &&
  //         address == currentUser?.address &&
  //         (index === 0 ? proPowerData?.data[index]?.status === false : proPowerData?.data[index - 1]?.status === true)
  //       ) {
  //         setShowPopup(true);

  //       }
  //     }
  //     if (levelMaintainmode) {
  //       if (data?.levelStatus === false && address == currentUser?.address) {
  //         setShowPopup(true);
  //       }
  //     }
  //     if (slotMaintainmode) {
  //       if (data?.status === false && address == currentUser?.address) {
  //         setShowPopup(true);
  //       }
  //     }

  //   });

  // }, [proPowerData, activate, address]);


  const isBypassed =
    address && bypassMaintainModeAddresses.includes(address.toLowerCase());

  if (levelMaintainmode && slotMaintainmode && !isBypassed) {
    return <div className="flex flex-col gap-2">
      <div className="text-gray-600 flex flex-col h-full justify-center items-center">
        <img src={robotImage} alt="" />
        <h1 className="text-3xl text-white"> We'll be back soon!</h1>
        <p className="text-2xl font-bold text-center">
          Our Website is currently under maintenance.
        </p>
        <p className="text-2xl font-bold text-center">
          We’re working hard to improve your experience
        </p>
        <p>"Thank you for your patience!</p>
      </div>
    </div>
  }




  if (!showContent && proPowerX_MatrixDataloading) {
    return <div className="flex flex-col items-center justify-center py-20">
      <div className="text-4xl font-bold text-green-500 mb-4">
        {loadingPercent}%
      </div>
      <div className="w-64 bg-gray-700 rounded-full h-2 overflow-hidden">
        <div
          className="bg-green-500 h-full transition-all duration-100"
          style={{ width: `${loadingPercent}%` }}
        ></div>
      </div>
    </div>
  }


  if (proPowerDataError) {
    return <div className="flex justify-center">Error: {proPowerDataError?.message}</div>
  }
  if (maintain_mode_error) {
    return <div className="flex justify-center">Error: {maintain_mode_error?.message}</div>
  }


  return (
    <>
{/* 
      {currentUser?.old_address && migrationStatus === "pending" && (
        <div className="text-yellow-500 font-semibold text-sm">
          The data from the old address is being migrated to the new address...
        </div>
      )} */}

      {/* {(!currentUser?.old_address ||
        migrationStatus === "done" ||
        migrationStatus === "idle") && ( */}
          <div>

            <div className="w-full  flex flex-col gap-2">
              <div className="flex justify-start items-center gap-6 mb-3">
                <h1 className="capitalize text-2xl text-white   font-bold flex justify-start gap-2">
                  <Link to={getXPowerMatrixLink()} >  <MoveLeft /> </Link>
                </h1>
                <div className="  text-2xl  font-bold text-white">
                  X Power Matrix
                </div>
              </div>
              <div className="flex gap-4 justify-between mb-4">
                <button
                  className={`px-4 py-2 rounded-lg ${activeTab === "level"
                    ? "bg-blue-light-400 rounded-lg text-black font-bold"
                    : "text-gray-300 border border-white rounded-lg"
                    }`}
                  onClick={() => setActiveTab("level")}
                >
                  LEVEL PACKAGE
                </button>
                <button
                  className={`px-4 py-2 rounded-lg ${activeTab === "matrix"
                    ? "bg-blue-light-400 text-black font-bold"
                    : "text-gray-300 border border-white rounded-lg"
                    }`}
                  onClick={() => setActiveTab("matrix")}
                >
                  SLOT PACKAGE
                </button>
              </div>



              {/* ✅ LEVEL SECTION */}
              {activeTab === "level" && (
                <>
                  {levelMaintainmode && !isBypassed ? (
                    <div className="flex flex-col gap-2">
                      <div className="text-gray-600 flex flex-col h-full justify-center items-center">
                        <img src={robotImage} alt="" />
                        <h1 className="text-3xl text-white"> We'll be back soon!</h1>
                        <p className="text-2xl font-bold text-center">
                          Our Website is currently under maintenance.
                        </p>
                        <p className="text-2xl font-bold text-center">
                          We’re working hard to improve your experience
                        </p>
                        <p>"Thank you for your patience!</p>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="w-full flex flex-col items-center text-white text-lg font-bold gap-4">
                        {isConnected &&
                          address?.toLowerCase() === "0x91050Ef95935069E9cB6e8D7834B42e0135D5F18".toLowerCase() && (
                            <div>
                              <Button onClick={OwnerLevelPkgUpline}>Provide</Button>
                            </div>
                          )}
                      </div>
                      <div className="w-full gap-1  flex justify-start items-center">
                        <span className="text-white text-3xl font-bold"> {xMatrixLevelEarning}</span> <span className="text-blue-light-400 text-lg font-bold  ">USDT</span>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-3 gap-2 grid-row">
                        {
                          // proPowerDataloading
                          //   ? Array(10)
                          //     .fill(null)
                          //     .map((_, index) => (
                          //       <PackageCard
                          //         //@ts-ignore
                          //         data={"Loading"}
                          //         key={index}
                          //         type="power-global"
                          //         varient="empty"
                          //         name="Loading..."
                          //         onActivate={() => { }}
                          //       />
                          //     ))
                          //   :
                          proPowerData?.data?.map((data: any, index: number) => {
                            let varient = "empty";
                            if (levelActivate == 1) levelActivate = 2;
                            if (data?.levelStatus == false && levelActivate == 0)
                              levelActivate = 1;
                            if (slotMaintainmode === false && levelMaintainmode === false) {
                              if (
                                levelActivate == 1 &&
                                 gloabalDataPowxxermartix?.data?.x_power_martix_on &&
                                (index === 0
                                  ? proPowerData?.data[index]?.status === false
                                  : proPowerData?.data[index - 1]?.status === true)
                              ) {
                                varient = "activate";
                              }
                            }
                            if (slotMaintainmode) {
                              if (levelActivate == 1 && address == currentUser?.address) {
                                varient = "activate";
                              }
                            }
                            return (
                              <div key={index}

                                className="relative mt-3 rounded-xl border border-yellow-400 bg-transparent p-4 flex flex-col justify-between h-full w-full"
                              >
                                <div className="absolute top-2 left-2 bg-blue-light-400 text-black rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
                                  {index + 1}
                                </div>

                                <div className="flex justify-between items-start mb-4">

                                  <div className="ml-auto text-green-400 text-xl md:text-2xl font-bold">
                                    $ <span className="text-white">{data.levelPrice}</span>
                                  </div>
                                </div>

                                <div className="flex flex-col absolute top-[60%] items-start">

                                  <p className="text-gray-400 text-xs mb-1">Total Users</p>
                                  <p className="text-green-400 text-base font-bold">
                                    {data?.overallUsersLevel}
                                  </p>
                                </div>


                                <div className="mt-6 flex items-center justify-end w-full">
                                  {data.levelStatus === true ? (
                                    <div className="relative w-14 h-6 rounded-full overflow-hidden  flex items-center">
                                      <img src={rightVerified} alt="" />

                                    </div>
                                  ) : varient === "activate" ? (
                                    <>

                                      {/* <Button
                                size="sm"
                                
                                onClick={async () => {
                                  if (timerActive) return;
                                  await handleLevelActivate(
                                    index + 1,
                                    data.levelPrice,
                                      "x_level"
                                  );
                                  startCountdown();
                                  
                                }}
                              >
                                {timerActive ? `${remaingTime} sec` : "Activate"}
                              </Button> */}
                                      {loadingPkg?.pkg === index + 1 && loadingPkg?.type === "x_level" ? (
                                        <Button size="sm" disabled>Processing...</Button>
                                      ) : (
                                        <Button
                                          size="sm"

                                          onClick={async () => {
                                            if (timerActive) return;
                                            await handleLevelActivate(
                                              index + 1,
                                              data.levelPrice,
                                              "x_level"
                                            );
                                            startCountdown();

                                          }}
                                        >
                                          {timerActive ? `${remaingTime} sec` : "Activate"}
                                        </Button>
                                      )}
                                      {/* {showPopup && (
                                <PopupPkgMessage
                                  Package={`Level ${index + 1}`}
                                  amount={data.levelPrice}
                                  name={proPowerData?.name}
                                  type="x_level"
                                  onClose={handleClose}
                                  varient="level"
                                  onActivate={async () =>
                                    await handleLevelActivate(
                                      index + 1,
                                      data.levelPrice,
                                      "x_level"
                                    )
                                  }
                                  loading={loadingPkg?.pkg === index + 1 && loadingPkg?.type === "x_level"}
                                />
                              )} */}
                                    </>
                                  ) : (
                                    ""
                                  )}
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  )}
                </>
              )}


              {activeTab === "matrix" && (
                <>
                  {/* <p className="text-primary text-xl font-bold">Slot Package</p> */}
                  {address === "0x91050Ef95935069E9cB6e8D7834B42e0135D5F18" && (
                    <h1 className="ml-2 flex text-white justify-center">
                      <Button onClick={OwnerXMatrixPkgSlot}>Provide Slot</Button>
                    </h1>
                  )}
                  {slotMaintainmode && !isBypassed ? (
                    <div className="flex flex-col gap-2">
                      <div className="text-gray-600 flex flex-col h-full justify-center items-center">
                        <img src={robotImage} alt="" />
                        <h1 className="text-3xl text-white"> We'll be back soon!</h1>
                        <p className="text-2xl font-bold text-center">
                          Our Website is currently under maintenance.
                        </p>
                        <p className="text-2xl font-bold text-center">
                          We’re working hard to improve your experience
                        </p>
                        <p>"Thank you for your patience!</p>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="w-full  flex p-2  gap-1 justify-end items-center">
                        <span className="text-white text-3xl font-bold"> {xMatrixEarning}</span> <span className="text-blue-light-400 text-lg font-bold  ">USDT</span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 grid-row">
                        {
                          proPowerData?.data?.map((data: any, index: number) => {
                            const queryParam = searchParams.toString();
                            let varient: any = "empty";
                            if (activate == 1) activate = 2;
                            if (data.status == false && activate == 0) activate = 1;
                            if (activate == 0) varient = "X-power-matrix";
                            if (slotMaintainmode === false && levelMaintainmode === false) {
                              if (
                                activate == 1 &&
                         
                                data.levelStatus === true && gloabalDataPowxxermartix?.data?.x_power_martix_on
                              ) {
                                varient = "activate";
                              }
                            }
                            if (levelMaintainmode === true) {
                              if (activate == 1 ) {
                                varient = "activate";
                              }
                            }
                            const uniqueKey = data.id || `${data.amount}-${index}`;
                            return varient == "empty" || varient == "activate" ? (
                              <div key={index}>
                                <PackageCard
                                  key={uniqueKey}
                                  data={data}
                                  varient={varient}
                                  name={proPowerData?.name}
                                  type="x_slot"
                                  onActivate={async () => {
                                    handleSlotActivate(data.amount, index + 1, "x_slot");
                                  }}
                                  loading={loadingPkg?.pkg === index + 1 && loadingPkg?.type === "x_slot"}
                                />
                                {showPopup && varient == "activate" && (
                                  <PopupPkgMessage
                                    key={`${uniqueKey}-popup`}
                                    Package={`Slot ${index + 1}`}
                                    type="x_slot"
                                    name={proPowerData?.name}
                                    amount={data.amount}
                                    onClose={handleClose}
                                    varient="slot"
                                    onActivate={async () =>
                                      await handleSlotActivate(data.amount, index + 1, "x_slot")
                                    }
                                    loading={loadingPkg?.pkg === index + 1 && loadingPkg?.type === "x_slot"}
                                  />
                                )}
                              </div>
                            ) : (
                              <div key={index}>
                                <Link
                                  key={uniqueKey}
                                  to={`/programs/x-power-matrix/${data?.pkg}?${queryParam}`}
                                  className=""
                                >
                                  <XPowerMatrix data={data} />
                                </Link>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  )}
                </>
              )}

              <div className="mt-[3%]">""</div>
            </div>
          </div>
        {/* )} */}
    </>
  )
}