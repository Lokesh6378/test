

import { useSelector } from "react-redux";
import { getProgramStatusGlobal, getProgramStatusMatrix } from "../../../apis/programs/main";
import { useQuery } from "@tanstack/react-query";
import { BsCurrencyDollar } from "react-icons/bs";
import { getInvestorMillionaire } from "../../../apis/investor/main";
import { useEffect, useState } from "react";
import { useEarning } from "../../../hooks/earning";
export default function Millionaire() {
  const {
    millionaire_Earnings,
    millionaire_level,
    loader
  } = useEarning();
  const [loadingPercent, setLoadingPercent] = useState(0);
  const [showContent, setShowContent] = useState(false);
  const totalTeamDataMatrix =
    Number(millionaire_Earnings?.["pro-power-matrix"] || 0) +
    Number(millionaire_level?.matrix_level_earning || 0);

  const totalTeamData =
    Number(millionaire_Earnings?.["pro-power-global"] || 0) +
    Number(millionaire_level?.global_level_earning || 0);

  const totalEarnings = totalTeamDataMatrix + totalTeamData;

  const currentUser = useSelector((state: any) => state.global.currentUser);
  const { data: proPowerData, isLoading: proPowerGlobalDataloading } = useQuery({
    queryKey: ["proPowerDataGlobal"],
    queryFn: () => getProgramStatusGlobal(currentUser?.address),
    refetchOnWindowFocus: false,
    enabled: !!currentUser?.address,
        staleTime: 1000 * 60 * 2,
    
  });


  const { data: proPowerDataMAtrix, isLoading: proPowerDataloading } = useQuery({
    queryKey: ["proPowerDataMatrix"],
    queryFn: () => getProgramStatusMatrix(currentUser?.address),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!currentUser?.address,
        staleTime: 1000 * 60 * 2,
  });


  const { data: millionaireinvestor, isLoading: millionaireinvestorloading } = useQuery({
    queryKey: ["millionaireinvestor"],
    queryFn: () => getInvestorMillionaire(),
    refetchOnWindowFocus: false,
        staleTime: 1000 * 60 * 2,
  });




  const data = proPowerDataMAtrix?.data?.filter((item: any) => item.status === true) || [];
  const totalMatrix = data.reduce((sum: number, item: any) => sum + (item?.amount || 0), 0);
  const dataGlobal = proPowerData?.data?.filter((item: any) => item.status === true) || [];
  const totalglobal = dataGlobal.reduce((sum: number, item: any) => sum + (item?.amount || 0), 0);  
  const lotal = totalMatrix + totalglobal;


  useEffect(() => {

    let interval: NodeJS.Timeout;

    const isLoading = millionaireinvestorloading || proPowerDataloading || proPowerGlobalDataloading || loader?.MillionaireEarningLoader || loader?.MillionaireLevelLoader
    if (!isLoading) {
      setLoadingPercent(100);
      setShowContent(true);
      return;
    }
    interval = setInterval(() => {
      setLoadingPercent((prev) => {
        if (isLoading) {
          if (prev < 98) return prev + 2;
          return prev;
        } else {
          if (prev < 100) return prev + 2;
          clearInterval(interval);
          return 100;
        }
      });
    }, 500);

    return () => clearInterval(interval);
  }, [millionaireinvestorloading, proPowerDataloading, proPowerGlobalDataloading, loader?.MillionaireLevelLoader, loader?.MillionaireEarningLoader]);



  useEffect(() => {
    if (loadingPercent === 100) {
      setShowContent(true);
    }
  }, [loadingPercent]);


  // const sortedInvestors = Array.isArray(millionaireinvestor?.data)
  // ? [...millionaireinvestor?.data].sort(
  //     (a: any, b: any) => b?.totalEarnings - a?.totalEarnings
  //   )
  // : [];

  const sortedInvestors = Array.isArray(millionaireinvestor?.data)
  ? millionaireinvestor?.data.sort((a: any, b: any) => {
      const depositedA = Number(a?.totalInvestment ?? 0);
      const depositedB = Number(b?.totalInvestment ?? 0);

      if (depositedB !== depositedA) {
        return depositedB - depositedA;
      }


      const earningA = Number(a?.totalEarnings ?? 0) ;
      const earningB = Number(b?.totalEarnings ?? 0) ;

      return earningB - earningA;
    })
  : [];

  

const userAddress = currentUser?.id?.trim().toLowerCase();

const userIndex = sortedInvestors.findIndex(
  (item: any) => item?.unique_id?.trim().toLowerCase() === userAddress
);

const userRank = userIndex !== -1 ? userIndex + 1 : null;


  if (!showContent &&( millionaireinvestorloading || proPowerDataloading ||  proPowerGlobalDataloading || loader?.MillionaireLevelLoader||  loader?.MillionaireEarningLoader)) {
    return <div className="flex flex-col items-center justify-center py-20">
      <div className="text-4xl font-bold text-green-500 mb-4">
        {loadingPercent}%
      </div>
      <div className="w-64 bg-gray-700 rounded-full h-2 overflow-hidden">
        <div
          className="bg-green-500 h-full transition-all duration-100"
          style={{ width: `${loadingPercent}%` }}
        ></div>
      </div>
    </div>
  }

  return (
    <div>
      <div>
        <h1 className="text-3xl text-white font-bold ">Self Capital</h1>
        <div className="overflow-x-auto rounded-lg border-2 border-yellow-600 mt-6">

          <table className="min-w-full table-auto  text-sm p-1  text-white">
            <thead className="bg-blue-light-400 text-black">
              <tr>
              <th className="text-center text-[80%] md:text-lg px-4 py-3">Rank</th>
                <th className="text-center px-4 text-[80%] md:text-lg py-3">Total Investment</th>
                <th className="text-center px-4 text-[80%] md:text-lg py-3">Total Earning</th>

              </tr>
            </thead>
            <tbody>
              <tr className=" hover:bg-gray-800 transition-all">
              <td className="text-center px-4 py-3">
                  <p className="flex justify-center  font-bold items-center text-xl">{userRank || "-"}</p>
                </td>
                <td className="text-center px-4 py-3">
                  <p className="flex justify-center  font-bold items-center text-xl"><BsCurrencyDollar className="font-bold" /><span className="text-xl">{Number(lotal).toFixed(0)}</span></p>
                </td>
                <td className="text-center px-4 py-3">
                  {/* <div className="mt-3 inline-block   px-2"> */}
                    <p className="flex justify-center text-blue-light-400 font-bold text-xl items-center"><BsCurrencyDollar /> <span className="text-xl text-blue-light-400">{Number(totalEarnings).toFixed(0)}</span></p>
                  {/* </div> */}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      {millionaireinvestor?.data?.length > 0 && (
        <div className="mt-4">
          <h1 className="text-3xl text-white font-bold ">Top Earners</h1>
          <div className="overflow-x-auto rounded-lg border border-gray-700 mt-6">
            <table className="min-w-full table-auto text-sm text-white">
              <thead className="bg-blue-light-400 text-black">
                <tr>
                  <th className="text-center text-[80%] md:text-lg px-4 py-3">Rank</th>
                  <th className="text-center text-[80%] md:text-lg px-4 py-3">ID</th>
                  <th className="text-center text-[80%] md:text-lg px-4 py-3">Invest</th>
                  <th className="text-center text-[80%] md:text-lg whitespace-nowrap px-4 py-3"> Earning</th>
                </tr>
              </thead>
              <tbody>
                {millionaireinvestor?.data
                  // ?.sort((a: any, b: any) => b.totalEarnings - a.totalEarnings)
                  .slice(0, 100)
                  .map((item: any, index: number) => (
                    <tr
                      key={item.unique_id}
                      className="border-t border-gray-700 hover:bg-gray-800 transition-all"
                    >
                      <td className="text-center px-4 py-3">{index + 1}</td>
                      <td className="text-center px-4 py-3">
                        <div className="inline-block bg-blue-400/30 border text-[#FFD700] text-[80%] md:text-lg rounded-full px-2">
                          {item?.unique_id}
                        </div>
                      </td>
                      <td className="">
                        <div className="text-center flex justify-center items-center text-lg px-4 py-3">
                          <BsCurrencyDollar />  {Number(item?.totalInvestment).toFixed(0)}
                        </div>
                      </td>
                      <td className="text-center text-blue-light-400 flex justify-center text-lg items-center px-4 py-3">
                        <BsCurrencyDollar /> {Number(item?.totalEarnings).toFixed(0)}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}