import MyLottieComponent from "../../../components/MyLottieComponent/MyLottieComponent";


export default function Trillionaire() {
  return (
    <div className="">
      <MyLottieComponent index={0} />


    </div>
  );
}
