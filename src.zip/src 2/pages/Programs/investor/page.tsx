import { useState } from "react";
import Millionaire from "./millionaire";
import Billionaire from "./billionarie";
import Trillionaire from "./trillionaire";
import { Beininh, ZgRn } from "../../../assets";


export default function InvestorTabs() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "profile" | "settings">("dashboard");

  const tabs = [
    { key: "dashboard", label: "Millionaire " },
    { key: "profile", label: "Billionaire" },
    { key: "settings", label: "Trillionaire " },
  ];





  const tabContent = {
    dashboard: <Millionaire />,
    profile: <Billionaire />,
    settings: <Trillionaire />,
  };

  return (
    <section className="text-white">
      <div className="mx-auto mt-8 bg-[#000000] rounded-2xl shadow-lg overflow-hidden">

        <div className="flex justify-around space-x-3  px-4 py-2">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as "dashboard" | "profile" | "settings")}
              className={`px-4 p-0 py-2 text-sm font-semibold transition-colors border-1 border-blue-light-400 text-black duration-300 rounded-2xl
              ${activeTab === tab.key
                  ? "text-black border-b-2 border-[#86ff00] bg-[#86ff00]"
                  : "text-gray-500 hover:text-[#86ff00]"
                }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        {
          activeTab != "settings" && (
            <div style={{
              boxShadow: '0 0 20px rgba(96, 165, 250, 1)',
            }} className=" md:hidden  flex relative mt-5 items-center rounded-xl   ">
              <h1 className="absolute top-0 flex justify-start  ml-2   text-4xl md:text-7xl font-bold text-black  ">Fuel Your Future<br />With Smart Investing</h1>
              <img src={ZgRn} alt="" className=" md:hidden absolute top-20  left-[-8%] h-[130px] rounded-2xl w-[50%]" />
              <img className=" h-[300px] md:h-[400px]  rounded-2xl w-full " src={Beininh} alt="" />
            </div>
          )
        }

        <div className="text-gray-700 gap-3 text-sm whitespace-pre-line leading-relaxed p-4">
          {tabContent[activeTab]}
        </div>

      </div>

    </section>

  );
}
