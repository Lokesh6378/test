
import { useSelector } from "react-redux";
import { getBillionaireXPowerGlobal, getBillionaireXPowerMatrix } from "../../../apis/programs/main";
import { useQuery } from "@tanstack/react-query";
import { BsCurrencyDollar } from "react-icons/bs";
import { getInvestorBillionaire } from "../../../apis/investor/main";
import { useEffect, useState } from "react";
import { useEarning } from "../../../hooks/earning";

export default function Billionaire() {
  const {
    billionaire_Earnings,
    billionaire_level,
    loader
  } = useEarning();
  const [loadingPercent, setLoadingPercent] = useState(0);
  const [showContent, setShowContent] = useState(false);
  const totalTeamDataMatrix =
    Number(billionaire_Earnings?.x_pro_power_matrix || 0) +
    Number(billionaire_level?.x_matrix_level_earning || 0);

  const totalTeamData =
    Number(billionaire_Earnings?.x_pro_power_global || 0) +
    Number(billionaire_level?.x_global_level_earning || 0);

  const totalEarnings = totalTeamDataMatrix + totalTeamData;

  const currentUser = useSelector((state: any) => state.global.currentUser);
  const { data: proPowerData, isLoading: proPowerX_Power_GlobalDataloading } = useQuery({
    queryKey: ["xPowerDataGlobalinvestor"],
    queryFn: () => getBillionaireXPowerGlobal(currentUser?.address),
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    enabled: !!currentUser?.address,
    staleTime: 1000 * 60 * 2,
  });

  const { data: proPowerDataMAtrix = 0, isLoading: proPowerX_MatrixDataloading, } = useQuery({
    queryKey: ["XpowermatrixDatainvestor"],
    queryFn: () => getBillionaireXPowerMatrix(currentUser?.address),
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    enabled: !!currentUser?.address,
    staleTime: 1000 * 60 * 2,
  });

  const { data: billionaireinvestor, isLoading: billionaireinvestorloading } = useQuery({
    queryKey: ["billionaireinvestor"],
    queryFn: () => getInvestorBillionaire(),
    refetchOnWindowFocus: false,
    staleTime: 1000 * 60 * 2,
  });



  useEffect(() => {

    let interval: NodeJS.Timeout;

    const isLoading = proPowerX_MatrixDataloading || billionaireinvestorloading || proPowerX_Power_GlobalDataloading || loader?.BillionaireEarningLoader || loader?.BillionaireLevelLoader
    if (!isLoading) {
      setLoadingPercent(100);
      setShowContent(true);
      return;
    }
    interval = setInterval(() => {
      setLoadingPercent((prev) => {
        if (isLoading) {
          if (prev < 98) return prev + 2;
          return prev;
        } else {
          if (prev < 100) return prev + 2;
          clearInterval(interval);
          return 100;
        }
      });
    }, 500);

    return () => clearInterval(interval);
  }, [proPowerX_MatrixDataloading, billionaireinvestorloading, proPowerX_Power_GlobalDataloading, loader?.BillionaireLevelLoader, loader?.BillionaireEarningLoader]);



  useEffect(() => {
    if (loadingPercent === 100) {
      setShowContent(true);
    }
  }, [loadingPercent]);


  const data = proPowerDataMAtrix?.data || [];

  const totalMatrix = data.reduce((sum: number, item: any) => {
    let itemSum = 0;
    if (item?.status === true) {
      itemSum += item?.amount ?? 0;
    }
    if (item?.levelStatus === true) {
      itemSum += item?.levelPrice ?? 0;
    }
    return sum + itemSum;
  }, 0);



  // const sortedInvestors = Array.isArray(billionaireinvestor?.data)
  // ? [...billionaireinvestor?.data].sort(
  //     (a: any, b: any) => b?.totalEarnings - a?.totalEarnings
  //   )
  // : [];


  const sortedInvestors = Array.isArray(billionaireinvestor?.data)
    ? billionaireinvestor?.data.sort((a: any, b: any) => {
      const depositedA = Number(a?.totalInvestment ?? 0);
      const depositedB = Number(b?.totalInvestment ?? 0);

      if (depositedB !== depositedA) {
        return depositedB - depositedA;
      }


      const earningA = Number(a?.totalEarnings ?? 0);
      const earningB = Number(b?.totalEarnings ?? 0);

      return earningB - earningA;
    })
    : [];

  const userAddress = currentUser?.id;
  const userIndex = sortedInvestors.findIndex(
    (item: any) => item?.unique_id
      ?.toLowerCase?.() === userAddress
  );

  const userRank = userIndex !== -1 ? userIndex + 1 : null;



  const dataGlobal = proPowerData?.data?.filter((item: any) => item.status === true) || [];
  const totalglobal = dataGlobal?.reduce((sum: number, item: any) => sum + (item?.amount || 0), 0);


  const lotal = totalMatrix + totalglobal;



  if (!showContent && (proPowerX_MatrixDataloading || proPowerX_Power_GlobalDataloading || billionaireinvestorloading || loader?.BillionaireLevelLoader || loader?.BillionaireEarningLoader)) {
    return <div className="flex flex-col items-center justify-center py-20">
      <div className="text-4xl font-bold text-green-500 mb-4">
        {loadingPercent}%
      </div>
      <div className="w-64 bg-gray-700 rounded-full h-2 overflow-hidden">
        <div
          className="bg-green-500 h-full transition-all duration-100"
          style={{ width: `${loadingPercent}%` }}
        ></div>
      </div>
    </div>
  }

  return (
    <div>
      <div>
        <h1 className="text-3xl text-white font-bold ">Self Capital</h1>
        <div className="overflow-x-auto rounded-lg border border-gray-700 mt-6">

          <table className="min-w-full table-auto text-sm border-2 border-yellow-600 text-white">
            <thead className="bg-blue-light-400 text-black">
              <tr>
                <th className="text-center text-[80%] md:text-lg px-4 py-3">Rank</th>
                <th className="text-center px-4 text-[80%] md:text-lg  py-3">Total Investment</th>
                <th className="text-center px-4 text-[80%] md:text-lg py-3">Total Earning</th>

              </tr>
            </thead>
            <tbody>
              <tr className=" hover:bg-gray-800 transition-all">
                <td className="text-center px-4 py-3">
                  <p className="flex justify-center font-bold text-xl items-center">{userRank || "-"}</p>
                </td>
                <td className="text-center px-4 py-3">
                  <p className="flex justify-center font-bold text-xl items-center"><BsCurrencyDollar />{Number(lotal).toFixed(0)}</p>
                </td>
                <td className="text-center px-4 py-3">

                  <p className="flex justify-center items-center text-xl  font-bold"><BsCurrencyDollar /><span className="text-blue-light-400"> {Number(totalEarnings).toFixed(0)}</span></p>


                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      {billionaireinvestor?.data?.length > 0 && (
        <div className="mt-4">
          <h1 className="text-3xl text-white font-bold ">Top Investor</h1>
          <div className="overflow-x-auto rounded-lg border border-gray-700 mt-6">
            <table className="min-w-full table-auto text-sm text-white">
              <thead className="bg-blue-light-400 text-black">
                <tr>
                  <th className="text-center text-[80%] md:text-lg  px-4 py-3">Rank</th>
                  <th className="text-center text-[80%] md:text-lg  px-4 py-3">ID</th>
                  <th className="text-center text-[80%] md:text-lg  px-4 py-3">Invest</th>
                  <th className="text-center text-[80%] md:text-lg   px-4 py-3">Earning</th>
                </tr>
              </thead>
              <tbody>
                {billionaireinvestor?.data
                  // ?.sort((a: any, b: any) => b?.totalEarnings - a?.totalEarnings)
                  .slice(0, 100)
                  .map((item: any, index: number) => (
                    <tr
                      key={item.unique_id}
                      className="border-t border-gray-700 hover:bg-gray-800 transition-all"
                    >
                      <td className="text-center px-4 py-3">{index + 1}</td>
                      <td className="text-center px-4 py-3">
                        <div className="inline-block bg-blue-400/30 border text-[80%] md:text-lg  text-[#FFD700] rounded-full px-2">
                          {item?.unique_id}
                        </div>
                      </td>
                      <td className="">
                        <div className="text-center flex justify-center text-lg items-center px-4 py-3">
                          <BsCurrencyDollar />  {Number(item?.totalInvestment).toFixed(0)}
                        </div>
                      </td>
                      <td className="text-center text-blue-light-400 flex justify-center text-lg items-center px-4 py-3">
                        <BsCurrencyDollar /> {Number(item?.totalEarnings).toFixed(0)}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}