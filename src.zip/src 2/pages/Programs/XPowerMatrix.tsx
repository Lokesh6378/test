"use client";
import { fillXpowerMatrixCircleColor } from "../../lib/utils";
import { Users, Recycle } from "lucide-react";

import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "../../components/ui/card/page";
import { useState } from "react";
import { useSelector } from "react-redux";
import { UserProfiles } from "../../assets";
import { BsCurrencyDollar } from "react-icons/bs";


type PackageData = {
    id: number;
    type: string | "upline" | "downline" | "working" | "";
};
type PackageProps = {
    pkg: number;
    recycle: number;
    amount: number;
    member: number;
    overallUsers: number;
    missed: boolean;
    data: Array<Array<PackageData>>;
};

export default function XPowerMatrix({
    data,
}: {
    data: PackageProps;
}) {

    const currentUser = useSelector((state: any) => state.global.currentUser);
    const [profileSrc, setProfileSrc] = useState(
        currentUser?.profile?.length > 0 ? currentUser?.profile : UserProfiles
    );
    return <Card className="border p-2 border-[#FFD700]  overflow-hidden  rounded-3xl transition-colors h-full flex flex-col justify-between">
        <CardHeader>
            <CardTitle>
                <div className="flex flex-row justify-between items-center text-white w-full   gap-4">
                    {/* Slot */}
                    <div className="bg-blue-light-400 text-black rounded-full w-10 h-10 flex items-center justify-center text-lg font-bold">
                        {data?.pkg}
                    </div>

                    {/* Center: Total Users & Current Line */}
                    <div className="flex flex-row items-center justify-center gap-4">
                        <div className="text-center">
                            <p className="text-gray-400 text-[50%] ">Total Users</p>
                            <p className="text-green-500 text-xl font-bold">{data?.overallUsers}</p>
                        </div>
                    </div>

                    {/* Amount */}
                    <div className="flex items-center gap-1 text-lg font-bold whitespace-nowrap">
            <span className="text-blue-light-400 text-2xl md:text-4xl "><BsCurrencyDollar/></span>
            <span className="ml-[-6%] text-2xl md:text-4xl ">{`${data?.amount}`}</span>
          </div>
                </div>
            </CardTitle>
        </CardHeader>

        <CardContent className="p-0 relative w-[100%] h-[100%] text-center z-0">
            <div className="">
                <svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">



                    <g transform="rotate(15,200,200)">
                        {/* <!-- Circular Arc Path for Text --> */}
                        <defs>
                            <path
                                id="circleTextPath"
                                d="M 180,80 A 150,150 0 0,1 330,200"
                                fill="none"
                            />
                        </defs>

                        {/* <!-- Circle Division --> */}
                        <path
                            d="M 200,50 A 150,150 0 0,1 350,200 L 275,200 A 75,75 0 0,0 200,125 Z"
                            fill={fillXpowerMatrixCircleColor(data?.data[1][2]?.type)}
                            stroke="black"
                            strokeWidth="5"
                        />

                        {/* <!-- Curved Text --> */}
                        <text fontSize="18" fill="black" fontWeight="bold">
                            <textPath href="#circleTextPath" startOffset="50%" textAnchor="middle">
                                {data?.data[1][2]?.id}
                            </textPath>
                        </text>
                    </g>


                    <g transform="rotate(15,200,200)">
                        {/* Arc Shape */}
                        <path
                            d="M 350,200 A 150,150 0 0,1 200,350 L 200,275 A 75,75 0 0,0 275,200 Z"
                            fill={fillXpowerMatrixCircleColor(data?.data[1][3]?.type)}
                            stroke="black"
                            strokeWidth="5"
                        />


                        <defs>
                            <path
                                id="arcTextPathRight"
                                d="M 330,210 A 200,200 0 0,1 220,330"
                                fill="none"
                            />
                        </defs>


                        <text fontSize="18" fill="black" fontWeight="bold">
                            <textPath
                                href="#arcTextPathRight"
                                startOffset="50%"
                                textAnchor="middle"
                                dominantBaseline="middle"
                            >
                                {data?.data[1][3]?.id}
                            </textPath>
                        </text>
                    </g>

                    <g transform="rotate(15,200,200)">
                        {/* Arc Shape */}
                        <path
                            d="M 200,350 A 150,150 0 0,1 50,200 L 125,200 A 75,75 0 0,0 200,275 Z"
                            fill={fillXpowerMatrixCircleColor(data?.data[1][0]?.type)}
                            stroke="black"
                            strokeWidth="5"
                        />


                        <defs>
                            <path
                                id="arcTextPathBottom"
                                d="M 180,330 A 200,200 0 0,1 70,200"
                                fill="none"
                            />
                        </defs>

                        {/* Curved Text */}
                        <text fontSize="18" fill="black" fontWeight="bold">
                            <textPath
                                href="#arcTextPathBottom"
                                startOffset="50%"
                                textAnchor="middle"
                                dominantBaseline="middle"
                            >
                                {data?.data[1][0]?.id}
                            </textPath>
                        </text>
                    </g>

                    <g transform="rotate(15,200,200)">

                        <path
                            d="M 50,200 A 150,150 0 0,1 200,50 L 200,125 A 75,75 0 0,0 125,200 Z"
                            fill={fillXpowerMatrixCircleColor(data?.data[1][1]?.type)}
                            stroke="black"
                            strokeWidth="5"
                        />
                        <defs>
                            <path
                                id="arcTextPath"
                                d="M 70,200 A 200,200 0 0,1 170,70"
                                fill="none"
                            />
                        </defs>

                        {/* Curved Text */}
                        <text fontSize="18" fill="black" fontWeight="bold">
                            <textPath
                                href="#arcTextPath"
                                startOffset="50%"
                                textAnchor="middle"
                                dominantBaseline="middle"
                            >
                                {data?.data[1][1]?.id}
                            </textPath>
                        </text>
                    </g>
                    <g transform="rotate(-30,200,200)">

                        <defs>
                            <path
                                id="innerArc"
                                d="M 130,200 A 70,70 0 0,1 270,200"
                                fill="none"
                            />
                        </defs>


                        <path
                            d="M 100,200 A 50,50 0 0,1 300,200 L 200,200 Z"
                            fill={fillXpowerMatrixCircleColor(data?.data[0][0]?.type)}
                            stroke="black"
                            strokeWidth="5"
                        />


                        <text fontSize="18" fill="black" fontWeight="bold">
                            <textPath href="#innerArc" startOffset="50%" textAnchor="middle">
                                {data?.data[0][0]?.id}
                            </textPath>
                        </text>
                    </g>
                    <g transform="rotate(-30,200,200)">

                        <path
                            d="M 300,200 A 50,50 0 0,1 100,200 L 200,200 Z"
                            fill={fillXpowerMatrixCircleColor(data?.data[0][1]?.type)}
                            stroke="black"
                            strokeWidth="5"
                        />


                        <defs>
                            <path
                                id="textPathArc"
                                d="M 280,200 A 40,40 0 0,1 120,200"
                                fill="none"
                            />
                        </defs>


                        <text fontSize="18" fill="black" fontWeight="bold">
                            <textPath
                                href="#textPathArc"
                                startOffset="50%"
                                textAnchor="middle"
                                dominantBaseline="middle"
                            >
                                {data?.data[0][1]?.id}
                            </textPath>
                        </text>
                    </g>





                    <defs>
                        <clipPath id="circleClip">
                            <circle cx="200" cy="200" r="50" />
                        </clipPath>
                    </defs>


                    {/* Center Circle */}
                    <circle cx="200" cy="200" r="50" fill="black" stroke="black" strokeWidth="3" />
                    {/* <text x="200" y="205" textAnchor="middle" fill="white" fontSize="18" fontWeight="bold">
                        You
                    </text> */}
                    <image
                        href={profileSrc}
                        x="150"
                        y="150"
                        width="100"
                        height="100"
                        clipPath="url(#circleClip)"
                        onError={() => setProfileSrc(UserProfiles)}
                    />

                </svg>
            </div>
        </CardContent>


        <CardFooter>
            <div className="flex text-white justify-between gap-3">
                <div className="flex gap-2">
                    <Users />
                    <div className="text-blue-light-400">{data?.member}</div>
                </div>
                <div className="flex text-white gap-2">
                    <Recycle /> <div className="text-blue-light-400">{data?.recycle}</div>
                </div>
            </div>
        </CardFooter>
    </Card>
}

