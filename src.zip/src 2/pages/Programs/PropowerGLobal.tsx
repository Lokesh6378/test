
import { getBackgroundOfPackageFillColor } from "../../lib/utils";
import { Users, Recycle } from "lucide-react";
import { Card, CardHeader, CardTitle, CardFooter } from "../../components/ui/card/page";
import { useSelector } from "react-redux";
import { UserProfiles } from "../../assets";
import { BsCurrencyDollar } from "react-icons/bs";
// import { useState } from "react";


type PackageData = {
    id: number;
    type: string | "upline" | "downline" | "working" | "";
};
type PackageProps = {
    pkg: number;
    recycle: number;
    amount: number;
    member: number;
    overallUsers: number;
    missed: boolean;
    data: Array<Array<PackageData>>;
};

export default function ProPowerGlobalCard({
    data,
}: {
    data: PackageProps;
}) {

    const currentUser = useSelector((state: any) => state.global.currentUser);
    // const [profileSrc, setProfileSrc] = useState(
    //     currentUser?.profile?.length > 0 ? currentUser.profile : UserProfiles
    // );

    // const profileImage = currentUser?.profile;
    const getFillColor = (value: string) => {
        return getBackgroundOfPackageFillColor(value);



    }
    const determineLine = (overallUsers: number) => {
        if (overallUsers <= 1) return " Current line-1";
        if (overallUsers <= 4) return " Current line-2";
        if (overallUsers <= 13) return " Current line-3";
        if (overallUsers <= 40) return " Current line-4";
        if (overallUsers <= 121) return " Current line-5";
        if (overallUsers <= 364) return " Current line-6";
        if (overallUsers <= 1093) return " Current line-7";
        if (overallUsers <= 3280) return " Current line-8";
        if (overallUsers <= 9841) return " Current line-9";
        if (overallUsers <= 29524) return " Current line-10";
        if (overallUsers <= 88573) return " Current line-11";
        if (overallUsers <= 265720) return " Current line-12";
        if (overallUsers <= 797161) return " Current line-13";
        if (overallUsers <= 2391484) return " Current line-14";
        if (overallUsers <= 7174453) return " Current line-15";
        return " Current line-16";
    };
    const line = determineLine(data?.overallUsers);
    const circles = [
        // Left Branch (mirrored to match Right)
        { label: "Left Main", top: 210, left: 120, dataPath: [0, 1] },
        { label: "Left 1", top: 160, left: 110, dataPath: [1, 5] },
        { label: "Left 2", top: 195, left: 70, dataPath: [1, 4] },
        { label: "Left 3", top: 250, left: 90, dataPath: [1, 3] },
      
        // Right Branch (unchanged)
        { label: "Right Main", top: 210, left: 380, dataPath: [0, 2] },
        { label: "Right 1", top: 160, left: 390, dataPath: [1, 6] },
        { label: "Right 2", top: 195, left: 430, dataPath: [1, 7] },
        { label: "Right 3", top: 250, left: 410, dataPath: [1, 8] },
      
        // Bottom Branch (unchanged)
        { label: "Bottom Main", top: 370, left: 250, dataPath: [0, 0] },
        { label: "Bottom 1", top: 410, left: 210, dataPath: [1, 2] },
        { label: "Bottom 2", top: 430, left: 250, dataPath: [1, 1] },
        { label: "Bottom 3", top: 410, left: 290, dataPath: [1, 0] },
      ];
      
const lines = [
    // Center to Left Main
    [250, 250, 120, 210],
    // Left Main to its children
    [120, 210, 110, 165],
    [120, 210, 70, 195],
    [120, 210, 90, 250],
  
    // Center to Right Main
    [250, 250, 380, 210],
    // Right Main to its children
    [380, 210, 390, 165],
    [380, 210, 430, 195],
    [380, 210, 410, 250],
  
    // Center to Bottom Main
    [250, 250, 250, 370],
    // Bottom Main to its children
    [250, 370, 210, 410],
    [250, 370, 250, 430],
    [250, 370, 290, 410],
  ];


    return <Card className="border border-[#FFD700] overflow-hidden   border-blue--300  rounded-3xl transition-colors h-full flex flex-col justify-between">
        <CardHeader>
            <CardTitle>
                <div className="flex flex-row justify-between items-center text-white w-full px-4 py-2 gap-4">
                    {/* Slot */}
                    <div className="text-xl font-bold whitespace-nowrap">
                        Slot {data?.pkg}
                    </div>

                    {/* Center: Total Users & Current Line */}
                    <div className="flex flex-row items-center justify-center gap-4">
                        <div className="text-center">
                            <p className="text-gray-400 text-[50%] ">Total Users</p>
                            <p className="text-green-500 text-lg font-bold">{data?.overallUsers}</p>
                        </div>
                        <div className="text-center">
                            <p className="text-gray-400 text-[50%] ">Current line</p>
                            <p className="text-green-500 text-lg font-bold">
                                {line.replace('Current line-', '')}
                            </p>
                        </div>
                    </div>

                    {/* Amount */}
                    <div className="flex items-center gap-1 text-lg font-bold whitespace-nowrap">
                        <span className="text-blue-light-400 text-2xl md:text-4xl "><BsCurrencyDollar /></span>
                        <span className="ml-[-6%] text-2xl md:text-4xl ">{data?.amount}</span>
                    </div>
                </div>

            </CardTitle>
        </CardHeader>
        <div className="relative w-full max-w-[500px] aspect-square  mx-auto">
            <svg
                viewBox="0 0 500 500"
                className="absolute w-full h-full"
                preserveAspectRatio="xMidYMid meet"
            >
                {/* Lines */}
                {lines.map(([x1, y1, x2, y2], i) => (
                    <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#374151" strokeWidth="4" />
                ))}

                {/* Center Circle */}
                <circle cx="250" cy="250" r="60" stroke="black" strokeWidth="10" />
                <clipPath id="clipCircle">
                    <circle cx="250" cy="250" r="45" />
                </clipPath>
                <image
                    // href={UserProfiles}
                    href={
                        currentUser?.profile && currentUser.profile.length > 0
                            ? currentUser.profile
                            : UserProfiles
                    }
                    x="205"
                    y="205"
                    width="90"
                    height="90"
                    clipPath="url(#clipCircle)"
                    preserveAspectRatio="xMidYMid slice"
                // style={{ filter: "invert(1)" }}
                />



                {/* Other Circles + Labels */}
                {circles.map((c, i) => {
                    // console.log("data", data);

                    const isMain = c.label.includes("Main");
                    const node = c.dataPath ? data?.data?.[c.dataPath[0]]?.[c.dataPath[1]] : null;


                    const type = node?.type || "";
                    const id = node?.id || "";

                    const fill = type && getFillColor(type);
                    // console.log(type, fill, id);
                    return (
                        // 
                        <g key={i}>
                            <text
                                x={c.left}
                                y={c.top - (isMain ? 30 : 25)}
                                textAnchor="middle"
                                fontSize="10"
                                fill="white"
                                opacity="0"
                                className="hover-label pointer-events-none"
                            >
                                {id || ""}
                            </text>

                            <circle
                                cx={c.left}
                                cy={c.top}
                                r={isMain ? 20 : 15}
                                fill={fill || '#4b4e52'}

                            />
                        </g>

                    );
                })}



            </svg>

            <style>{`
        svg g:hover text {
          opacity: 1;
        }
      `}</style>
        </div>
        <CardFooter>
            <div className="flex text-white justify-between gap-3">
                <div className="flex gap-2">
                    <Users /> 
                    <div className="text-blue-light-400">{data?.member}</div>
                </div>
                <div className="flex  gap-2 ">
                     
                    <Recycle />   <div className="flex  gap-2 text-blue-light-400"> {data?.recycle}</div>
                </div>
            </div>
        </CardFooter>
    </Card>
} 