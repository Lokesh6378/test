import { useState, useEffect } from "react";
import { dashboardPlanData } from "../../config/data";
import { useQuery } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import {
  getAllStatusAddress,
  getTotalActiveBillionaire,
  getTotalActiveMillionaire,
  getTotalInactiveBillionaire,
  getTotalInactiveMillionaire,
  getTotalTeam,
  getUserMultiStatus,
} from "../../apis/dashboard/main";

import ProgramCard from "./ProgramsCard";

import ModalBox from "../../components/ui/modal/totalTeamData";
import { getuniqueid } from "../../lib/smartContract";
import { getUserBillionaireList, getUserMillionaireList } from "../../apis/programs/main";
import { getMultipleTimer } from "../../apis/timer/main";

// import { MoveLeft } from "lucide-react";

const unitLabels: Record<string, string> = {
  days: "Days",
  hours: "Hrs",
  minutes: "Min",
  seconds: "Sec",
};

export default function ProgramsList() {
  const [activePlanTab, setActivePlanTab] = useState<"MILLIONAIRE" | "BILLIONAIRE" | "TRILLIONAIRE">("TRILLIONAIRE");
  const [modalPage, setModalPage] = useState(1);
  const [modalTotalPages, setModalTotalPages] = useState(1);
  const [modalType, setModalType] = useState<"MILLIONAIRE" | "BILLIONAIRE" | null>(null);
  const [modalStatus, setModalStatus] = useState<"Active" | "Inactive" | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  const [modalData, setModalData] = useState<any[]>([]);
  const [modalMode, setModalMode] = useState<"team" | "partner">("team");
  const [loadingPercent, setLoadingPercent] = useState(0);
  const [modalDataCache, setModalDataCache] = useState<Record<string, any[]>>({});
  const [partnerCache, setPartnerCache] = useState<any>({});
  const [timeLeftpre, setTimeLeftpre] = useState<{ days: number; hours: number; minutes: number; seconds: number } | null>(null);
  const [timerTextpre, setTimerTextpre] = useState('');
 
  const {
    data: timerData,
  } = useQuery({
    queryKey: ["isgloabalDatamps_token_time_trill"],
    queryFn: () => getMultipleTimer(),
    staleTime: 1000 * 60 * 2,
    refetchOnWindowFocus: false,
  });

  const getCacheKey = (type: string, status: string, mode: string, page: number) =>
    `${type}_${status}_${mode}_${page}`;
  const currentUser: any = useSelector((state: any) => state.global?.currentUser);
//   const oldAddress =
//   currentUser?.old_address ||
//   currentUser?.address ||
//   null;

// const oldUniqueId =
//   currentUser?.old_unique_id ||
//   currentUser?.uniqueId ||
//   null;
 
  const {
    data: totalTeamData,
} = useQuery({
    queryKey: ['totalTeamDataww',currentUser?.address, currentUser?.id],
    queryFn: () => getTotalTeam(currentUser?.address, currentUser?.id),
    enabled: !!currentUser?.address|| !!currentUser?.id,
    refetchOnWindowFocus: false,
    staleTime: 1000 * 60 * 2,

});
   
// console.log("currentUser.address",currentUser?.old_address);

  const { data: activeProgram = {},isLoading:getAllprogramLoading,refetch } = useQuery({
    queryKey: ["programStatus", currentUser?.address],
    queryFn: () => getAllStatusAddress(currentUser?.address),
    enabled: !!currentUser?.address,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });


  useEffect(() => {
    if (activeProgram) {
        refetch();
    }
}, [activeProgram]);


useEffect(() => {
  if (!(timerData?.success && Array.isArray(timerData?.data) && timerData.data[0]?.upcomming_programe)) {
    return;
  }
  let interval: NodeJS.Timeout | null = null;
  const activeProgramName = "Trillionaire Timer";
  const found = timerData.data[0].upcomming_programe.find(
    (prog: any) => prog?.programName?.trim() === activeProgramName
  );
  if (found) {
    setTimerTextpre(found?.tag);
    const targetTime = new Date(found?.time).getTime();
    const updateTimer = () => {
      const now = Date.now();
      const diff = targetTime - now;
      if (diff <= 0) {
        setTimeLeftpre(null);
        if (interval) clearInterval(interval);
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      setTimeLeftpre({ days, hours, minutes, seconds });
    };

    updateTimer();
    interval = setInterval(updateTimer, 1000);
  }

  return () => {
    if (interval) clearInterval(interval);
  };
}, [timerData]);

  useEffect(() => {
        
    let interval: NodeJS.Timeout;

    const isLoading = getAllprogramLoading 
    if(!isLoading) {
        setLoadingPercent(100);
        setShowContent(true);
        return;
    }
    interval = setInterval(() => {
        setLoadingPercent((prev) => {
            if (isLoading) {
                if (prev < 98) return prev + 2;
                return prev;
            } else {
                if (prev < 100) return prev + 2;
                clearInterval(interval);
                return 100;
            }
        });
    }, 300);

    return () => clearInterval(interval);
}, [ getAllprogramLoading]);





  const { data: millionairePartners, isLoading: millionaireLoading } = useQuery({
    queryKey: ["millionairePartners", currentUser?.address],
    queryFn: () => getUserMillionaireList(currentUser?.address),
    enabled: !!currentUser?.address,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });

  const { data: billionairePartners, isLoading: billionaireLoading } = useQuery({
    queryKey: ["billionairePartners", currentUser?.address],
    queryFn: () => getUserBillionaireList(currentUser?.address),
    enabled: !!currentUser?.address,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });

  useEffect(() => {
    if (millionairePartners && billionairePartners) {
      setPartnerCache({
        MILLIONAIRE: millionairePartners,
        BILLIONAIRE: billionairePartners,
      });
    }
  }, [millionairePartners, billionairePartners]);

  const partnersReady =!!partnerCache.MILLIONAIRE?.ActiveUsers && !!partnerCache.BILLIONAIRE?.ActiveUsers;
  const [showContent, setShowContent] = useState(false);

useEffect(() => {
  let interval: NodeJS.Timeout;
  if(partnersReady){
    setLoadingPercent(100);
    setShowContent(true);
    return;
  }
  const isLoading = !partnersReady || millionaireLoading || billionaireLoading;

  interval = setInterval(() => {
    setLoadingPercent((prev) => {
      if (isLoading) {
        if (prev < 98) return prev + 2; 
        return prev;
      } else {
        if (prev < 100) return prev + 2;
        clearInterval(interval);
        return 100;
      }
    });
  }, 1000);

  return () => clearInterval(interval);
}, [partnersReady, millionaireLoading, billionaireLoading]);

useEffect(() => {
  if (loadingPercent === 100) {
    setShowContent(true);
  }
}, [loadingPercent]);

  

  const PARTNER_PAGE_LIMIT = 25;
  const fetchModalData = async (
    type: "MILLIONAIRE" | "BILLIONAIRE",
    status: "Active" | "Inactive",
    page: number,
    mode: "team" | "partner"
  ) => {
    const cacheKey = getCacheKey(type, status, mode, page);

    if (modalDataCache[cacheKey]) {
      setModalData(modalDataCache[cacheKey]);
      return;
    }

    setModalData([]);
    try {
      let dataForPage: any[] = [];

      if (mode === "partner") {
        const partnerData = partnerCache[type];
        if (!partnerData) return;

        const list =
          status === "Active"
            ? partnerData?.ActiveUsers || []
            : partnerData?.InactiveUsers || [];
        const start = (page - 1) * PARTNER_PAGE_LIMIT;
        const end = start + PARTNER_PAGE_LIMIT;
        const pageSlice = list.slice(start, end);
        const addresses = pageSlice.map((u: any) => u.address);
        const statusResponse = await getUserMultiStatus(addresses);
        const dataArray = statusResponse || [];
        dataForPage = pageSlice.map((item: any, i: number) => ({
          uniqueId: item.unique_id,
          address: item.address,
          proPowerMatrix: dataArray[i]?.["pro-power-matrix"],
          proPowerGlobal: dataArray[i]?.["pro-power-global"],
          xPowerMatrix: dataArray[i]?.["x-power-matrix"],
          xPowerGlobal: dataArray[i]?.["x-power-global"],
        }));

        setModalTotalPages(Math.ceil(list.length / PARTNER_PAGE_LIMIT));
      } else {
        let addressData: any = null;
        if (type === "MILLIONAIRE") {
          addressData =
            status === "Active"
              ? await getTotalActiveMillionaire(currentUser?.address, page)
              : await getTotalInactiveMillionaire(currentUser?.address, page);
        } 
        else {
          addressData =
            status === "Active"
              ? await getTotalActiveBillionaire(currentUser?.address, page)
              : await getTotalInactiveBillionaire(currentUser?.address, page);
        }

        const addressList = addressData?.data || [];
        const pagination = addressData?.pagination || {};
        setModalPage(pagination.currentPage || 1);
        setModalTotalPages(pagination.totalPages || 1);

        const response = await getUserMultiStatus(addressList);
        const dataArray = response || [];

        dataForPage = await Promise.all(
          addressList.map(async (address: string, i: number) => {
            const uniqueId = await getuniqueid(address as any);
            return {
              uniqueId,
              address,
              proPowerMatrix: dataArray[i]?.["pro-power-matrix"],
              proPowerGlobal: dataArray[i]?.["pro-power-global"],
              xPowerMatrix: dataArray[i]?.["x-power-matrix"],
              xPowerGlobal: dataArray[i]?.["x-power-global"],
            };
          })
        );
      }

      setModalDataCache((prev) => ({
        ...prev,
        [cacheKey]: dataForPage,
      }));
      setModalData(dataForPage);
    } catch (err) {
      console.error("Error fetching modal data", err);
      setModalData([]);
    }
  };

  const handleShowModal = (
    type: "MILLIONAIRE" | "BILLIONAIRE",
    status: "Active" | "Inactive",
    mode: "team" | "partner"
  ) => {
    const page = 1;
    const cacheKey = getCacheKey(type, status, mode, page);

    setModalTitle(`${type} (${status} ${mode === "partner" ? "Partners" : "Members"})`);
    setIsModalOpen(true);
    setModalType(type);
    setModalStatus(status);
    setModalMode(mode);
    setModalPage(page);

    if (modalDataCache[cacheKey]) {
      setModalData(modalDataCache[cacheKey]);
    } else {
      fetchModalData(type, status, page, mode);
    }
  };

  useEffect(() => {
    if (isModalOpen && modalType && modalStatus && modalMode) {
      const cacheKey = getCacheKey(modalType, modalStatus, modalMode, modalPage);
      if (modalDataCache[cacheKey]) {
        setModalData(modalDataCache[cacheKey]);
      } else {
        fetchModalData(modalType, modalStatus, modalPage, modalMode);
      }
    }
  }, [modalPage]);
  const dashboardPlanDataObject: any = dashboardPlanData();
  return (
    <>
      {/* Tab Header */}
      <div className="flex justify-around  text ">    
        {["MILLIONAIRE", "BILLIONAIRE", "TRILLIONAIRE"].map((plan) => (
          <button
            key={plan}
            onClick={() => setActivePlanTab(plan as any)}
            className={`px-4 py-2 rounded-full font-semibold border  text-[85%] transition-all ${activePlanTab === plan
                ? "bg-blue-light-400"
                : " border-blue-light-400 border text-white  "
              }`}
          >
            {plan} 
          </button>
        ))}
      </div>

      {/* Programs Data */}
      <div className="flex flex-col gap-4">
        {Object.keys(dashboardPlanDataObject)
          .filter((plan) => plan === activePlanTab)
          .map((plan, planIndex) => {
            const programData = dashboardPlanDataObject[plan];
            return (
              <div key={planIndex} className="w-full">
                {/* Content continues unchanged */}
                {/* KEEP YOUR INNER CONTENT (cards, partner/team buttons) UNCHANGED */}
                {/* ... */}
                {/* <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {programData?.program?.map((program: any, index: any) => (
                    <ProgramCard
                      key={index}
                      status={program?.status}
                      programName={program?.title}
                      redirectUrl={`/programs/${program?.type}`}
                      levelData={{
                        count: program?.levelCount,
                        active: activeProgram[program?.type] || 0,
                      }}
                    />
                  ))}
                </div> */}
                <div className={`flex flex-row md:flex-row font-bold ${plan === "TRILLIONAIRE" ? "md:justify-center" : "md:justify-around"} md:items-center gap-4 mb-4 p-6 md:p-8`}>
                  {/* <div className="block md:hidden text-center text-white font-bold text-lg capitalize">
                    {plan}
                  </div> */}

                  {(programData?.title === "MILLIONAIRE" || programData?.title === "BILLIONAIRE") && (
                    <div className="w-full md:w-auto">
                      <div className="text-white text-xl border-[0.1px] border-gray-600 rounded max-w-sm mx-auto">
                        <div className="text-center p-2   text-[70%] md:text-xl font-semibold mb-2 text-[#FFD700]">Direct Partner</div>
                        <div className="relative flex divide-x divide-gray-600 border-[0.1px] border-gray-600 rounded overflow-hidden">
                          <button
                            className="flex-1 text-center p-4 bg-transparent text-white"
                            onClick={() => handleShowModal(programData?.title, "Active", "partner")}
                          >
                            <div className="mb-1 text-[60%] md:text-[70%] leading-tight  dark:text-[#929292]">Active</div>
                            <div className="text-green-600">
                              {partnersReady && showContent
                                ? partnerCache[programData?.title]?.ActiveUsers?.length ?? 0
                                : `${loadingPercent}%`}
                            </div>
                          </button>
                          <button
                            className="flex-1 text-center p-4 bg-transparent text-white"
                            onClick={() => handleShowModal(programData?.title, "Inactive", "partner")}
                          >
                            <div className="mb-1 text-[60%] md:text-[70%] leading-tight  dark:text-[#929292]">Inactive</div>
                            <div className="text-green-600">
                              {partnersReady && showContent
                                ? partnerCache[programData?.title]?.InactiveUsers?.length ?? 0
                                : `${loadingPercent}%`}
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* <div className="hidden md:flex justify-center items-center text-center text-white font-bold text-5xl capitalize">
                    {plan}
                  </div> */}

                  {(programData?.title === "MILLIONAIRE" || programData?.title === "BILLIONAIRE")  && (
                    <div className="w-full md:w-auto">
                      <div className="text-white text-xl border-[0.1px] border-gray-600 rounded max-w-sm mx-auto">
                        <div className="text-center font-semibold p-2   text-[70%] md:text-xl mb-2 text-[#FFD700]">Total Team</div>
                        <div className="relative flex divide-x divide-gray-600 border-[0.1px] border-gray-600 rounded overflow-hidden">
                          <button
                            className="flex-1 text-center p-4 bg-transparent text-white"
                            onClick={() => handleShowModal(programData?.title, "Active", "team")}
                          >
                            <div className="mb-1 text-[60%] md:text-[70%] leading-tight  dark:text-[#929292]">Active</div>
                            <div className="text-green-600">
                              {programData?.title === "MILLIONAIRE"
                                ? totalTeamData?.data?.activeUser ?? 0
                                : totalTeamData?.data?.xactiveUser ?? 0}
                            </div>
                          </button>
                          <button
                            className="flex-1 text-center p-4 bg-transparent text-white"
                            onClick={() => handleShowModal(programData?.title, "Inactive", "team")}
                          >
                            <div className="mb-1 text-[60%] md:text-[70%] leading-tight  dark:text-[#929292]">Inactive</div>
                            <div className="text-green-600">
                              {programData?.title === "MILLIONAIRE"
                                ? totalTeamData?.data?.inActiveUser ?? 0
                                : totalTeamData?.data?.inXActiveUser ?? 0}
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>


{programData?.title === "Trillionaire" && timeLeftpre &&(
// {timeLeftpre && (
  <div className="flex flex-col items-center text-center mb-6">
    <p className="text-green-400 text-xl mb-1">{timerTextpre}</p>
    <div className="flex gap-2 text-white font-semibold text-md md:text-xl">
      {["days", "hours", "minutes", "seconds"].map((unit) => (
        <div key={unit} className="flex flex-col items-center">
          <span className="border border-green-400 p-2 h-15 w-15 rounded-full flex items-center justify-center">
            {timeLeftpre[unit as keyof typeof timeLeftpre]}
          </span>
          <span className="text-xs text-green-300">{unitLabels[unit]}</span>
        </div>
      ))}
    </div>
  </div>
// )}
)}




                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 ">
                  {programData?.program?.map((program: any, index: any) => (
                    <ProgramCard
                      key={index}
                      status={program?.status}
                      programName={program?.title}
                      redirectUrl={`/programs/${program?.type}`}
                      levelData={{
                        count: program?.levelCount,
                        active: activeProgram[program?.type] || 0,
                      }}
                    />
                  ))}
                </div>

              </div>
            );
          })}
      </div>
      <ModalBox
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={modalTitle}
        data={modalData}
        currentPage={modalPage}
        totalPages={modalTotalPages}
        onPageChange={(page: number) => setModalPage(page)}
      />
    </>
  );
}
