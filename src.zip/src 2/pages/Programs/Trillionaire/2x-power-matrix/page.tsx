import { memo, useCallback, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router";
import { useAccount, useDisconnect } from "wagmi";
import { waitForTransactionReceipt } from "wagmi/actions";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import Web3 from "web3";
import axios from "axios";
import { ethers } from "ethers";
import { MoveLeft } from "lucide-react";

import {
  get2ProgramStatus,
  get2ProgramStatusGlobal,
  getGlobalMatnenanceMode,
} from "../../../../apis/programs/main";

import { getConfigData } from "../../../../apis/AiRobat/main";

import {
  Allow2xProContractAmount,
  Allow2XProPowerMatrixSoltContractPkgBuy,
  GetTokenBalanceAmount,
} from "../../../../lib/smartContract";

import { wagmiAdapter } from "../../../../lib/Web3Modal";
import { chainId } from "../../../../config/data";

import { useToast } from "../../../../components/ui/toast/use-toast";
import { useEarning } from "../../../../hooks/earning";

import { robotImage } from "../../../../assets";

import Tr2XPowerMatrix from "../../tXPowerMatrix.tsx";
import Tr2XPowerGlobal from "../../x2powerGlobal.tsx";
import PackageCardTrill from "../../../../components/ui/package/trillionaire.tsx";

const PACKAGE_AMOUNTS = [
  3,
  5,
  10,
  20,
  40,
  80,
  160,
  320,
  640,
  1280,
  2560,
  5120,
  10240,
];

const queryConfig = {
  staleTime: 1000 * 60 * 5,
  gcTime: 1000 * 60 * 10,
  retry: 1,
  refetchOnWindowFocus: false,
  refetchOnReconnect: false,
};

const apiClient = axios.create({
  baseURL: "http://localhost:81/api",
  // timeout: 30000,
});

function X2ProPowerMatrix() {
  const [searchParams] = useSearchParams();

  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { disconnect } = useDisconnect();
  const { toast } = useToast();

  const config = wagmiAdapter?.wagmiConfig;

  const currentUser = useSelector(
    (state: any) => state.global.currentUser
  );

  const { address } = useAccount({ config });

  const purchaseRef = useRef(false);

  const [loadingPkg, setLoadingPkg] = useState<{
    pkg: number;
    type: string;
  } | null>(null);

  const web3 = useMemo(() => {
    return new Web3(
      new Web3.providers.HttpProvider(
        "https://bsc-dataseed.binance.org/"
      )
    );
  }, []);

  const {
    millionaire_Earnings,
    millionaire_level,
  } = useEarning();

  const globalEarning = Number(
    millionaire_Earnings?.["pro-power-global"] || 0
  ).toFixed(0);

  const globalLevelEarning = Number(
    millionaire_level?.global_level_earning || 0
  ).toFixed(0);

  const getXPowerMatrixLink = () => {
    if (searchParams.get("user")) {
      return "/programs?" + searchParams.toString();
    }

    return "/programs";
  };

  const { data: configData } = useQuery({
    queryKey: ["configData"],
    queryFn: getConfigData,
    ...queryConfig,
  });

  const {
    data: proPowerData,
    error: proPowerDataError,
    isLoading: proPowerLoading,
  } = useQuery({
    queryKey: [
      "2proPowerDataMatrix",
      currentUser?.address,
    ],
    queryFn: () =>
      get2ProgramStatus(currentUser?.address),
    enabled: !!currentUser?.address,
    ...queryConfig,
  });

  const {
    data: proPowerData2global,
    error: pro2globalPowerDataError,
    isLoading: proPower2GlobalLoading,
  } = useQuery({
    queryKey: [
      "2proPowerDataGlobal",
      currentUser?.address,
    ],
    queryFn: () =>
      get2ProgramStatusGlobal(currentUser?.address),
    enabled: !!currentUser?.address,
    ...queryConfig,
  });

  const {
    data: maintain_mode,
    error: maintainModeError,
    isLoading: maintainModeLoading,
  } = useQuery({
    queryKey: ["maintain_modeglobal"],
    queryFn: getGlobalMatnenanceMode,
    ...queryConfig,
  });

  const globalMap = useMemo(() => {
    const map = new Map();

    proPowerData2global?.data?.forEach(
      (item: any) => {
        map.set(item.pkg, item);
      }
    );

    return map;
  }, [proPowerData2global]);

  const packageStates = useMemo(() => {
    let activate = 0;

    return (
      proPowerData?.data?.map((data: any) => {
        let variant: any = "empty";

        if (activate === 1) {
          activate = 2;
        }

        if (
          data.status === false &&
          activate === 0
        ) {
          activate = 1;
        }

        if (activate === 0) {
          variant = "2x-pro-power-matrix";
        }

        if (
          activate === 1 &&
          address === currentUser?.address &&
          configData?.data?.power_global_on
        ) {
          variant = "activate";
        }

        return {
          ...data,
          variant,
        };
      }) || []
    );
  }, [
    proPowerData,
    address,
    currentUser,
    configData,
  ]);

  const handlePurchase = useCallback(
    async (
      pkg: number,
      amount: number,
      type: string
    ) => {
      if (purchaseRef.current) return;

      try {
        purchaseRef.current = true;

        setLoadingPkg({
          pkg,
          type,
        });

        if (!address) {
          disconnect();
          navigate("/");
          return;
        }

        const provider = web3;

        const pkgAmount = ethers.utils.parseUnits(
          amount.toString(),
          18
        );

        const [
          walletBalanceBNB,
          tokenBalance,
        ] = await Promise.all([
          provider.eth.getBalance(address),
          GetTokenBalanceAmount(address),
        ]);

        const walletBalanceFormatted =
          ethers.utils.formatEther(
            walletBalanceBNB
          );

        const requiredBalance = 0.0008;

        // if (
        //   parseFloat(walletBalanceFormatted) <=
        //   requiredBalance
        // ) {
        //   throw new Error(
        //     `Insufficient BNB balance! You need at least ${requiredBalance} BNB.`
        //   );
        // }

        if (tokenBalance as any < pkgAmount) {
          throw new Error(
            "Insufficient Balance in Account"
          );
        }

        const approveTx =
          await Allow2xProContractAmount(
            pkgAmount
          );

        await waitForTransactionReceipt(
          config,
          {
            hash: approveTx,
            chainId,
          }
        );

        const txHash =
          await Allow2XProPowerMatrixSoltContractPkgBuy(
            amount
          );

        if (!txHash) {
          throw new Error(
            "Transaction rejected or failed"
          );
        }
        const { data: buyResponse } = await apiClient.get(
          "/2x/buy-pkg",
          {
            params: {
              userAddress: address,
              pkg,
              uniqueId: currentUser?.id,
              trxHash: txHash,
            },
          }
        );
        console.log("buyResponse =>", buyResponse);
        const isSuccess =
          buyResponse?.success &&
          buyResponse?.data?.success &&
          buyResponse?.data?.data?._id;

          if (
            buyResponse?.status !== 200 ||
            !buyResponse?.success
          ) {
            throw new Error(
              buyResponse?.message ||
                "Package purchase failed!"
            );
          }

        localStorage.setItem(
          "package2XMatrixPurchaseTimer",
          (
            Date.now() + 120000
          ).toString()
        );

        toast({
          title:
            "Package Purchase Successful",
          description:
            "You have successfully purchased the package.",
          variant: "success",
        });

        await Promise.all([
          queryClient.invalidateQueries({
            queryKey: [
              "2proPowerDataMatrix",
            ],
          }),

          queryClient.invalidateQueries({
            queryKey: [
              "2proPowerDataGlobal",
            ],
          }),
        ]);
      } catch (e: any) {
        const errorMessage =
          e?.response?.data?.message ||
          e?.message ||
          "Unknown error";

        toast({
          title: "Package Purchase Failed",
          description: errorMessage,
          variant: "destructive",
        });
      } finally {
        purchaseRef.current = false;
        setLoadingPkg(null);
      }
    },
    [
      address,
      config,
      currentUser,
      disconnect,
      navigate,
      queryClient,
      toast,
      web3,
    ]
  );

  if (proPowerDataError) {
    return (
      <div className="flex justify-center text-amber-200">
        Error: {proPowerDataError.message}
      </div>
    );
  }

  if (pro2globalPowerDataError) {
    return (
      <div className="flex justify-center text-amber-200">
        Error:
        {pro2globalPowerDataError.message}
      </div>
    );
  }

  if (maintainModeError) {
    return (
      <div className="flex justify-center">
        Error:
        {maintainModeError.message}
      </div>
    );
  }

  if (
    proPowerLoading ||
    proPower2GlobalLoading ||
    maintainModeLoading
  ) {
    return (
      <div className="flex justify-center py-10 text-white">
        Loading...
      </div>
    );
  }

  if (maintain_mode?.data) {
    return (
      <div className="flex flex-col gap-2">
        <div className="flex h-full flex-col items-center justify-center text-gray-600">
          <img src={robotImage} alt="" />

          <h1 className="text-3xl text-white">
            We'll be back soon!
          </h1>

          <p className="text-center text-2xl font-bold">
            Our Website is currently
            under maintenance.
          </p>

          <p className="text-center text-2xl font-bold">
            We’re working hard to
            improve your experience
          </p>

          <p>
            Thank you for your patience!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex w-full flex-col gap-2">
      <div className="flex items-center gap-6">
        <Link
          to={getXPowerMatrixLink()}
          className="flex items-center gap-2 text-white"
        >
          <MoveLeft />
        </Link>

        <h1 className="text-2xl font-bold text-white">
          2X Power
        </h1>
      </div>

      <div className="flex w-full flex-col items-center gap-4 text-lg font-bold text-white">
        <div className="flex w-full items-center justify-between">
          <div className="rounded-lg border border-gray-600 px-6 py-4 text-center">
            <div className="mb-1 text-[60%] leading-tight dark:text-[#929292] md:text-[70%]">
              Level Earning
            </div>

            <div className="my-1 w-full border-b border-gray-600" />

            <span className="mt-2 block">
              <span className="text-blue-light-400">
                $
              </span>
              {globalLevelEarning}
            </span>
          </div>

          <div className="rounded-lg border border-gray-600 px-6 py-4 text-center">
            <div className="mb-1 text-[60%] leading-tight dark:text-[#929292] md:text-[70%]">
              Slot Earning
            </div>

            <div className="my-1 w-full border-b border-gray-600" />

            <span className="mt-2 block">
              <span className="text-blue-light-400">
                $
              </span>

              {globalEarning}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {packageStates.map(
          (data: any, index: number) => {
            const queryParam =
              searchParams.toString();

            const globalItem =
              globalMap.get(data.pkg);

            const slot = index + 1;

            if (
              data.variant === "empty" ||
              data.variant === "activate"
            ) {
              return (
                <div key={index}>
                  <PackageCardTrill
                    data={{
                      ...data,
                      pkg: slot,
                      amount:
                        data?.amount ||
                        PACKAGE_AMOUNTS[index],
                    }}
                    type="2x_power_matrix"
                    varient={data.variant}
                    name={proPowerData?.name}
                    onActivate={() =>
                      handlePurchase(
                        slot,
                        PACKAGE_AMOUNTS[index],
                        "2x_power_matrix"
                      )
                    }
                    loading={
                      loadingPkg?.pkg ===
                        slot &&
                      loadingPkg?.type ===
                        "2x_power_matrix"
                    }
                  />
                </div>
              );
            }

            return (
              <div
                key={index}
                className="grid grid-cols-1 gap-6 md:grid-cols-2"
              >
                <Link
                  to={`/programs/2x-pro-power-martix/${data.pkg}?${queryParam}`}
                >
                  <Tr2XPowerMatrix
                    data={data}
                  />
                </Link>

                <Link
                  to={`/programs/2x-pro-power-global/${globalItem?.pkg}?${queryParam}`}
                >
                  <Tr2XPowerGlobal
                    data={globalItem}
                  />
                </Link>
              </div>
            );
          }
        )}
      </div>
    </div>
  );
}

export default memo(X2ProPowerMatrix);