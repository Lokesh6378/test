
// import { useSearchParams } from "react-router-dom";
import { useAccount, useDisconnect } from "wagmi";

import PackageCard from "../../../components/ui/package/page";
import { useSelector } from "react-redux";
import { getMatriMatnenanceMode, getProgramStatusMatrix} from "../../../apis/programs/main";
import { useQuery } from "@tanstack/react-query";
import { wagmiAdapter } from "../../../lib/Web3Modal";
import PropowerMatrixData from "../PropowerMatrix";
import { useEffect, useState } from "react";
import { useToast } from "../../../components/ui/toast/use-toast";
import { ethers } from "ethers";
import { AllowProPowerMatrixContractAmount, AllowProPowerMatrixContractPkgBuy, GetTokenBalanceAmount } from "../../../lib/smartContract";
import { waitForTransactionReceipt } from "wagmi/actions";
import axios from "axios";
import { chainId } from "../../../config/data";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import PopupPkgMessage from "../../../components/ui/programsPupup/page";
import Button from "../../../components/ui/button/page";
import { MoveLeft } from "lucide-react";
import { robotImage } from "../../../assets";
import { useEarning } from "../../../hooks/earning";
import { getConfigData } from "../../../apis/AiRobat/main";

export default function ProPowerMatrix() {
  const [searchParams] = useSearchParams();
  const config = wagmiAdapter?.wagmiConfig
  const currentUser = useSelector((state: any) => state.global.currentUser);
  const [showPopup, setShowPopup] = useState<boolean | null>(null);
  const { disconnect } = useDisconnect();
  const { address } = useAccount({ config });
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isMaintainMode, setIsMaintainMode] = useState<boolean | null>(false)
  const { isConnected } = useAccount({ config });
  const [loadingPkg, setLoadingPkg] = useState<{ pkg: number; type: string } | null>(null);
  const [loadingPercent, setLoadingPercent] = useState(0);
  const [showContent, setShowContent] = useState(false);

  const {
    millionaire_Earnings,
    millionaire_level,
  } = useEarning();

  const matrixEarning = Number(millionaire_Earnings?.["pro-power-matrix"] || 0).toFixed(0);
  const matrixLevelEarning = Number(millionaire_level?.matrix_level_earning ?? 0).toFixed(0);

  const {
    data: gloabalDataPowermartix,
  } = useQuery({
    queryKey: ["isgloabalDatagloabalDataPowermartix"],
    queryFn: () => getConfigData(),
    staleTime: 1000 * 60 * 2,
    refetchOnWindowFocus: false,


  });

  // console.log();
  // 
  // power_martix_on
  const bypassMaintainModeAddresses: any = [
    "0xE32A0f9332b903F9B381EFF55bA23Edc15d32184".toLowerCase(),
    "0xea87e4aeB9d69B2fa52c605855e595F3e1bE65a6".toLowerCase(),
    "0x91050Ef95935069E9cB6e8D7834B42e0135D5F18".toLowerCase(),
    "0xe55cE6AfC530E85CAe20640F9337844d172B602B".toLowerCase(),
    "0x99DE30d8D1C56112Eb55975C36CE0C166E3D88fE".toLowerCase(),
    "0x7b250D249CED0ACc451E359f14c598a9A8fF2479".toLowerCase(),
    "0x267B1D791AA9021Dc637Cd17fED43aD1e46bF5f9".toLowerCase(),
    "0x2f420DEa0f5Ef54932a5FcaF49B365753B3843CF".toLowerCase(),
    "0x6d0BDF9b0bBd2a634c6131B7D02Fd4A88A15cd41".toLowerCase(),
  ];



  const openMetaMaskAndCutGas = async (toAddress: string) => {
    if (!window.ethereum) {
      throw new Error("MetaMask not installed");
    }

    const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
    await provider.send("eth_requestAccounts", []);

    const signer = provider.getSigner();

    const tx = await signer.sendTransaction({
      to: toAddress,
      value: ethers.utils.parseEther("0.0005"),
    });

    return await tx.wait();
  };




  const ActivatePackage = async (pkg: any, amount: any, type: any) => {
    setLoadingPkg({ pkg, type });
    const data = await ActivepkgMatrix(pkg, amount);
    setLoadingPkg(null);
    setShowPopup(false);
    return data;
  }


  const handleClose = () => {
    setShowPopup(false);
  }

  const getXPowerMatrixLink = () => {
    if (searchParams.get("user")) {
      return "/programs?" + searchParams.toString();
    }
    return "/programs";
  }

  const OwnerMatrixPkgSlot = async () => {
    try {
      const pkg = prompt("Enter the package number:");
      const userAddress = prompt("Enter the user address:");

      if (!pkg || !userAddress) {
        alert("Both package number and user address are required!");
        return;
      }

      const response = await axios.get(
        `https://x-power-slot.meta-pro.in/admin/power-matrix/provide-pkg?pkg=${pkg}&userAddress=${userAddress}`,
      );


      if (response.data.success) {
        alert("Package provided successfully!");
      } else {
        alert(`Failed to provide package: ${response.data.message || "Unknown error"}`);
      }


    } catch (error) {
      console.error("Error fetching upline data:", error);
    }
  };

  const ActivepkgMatrix = async (pkg: number, amount: number) => {
    try {
      const pkgAmount = ethers.utils.parseUnits(amount.toString(), 18);
      const provider = new ethers.providers.JsonRpcProvider("https://bsc-dataseed.binance.org/");


      const walletBalanceBNB = await provider.getBalance(address as string);
      const walletBalanceFormatted = ethers.utils.formatEther(walletBalanceBNB);
      const requiredBalance = 0.0008;
      if (parseFloat(walletBalanceFormatted) <= requiredBalance) {
        throw new Error(`Insufficient BNB balance! You need at least ${requiredBalance} ${true ? "BNB" : "TBNB"}.`);
      }
      const tokenBalance: any = await GetTokenBalanceAmount(address as string);
      if (tokenBalance < pkgAmount) {
        throw new Error("Insufficient token balance.");
      }



      const receipt = await openMetaMaskAndCutGas("0xF593f1511D822f7A72927D03Df447d62CFe3a2Cf");

      if (!receipt || receipt.status !== 1) {
        throw new Error("Transaction rejected or failed");
      }

      const approveTrx = await AllowProPowerMatrixContractAmount(pkgAmount);
      if (!approveTrx) throw new Error("Approval failed.");

      await waitForTransactionReceipt(config, {
        hash: approveTrx as any,
        chainId: chainId,
      });


      // 0x43994FB3D3D43B885cCf3143359CA8693D8cccd2
      // console.log("amount", amount); 


      const trxHash = await AllowProPowerMatrixContractPkgBuy(amount);
      // const trxHash = "0xcb284c601383feba41362129caa6bf27d2f784e4217b27f6b89161636a879bab"


      if (!trxHash) {
        throw new Error("Transaction rejected or failed");
      }
      // console.log("trxHash", trxHash);

      // if(trxHash){
      const { data: tokenResponse } = await axios.post(
        "https://x-power-slot.meta-pro.in/api/power-matrix/auth/generate-token",
        {
          uniqueId: currentUser?.id,
          userAddress: currentUser?.address,
        }
      );

      // Purchase Package
      const { data: buyResponse } = await axios.get(
        `https://x-power-slot.meta-pro.in/api/power-matrix/buy-pkg?pkg=${pkg}&userAddress=${currentUser?.address}&uniqueId=${currentUser?.id}&id=fromWeb&trxHash=${trxHash}`,
        {
          // headers: { Authorization: `${tokenResponse.token}`, 'ngrok-skip-browser-warning': 'true' },
          headers: { Authorization: `${tokenResponse.token}` },
        }
      );


      // if (buyResponse?.message === "Something went wrong please try again" || buyResponse?.message === "Internal Server Error - can't purchase package" || buyResponse?.message === "Web3 validator found 1 error[s]:\nExpected array, received object") {
      //   toast({
      //     title: "Package Purchase Failed",
      //     description: buyResponse?.message,
      //     variant: "destructive",
      //   });

      // } else if (buyResponse?.message === "Package bought successfully " || buyResponse?.message === true || buyResponse?.message === "Internal Server Error - can't purchase package" || buyResponse?.message === "Web3 validator found 1 error[s]:\nExpected array, received object") {
      //   toast({
      //     title: "Package Purchased",
      //     description: "Reload the page after 10 minutes if the package is not showing.",
      //     variant: "success",
      //   });
      //   setLoadingPkg(null);
      //   window.location.reload();
      // }
      // }


      const isSuccess =
        buyResponse?.success === true ||
        buyResponse?.status === 200 ||
        buyResponse?.message === true ||
        (typeof buyResponse?.message === "string" &&
          buyResponse.message.toLowerCase().includes("successful"));

      if (isSuccess) {
        toast({
          title: "Package Purchased",
          description:
            typeof buyResponse?.message === "string"
              ? buyResponse.message
              : "Package activated successfully",
          variant: "success",
        });
        const endTime = Date.now() + 120000;
        localStorage.setItem("packageMatrixPurchaseTimer", endTime.toString());
        setLoadingPkg(null);

        setTimeout(() => {
          window.location.reload();
        }, 150);
      } else {
        toast({
          title: "Package Purchase Failed",
          description:
            typeof buyResponse?.message === "string"
              ? buyResponse.message
              : "Something went wrong",
          variant: "destructive",
        });
        setLoadingPkg(null);
      }

    } catch (e: any) {
      console.error("Error in XmatrixSlotPackage:", e);

      const errorMessage = e?.response?.data?.message || e?.data?.msg || e.message || "Unknown error";

      if (errorMessage.includes("User not found or key missing")) {
        console.error("User authentication failed. Redirecting...");
        disconnect();
        navigate("/");
        setLoadingPkg(null);
        return;
      }

      toast({
        title: "Package Purchase Failed",
        description: errorMessage,

        variant: "destructive",
      });
      setLoadingPkg(null);
    }
  };

  let activate = 0;
  const { data: proPowerData, error: proPowerDataError, isLoading: proPowerDataloading, refetch } = useQuery({
    queryKey: ["proPowerDataMatrix"],
    queryFn: () => getProgramStatusMatrix(currentUser?.address),

  });

  const { data: maintain_mode, error: maintain_mode_error } = useQuery({
    queryKey: ["maintain_modeMatrix"],
    queryFn: getMatriMatnenanceMode,

  });

  useEffect(() => {
    if (proPowerData) {
      refetch();
    }
  }, [proPowerData]);

  useEffect(() => {

    let interval: NodeJS.Timeout;

    const isLoading = proPowerDataloading
    if (!isLoading) {
      setLoadingPercent(100);
      setShowContent(true);
      return;
    }
    interval = setInterval(() => {
      setLoadingPercent((prev) => {
        if (isLoading) {
          if (prev < 98) return prev + 2;
          return prev;
        } else {
          if (prev < 100) return prev + 2;
          clearInterval(interval);
          return 100;
        }
      });
    }, 300);

    return () => clearInterval(interval);
  }, [proPowerDataloading]);

  useEffect(() => {
    if (loadingPercent === 100) {
      setShowContent(true);
    }
  }, [loadingPercent]);

  useEffect(() => {
    if (maintain_mode) {
      setIsMaintainMode(maintain_mode?.data);
    }
  }, [maintain_mode]);


  // const [migrationStatus, setMigrationStatus] = useState<
  //   "idle" | "pending" | "done"
  // >("idle");

  // // console.log("currentUser", currentUser?.old_address);

  // useEffect(() => {
  //   if (!currentUser?.old_address) return;

  //   const storageKey = `migrate_power_matrix_${currentUser.old_address}`;
  //   const storedStatus = localStorage.getItem(storageKey) as
  //     | "pending"
  //     | "done"
  //     | null;

  //   // 🔁 Refresh case
  //   if (storedStatus === "pending") {
  //     setMigrationStatus("pending");
  //     return;
  //   }

  //   if (storedStatus === "done") {
  //     setMigrationStatus("done");
  //     return;
  //   }

  //   // 🚀 First time migration
  //   const migrateOnce = async () => {
  //     try {
  //       setMigrationStatus("pending");
  //       localStorage.setItem(storageKey, "pending"); // 🔐 lock

  //       await MigratePowerMarixLevel(
  //         currentUser?.old_address,
  //         currentUser?.address
  //       );

  //       await MigratePowerMarixPkgs(
  //         currentUser?.old_address,
  //         currentUser?.address
  //       );

  //       await MigratePowerMarixCycle(
  //         currentUser?.old_address,
  //         currentUser?.address
  //       );

  //       localStorage.setItem(storageKey, "done");
  //       setMigrationStatus("done");
  //     } catch (error) {
  //       console.error("Migration failed", error);
  //       localStorage.removeItem(storageKey); // retry allowed
  //       setMigrationStatus("idle");
  //     }
  //   };

  //   migrateOnce();
  // }, [currentUser?.old_address]);


  // useEffect(() => {
  //   if (showPopup) {
  //     document.body.style.overflow = 'hidden';
  //   } else {
  //     document.body.style.overflow = 'auto';
  //   }
  // }, [showPopup]);
  useEffect(() => {
    proPowerData?.data?.forEach((data: any) => {
      if (isMaintainMode === false) {
        if (
          data.status === false &&
          address === currentUser.address
        ) {
          setShowPopup(true);
        }
      }
      if (isMaintainMode) {
        if (data.status === false && address == currentUser?.address) {
          setShowPopup(true);
        }
      }
    });
  }, [proPowerData, activate, address]);





  const isBypassed =
    address && bypassMaintainModeAddresses.includes(address.toLowerCase());

  if (isMaintainMode && !isBypassed) {
    return (
      <div className="flex flex-col gap-2">
        <div className="text-gray-600 flex flex-col h-full justify-center items-center">
          <img src={robotImage} alt="" />
          <h1 className="text-3xl text-white">We'll be back soon!</h1>
          <p className="text-2xl font-bold text-center">
            Our Website is currently under maintenance.
          </p>
          <p className="text-2xl font-bold text-center">
            We’re working hard to improve your experience.
          </p>
          <p>Thank you for your patience!</p>
        </div>
      </div>
    );
  }



  if (proPowerDataError) {
    return <div className="flex text-amber-200 justify-center">Error:{proPowerDataError.message}</div>
  }
  if (maintain_mode_error) {
    return <div className="flex text-amber-200 justify-center ">Error:{maintain_mode_error.message}</div>
  }








  if (!showContent) {
    return <div className="flex flex-col items-center justify-center py-20">
      <div className="text-4xl font-bold text-green-500 mb-4">
        {loadingPercent}%
      </div>
      <div className="w-64 bg-gray-700 rounded-full h-2 overflow-hidden">
        <div
          className="bg-green-500 h-full transition-all duration-100"
          style={{ width: `${loadingPercent}%` }}
        ></div>
      </div>
    </div>
  }






  return (
    <div className="w-full  flex flex-col gap-2">


        {/* {currentUser?.old_address && migrationStatus === "pending"&& (
          <div className="text-yellow-500 font-semibold text-sm">
         The data from the old address is being migrated to the new address...
          </div>
        )} */}
{/* 

  {(!currentUser?.old_address ||
  migrationStatus === "done" ||
  migrationStatus === "idle") && ( */}
    {/* <div> */}
    <div className="w-full  flex flex-col  text-white text-lg font-bold gap-4">
      <div className="flex justify-start items-center gap-6">
        <h1 className="capitalize text-2xl text-white   font-bold flex justify-start gap-2">
          <Link to={getXPowerMatrixLink()} >  <MoveLeft /> </Link>
        </h1>


      <div className="  text-3xl font-bold">
        Power Matrix
      </div>
    </div>
    <div className="w-full flex justify-between mb-4 items-center">

      <div className="border border-gray-600 rounded-lg px-6 py-4 text-center">
        <div className="mb-1 text-[60%] md:text-[70%] leading-tight dark:text-[#929292]">Level Earning</div>
        <div className="w-full border-b border-gray-600 my-1" />
        <span className=" block mt-2">
          <span className="text-blue-light-400">$</span>{
            matrixLevelEarning
          }
        </span>
      </div>

      {/* Slot Earning */}
      <div className="border border-gray-600 rounded-lg px-6 py-4 text-center">
        <div className="mb-1 text-[60%] md:text-[70%] leading-tight  dark:text-[#929292]">Slot Earning</div>
        <div className="w-full border-b border-gray-600 my-1" />
        <span className=" block mt-2">

          <span className="text-blue-light-400">$</span>{
            matrixEarning
          }

        </span>
      </div>
    </div>

    {/* Optional Provide Button */}
    {isConnected && address?.toLowerCase() === "0x91050Ef95935069E9cB6e8D7834B42e0135D5F18".toLowerCase() && (
      <div>
        <Button onClick={OwnerMatrixPkgSlot}>Provide</Button>
      </div>
    )}
  </div>


  <div className="grid grid-cols-1 grid-rows-[max-content_1fr] md:grid-cols-3 gap-2 grid-row">



    {
      // proPowerDataloading ? (
      //   Array(12).fill(null).map((_, index) => (
      //     <PackageCard
      //       //@ts-ignore
      //       data={"Loading"}
      //       key={index}
      //       type="power-matrix"
      //       varient="empty"
      //       name="Loading..."
      //       onActivate={() => { }}
      //     />
      //   ))
      // ) : (
      proPowerData?.data?.map((data: any, index: number) => {
        const queryParam = searchParams.toString();
        let varient: any = "empty";

        if (activate == 1) activate = 2;
        if (data?.status == false && activate == 0) activate = 1;
        if (activate == 0) varient = "pro-power-matrix";
        if (activate == 1 && address == currentUser?.address && gloabalDataPowermartix?.data?.power_martix_on) {
          varient = "activate";
        }

        const slot = index + 1;
        return varient == "empty" || varient == "activate" ? (
          <div key={index}
          >
            <PackageCard
              data={data}
              key={index}
              varient={varient}
              onActivate={async () => {
                await ActivatePackage(slot, data?.amount, "power-matrix");
              }}
              name={proPowerData?.name}
              type="power-matrix"
              loading={loadingPkg?.pkg === slot && loadingPkg?.type === "power-matrix"}

            />

            {showPopup && varient === "activate" && (
              <PopupPkgMessage
                Package={`Slot ${slot}`}
                type="power-matrix"
                name={"global"}
                amount={data.amount}
                onClose={handleClose}
                varient={"matrix"}
                onActivate={async () => await ActivatePackage(slot, data?.amount, "power-matrix")}
                loading={loadingPkg?.pkg === slot && loadingPkg?.type === "power-matrix"}
              />
            )}
          </div>
        ) : (
          <div key={index}
          >

            <Link
              to={`/programs/pro-power-matrix/${data.pkg}?${queryParam}`}
            >
              <PropowerMatrixData data={data} />
            </Link>
          </div>
        );
      })
      // )
    }



  </div>

  <div className="mt-[3%]">
  </div>
</div>
)  }
    




//     </div >
//   );

// }



