import { LogoFinalModified } from "../../assets";
import Button from "../../components/ui/button/page";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../../components/ui/card/page";
import { useLocation, useNavigate } from "react-router-dom";
import { cn } from "../../lib/utils";
import MyLottieComponent from "../../components/MyLottieComponent/MyLottieComponent";
import { useEarning } from "../../hooks/earning";

const ProgramCard = ({
  programName,
  redirectUrl,
  status,
  levelData,
}: {
  programName: string;
  status?: boolean;
  redirectUrl: string;
  levelData: {
    count: number;
    active: number;
  };
}) => {
  const {
    millionaire_Earnings,
    millionaire_level,
    billionaire_Earnings,
    billionaire_level,
    trillionaire_Earnings,
    trillionaire_level,
  } = useEarning();

  const location = useLocation();
  const searchParams = location.search;

  // const isxGlobalOpen = useSelector((state: any) => state.global?.isxGlobalOpen);
  // const isGlobalOpen = useSelector((state: any) => state?.global?.isGlobalOpen);

  const navigate = useNavigate();

  // ✅ Compute total by program type
  let totalTeamData = 0;

  if (programName === "Power Matrix") {
    totalTeamData =
      Number(millionaire_Earnings?.["pro-power-matrix"] || 0) +
      Number(millionaire_level?.matrix_level_earning || 0);
  } else if (programName === "Power Global") {
    totalTeamData =
      Number(millionaire_Earnings?.["pro-power-global"] || 0) +
      Number(millionaire_level?.global_level_earning || 0);
  } else if (programName === "X-Power Global") {
    totalTeamData =
      Number(billionaire_Earnings?.x_pro_power_global || 0) +
      Number(billionaire_level?.x_global_level_earning || 0);
  } else if (programName === "X-Power Matrix") {
    totalTeamData =
      Number(billionaire_Earnings?.x_pro_power_matrix || 0) +
      Number(billionaire_level?.x_matrix_level_earning || 0);
  }
  else if (programName === "2X-Power") {
    totalTeamData =
      Number(trillionaire_Earnings?.two_x_matrix || 0) +
      Number(trillionaire_level?.two_x_level_earning || 0);
  }

  return (
    <div className="rounded-md   md:p-8">
      <div className="relative overflow-hidden rounded-md ">
        <div className="relative">
          <img
            src={LogoFinalModified}
            alt=""
            className="absolute bottom-2  right-5 h-72 w-72 object-cover opacity-40"
          />
        </div>
        <Card className="relative overflow-hidden rounded-xl border-2 border-yellow-600 p-2 md:p-8">
          <CardHeader>
            <CardTitle className="flex justify-between gap-2">
              <div className="text-white">{programName}</div>

              {(programName === "Power Matrix" ||
                programName === "Power Global" ||
                programName === "X-Power Global" ||
                programName === "X-Power Matrix" ||programName === "2X-Power" 
              ) && (
                  <div className="text-white">
                    <span className="text-[#86ff00]">
                      <span className="text-white text-lg md:text-2xl"> {typeof totalTeamData === "number" ? totalTeamData.toFixed(0) : "0"}</span>
                    </span>  <span className="text-[#86ff00]">USDT</span>

                  </div>
                )}
            </CardTitle>
          </CardHeader>

          <CardContent className="flex flex-wrap gap-2">
            {status ? (
              [...Array(levelData?.count)].map((_, i) => (
                <div
                  key={i}
                  className={cn(
                    "num-slot flex h-7 md:h-12 w-7 md:w-12 items-center justify-center rounded-full border-3 border-[#fab823] text-lg font-bold text-white overflow-hidden",
                    i < levelData?.active ? "ring-primary bg-green-600" : "ring-white"
                  )}
                >
                  <p>{i + 1}</p>
                </div>
              ))
            ) : (
              <div className="w-full h-full flex text-white justify-center flex-col items-center">

                <MyLottieComponent index={0} />
              </div>
            )}
          </CardContent>

          <CardFooter className="flex justify-end">

            {
              status && (
                <Button
                  className="bg-yellow-600 font-bold text-white"
                  onClick={() => {
                    navigate(`${redirectUrl}${searchParams}`);
                  }}
                >
                  More Detail
                </Button>
              )
            }

            {/* )} */}
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default ProgramCard;
