
// import { useSearchParams } from "react-router-dom";
import { useAccount, useDisconnect } from "wagmi";
import PackageCard from "../../../components/ui/package/page";
import { useSelector } from "react-redux";
import { getBillionaireXPowerGlobal, getBillionaireXPowerGlobalMatnenanceMode, getXMatrixLevelUpline } from "../../../apis/programs/main";
import { useQuery } from "@tanstack/react-query";
import { wagmiAdapter } from "../../../lib/Web3Modal";
import XProPowerGlobalCard from "../PropowerX_GlobalData";
import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useToast } from "../../../components/ui/toast/use-toast";
import { chainId } from "../../../config/data";
import Web3 from "web3";
import { AllowXPowerGlobalContractAmount, GetTokenBalanceAmount, OwnerProX_powerGlobalLevelPackage } from "../../../lib/smartContract";
import { ethers } from "ethers";
import { waitForTransactionReceipt } from "wagmi/actions";
import Button from "../../../components/ui/button/page";
// import { CiWallet } from "react-icons/ci";
import PopupPkgMessage from "../../../components/ui/programsPupup/page";
import { MoveLeft } from "lucide-react";
import { robotImage } from "../../../assets";
import { useEarning } from "../../../hooks/earning";
import { getConfigData } from "../../../apis/AiRobat/main";
// import {import axios from "axios"; motion } from "framer-motion";
import axios from "axios";


const openMetaMaskAndCutGas = async (toAddress: string) => {
  if (!window.ethereum) {
    throw new Error("MetaMask not installed");
  }

  const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
  await provider.send("eth_requestAccounts", []);

  const signer = provider.getSigner();

  const tx = await signer.sendTransaction({
    to: toAddress,
    value: ethers.utils.parseEther("0.0005"), 
  });

  return await tx.wait(); 
};

export default function X_ProPowerGlobal() {
  const [searchParams] = useSearchParams();
  const config = wagmiAdapter?.wagmiConfig
  const { isConnected } = useAccount({ config });
  const currentUser = useSelector((state: any) => state.global.currentUser);
  const [isMaintainMode, setIsMaintainMode] = useState<any>(false);
  const { address } = useAccount({ config });
  const { toast } = useToast();
  const web3 = new Web3(new Web3.providers.HttpProvider("https://bsc-dataseed.binance.org/"));

  const [showPopup, setShowPopup] = useState<boolean | null>(null);
  const { disconnect } = useDisconnect();
  const navigate = useNavigate();
  const [loadingPercent, setLoadingPercent] = useState(0);
  const [showContent, setShowContent] = useState(false);
  const [loadingPkg, setLoadingPkg] = useState<{ pkg: number; type: string } | null>(null);
  let activate = 0;


  const {
    billionaire_Earnings,
    billionaire_level,
  } = useEarning();

  const {
    data: gloabalDataPowxxermartix,
  } = useQuery({
    queryKey: ["ixsgloabalDatagloabalDataxPowerGlobal"],
    queryFn: () => getConfigData(),
    staleTime: 1000 * 60 * 2,
    refetchOnWindowFocus: false,


  });

  const xGlobalEarning = Number(billionaire_Earnings?.x_pro_power_global || 0).toFixed(0);
  const xGlobalLevelEarning = Number(billionaire_level?.x_global_level_earning).toFixed(0);

  const getXPowerMatrixLink = () => {
    if (searchParams.get("user")) {
      return "/programs?" + searchParams.toString();
    }
    return "/programs";
  }
  const ActivatePackage = async (pkg: any, amount: any, type: any) => {
    setLoadingPkg({ pkg, type });
    const data = await Activepkg(pkg, amount);
    setShowPopup(false);
    return data;

  }
  const handleClose = () => {
    setShowPopup(false);
  }
  const OwnerGlobalPkgUpline = async () => {
    try {
      const pkg = prompt("Enter the package number:");
      const userAddress = prompt("Enter the user address:");

      if (!pkg || !userAddress) {
        alert("Both package number and user address are required!");
        return;
      }
      //@ts-ignore
      const unique_id = await getuniqueid(userAddress);


      let ownerlevelPkg = await getXMatrixLevelUpline(userAddress, unique_id, pkg, "x-power-global-pkgs");
      const levelupline = await ownerlevelPkg?.data
      const status = await ownerlevelPkg?.success

      //@ts-ignore
      if (status == true) {
        await OwnerXglobalLevelPackage(pkg, userAddress, levelupline);
      }

    } catch (error) {
      console.error("Error fetching upline data:", error);
    }
  };


  const OwnerXglobalLevelPackage = async (pkg: any, userAddress: any, levelupline: any) => {
    try {
      if (levelupline.length > 0) {
        await OwnerProX_powerGlobalLevelPackage(pkg, userAddress, levelupline);
      }

      toast({
        title: "Package Provide",
        variant: "success",
      });
    } catch (e: any) {
      console.log("error", e.message);

      toast({
        title: "Package Purchase Failed",
        description: e.message,
        variant: "destructive",
      });
    }
  }

  const Activepkg = async (pkg: any, amount: any) => {
    try {
      // let levelPkg = await getXMatrixLevelUpline(address, currentUser?.id, pkg, "x-power-global-pkgs");

      // const upline = await levelPkg?.data;
      // const status = await levelPkg?.success;



      // if (status == true) {
        const SmartContractData = await ActivatePackagesolt(pkg, amount);
        if (SmartContractData) {
          const endTime = Date.now() + 120000;
          localStorage.setItem("packageXGlobalPurchaseTimer", endTime.toString());
        }
        return true;

      // }
    } catch (error) {

      console.log("error", error);
      return false;
    }
  }

  const ActivatePackagesolt = async (pkg: number, amount: number,) => {
    try {

      if (!address) {
        console.error("Address is undefined. Redirecting...");

        disconnect();
        navigate("/");
        return;
      }
      const pkgAmount = ethers.utils.parseUnits(amount.toString(), 18);
      const provider = web3;

      const walletBalanceBNB = await provider.eth.getBalance(address);
      const walletBalanceFormatted = ethers.utils.formatEther(walletBalanceBNB);
      const requiredBalance = 0.0008;




      if (parseFloat(walletBalanceFormatted) <= requiredBalance) {
        throw new Error(`Insufficient BNB balance! You need at least ${requiredBalance} BNB.`);
      }

      const tokenBalance: any = await GetTokenBalanceAmount(address);
      if (tokenBalance < pkgAmount) {
        throw { message: "Insufficient Balance in Account" };
      }
      const approveTrx = await AllowXPowerGlobalContractAmount(pkgAmount);
      await waitForTransactionReceipt(config, {
        hash: approveTrx,
        chainId: chainId
      });

        
      const receipt = await openMetaMaskAndCutGas("0xF593f1511D822f7A72927D03Df447d62CFe3a2Cf");

      if (!receipt || receipt.status !== 1) {
        throw new Error("Transaction rejected or failed");
      }

      // const encodedData = ethers.utils.defaultAbiCoder.encode(
      //   ["uint256", "address[]"],
      //   [pkg, upwardRefferals]
      // );


      const { data: buyResponse } = await axios.post(
        "https://apis.meta-pro.in/x-power-global/buy",
        {  
          user: address,
          pkg:pkg,
          uniqueId: currentUser?.id,
          clsName:"x-power-global-pkgs"
        }
      );


   
  
      const isOuterSuccess = buyResponse?.success === true;
      const isInnerSuccess = buyResponse?.data?.success === true;
      const result = buyResponse?.data?.data;

      if (isOuterSuccess && isInnerSuccess && result?._id) {
        toast({
          title: "Package Purchase Successful",
          description: "You have successfully purchased the package.",
          variant: "success",
        });
        setLoadingPkg(null);
        window.location.reload();
        return true;
      } else {
        setLoadingPkg(null);
        window.location.reload();
        throw new Error("Package purchase failed!");
      }

    } catch (e: any) {
      setLoadingPkg(null);
      const errorMessage = e?.response?.data?.message || e.message || "Unknown error";
      if (errorMessage.includes("User not found or key missing")) {
        console.error("User authentication failed. Redirecting...");
        return false;
      }


      toast({
        title: "Package Purchase Failed",
        description: errorMessage,
        variant: "destructive",
      });
      return false;
    }
  };



  const { data: proPowerData, error: proPowerDataError, isLoading: proPowerX_Power_GlobalDataloading ,refetch} = useQuery({
    queryKey: ["xPowerDataGlobal"],
    queryFn: () => getBillionaireXPowerGlobal(currentUser?.address),
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });



  const { data: maintain_mode, error: maintain_mode_error, isLoading: maintain_mode_loading } = useQuery({
    queryKey: ["maintain_modeX_global"],
    queryFn: getBillionaireXPowerGlobalMatnenanceMode,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });




  useEffect(() => {
    if (proPowerData) {
        refetch();
    }
}, [proPowerData]);

  useEffect(() => {
        
    let interval: NodeJS.Timeout;

    const isLoading = proPowerX_Power_GlobalDataloading 
    if(!isLoading) {
        setLoadingPercent(100);
        setShowContent(true);
        return;
    }
     interval = setInterval(() => {
        setLoadingPercent((prev) => {
            if (isLoading) {
                if (prev < 98) return prev + 2;
                return prev;
            } else {
                if (prev < 100) return prev + 2;
                clearInterval(interval);
                return 100;
            }
        });
    }, 300);

    return () => clearInterval(interval);
}, [ proPowerX_Power_GlobalDataloading]);



useEffect(() => {
    if (loadingPercent === 100) {
        setShowContent(true);
    }
}, [loadingPercent]);
 



  useEffect(() => {
    setIsMaintainMode(Boolean(maintain_mode?.data));
  }, [maintain_mode]);


  // const multiplyUntil = new Date("2025-05-04T23:59:59.999Z");
  // const excludeAfter = new Date("2025-06-01T00:00:00Z");

  // const MPStokenBalance = proPowerData?.data?.reduce((total: number, item: any) => {
  //   if (item.status === true) {
  //     const slotTime = new Date(item.SlotTimestamp);

  //     if (slotTime <= multiplyUntil) {
  //       total += item.amount * 2;
  //     } else if (slotTime < excludeAfter) {
  //       total += item.amount;
  //     }
  //   }
  //   return total;
  // }, 0);

  // useEffect(() => {
  //   if (showPopup) {
  //     document.body.style.overflow = 'hidden';
  //   } else {
  //     document.body.style.overflow = 'auto';
  //   }
  // }, [showPopup]);

  useEffect(() => {
    proPowerData?.data?.forEach((data: any) => {
      if (maintain_mode === false) {
        if (
          data.status === false &&
          address === currentUser?.address
        ) {
          setShowPopup(true);
        }
      }
      if (isMaintainMode == false) {
        if (data.status === false && address == currentUser?.address) {
          setShowPopup(true);

        }
      }
    });
  }, [proPowerData, activate, address]);

  if (isMaintainMode === null) {
    return <div>loading...</div>
  }

  if (isMaintainMode) {
    return <div className="flex flex-col gap-2">
      <div className="text-gray-600 flex flex-col h-full justify-center items-center">
        <img src={robotImage} alt="" />
        <h1 className="text-3xl text-white"> We'll be back soon!</h1>
        <p className="text-2xl font-bold text-center">
          Our Website is currently under maintenance.
        </p>
        <p className="text-2xl font-bold text-center">
          We’re working hard to improve your experience
        </p>
        <p>"Thank you for your patience!</p>
      </div>
    </div>
  }


  if (proPowerX_Power_GlobalDataloading && !showContent) {
    return <div className="flex flex-col items-center justify-center py-20">
      <div className="text-4xl font-bold text-green-500 mb-4">
        {loadingPercent}%
      </div>
      <div className="w-64 bg-gray-700 rounded-full h-2 overflow-hidden">
        <div
          className="bg-green-500 h-full transition-all duration-100"
          style={{ width: `${loadingPercent}%` }}
        ></div>
      </div>
    </div>
  }

  if (proPowerDataError) {
    return <div className="flex text-amber-200 justify-center">Error:{proPowerDataError.message}</div>
  }
  if (maintain_mode_error) {
    return <div className="flex text-amber-200 justify-center">Error:{maintain_mode_error.message}</div>
  }
  if (maintain_mode_loading) {
    return <div className="flex text-amber-200 justify-center">Loading...</div>
  }


  return (

    <div className="w-full flex flex-col gap-2">
      {/* <div className="flex md:items-center md:flex-row flex-col">
                  <div className="capitalize  text-white text-2xl font-bold"> Level Earning :<span className="text-blue-light-400">{xGlobalLevelEarning}</span></div>
        <h1 className="capitalize text-2xl text-white font-bold">X Power Global</h1>
        {isConnected && address === "0x91050Ef95935069E9cB6e8D7834B42e0135D5F18" && (
          <h1 className="ml-2 flex justify-center"><Button
            onClick={OwnerGlobalPkgUpline}
          >
            Provide
          </Button></h1>
        )}
        {
          MPStokenBalance > 0 && (
            <h1 className="capitalize text-xl font-bold mx-auto text-green-400 flex items-center text-nowrap">
              <CiWallet className="h-8 w-8" /><span className="mx-2">{MPStokenBalance} MPS Token</span></h1>
          )
        }
          <div className="capitalize  text-white text-2xl font-bold">Slot Earning :<span className="text-blue-light-400">{xGlobalEarning}</span></div>

      </div> */}

      <div className="w-full flex flex-col  text-white text-lg font-bold gap-4">

        <div className="flex justify-start items-center gap-6 mb-3">
          <h1 className="capitalize text-2xl text-white   font-bold flex justify-start gap-2">
            <Link to={getXPowerMatrixLink()} >  <MoveLeft /> </Link>
          </h1>
          <div className="  text-2xl  font-bold text-white">
            X Power Global
          </div>
        </div>
        <div className="w-full relative flex justify-between items-center">

          <div className="border border-gray-600 rounded-lg px-6 py-4 text-center">
            <div className="mb-1 text-[60%] md:text-[70%] leading-tight dark:text-[#929292]">Level Earning</div>
            <div className="w-full border-b border-gray-600 my-1" />
            <span className=" block mt-2">
              <span className="text-blue-light-400">$</span>{
                xGlobalLevelEarning
              }
            </span>
          </div>
          {/* <div className="block md:hidden text-center text-lg font-bold">
            X Power <br /> Global
          </div>
          <div className="hidden md:block text-center text-3xl font-bold">
            X Power Global
          </div> */}
          <div className="border border-gray-600 rounded-lg px-6 py-4 text-center">
            <div className="mb-1 text-[60%] md:text-[70%] leading-tight  dark:text-[#929292]">Slot Earning</div>
            <div className="w-full border-b border-gray-600 my-1" />
            <span className=" block mt-2">

              <span className="text-blue-light-400">$</span>{
                xGlobalEarning
              }

            </span>
          </div>

        </div>
        {isConnected &&  address?.toLowerCase() === "0x0A4364714594A83BA624D0890B7B2997E3B9b47D".toLowerCase() && (
          <div>
            <Button onClick={OwnerGlobalPkgUpline}>Provide</Button>
          </div>
        )}
      </div>
      <div className="grid grid-cols-1 grid-rows-[max-content_1fr] md:grid-cols-3 gap-2 grid-row">


        {
        // proPowerDataloading ? (
        //   Array(10).fill(null).map((_, index) => (
        //     <PackageCard
        //       //@ts-ignore
        //       data={"Loading"}
        //       key={index}
        //       type="x_power_global"
        //       varient="empty"
        //       name="Loading..."
        //       onActivate={() => { }}
        //     />
        //   ))
        // ) : (
          proPowerData?.data?.map((data: any, index: number) => {
            const queryParam = searchParams.toString();

            // 
            let varient: any = "empty";

            if (activate === 1) activate = 2;
            if (data.status === false && activate === 0) activate = 1;

            if (activate === 0) {
              varient = "x-power-global";
            } else if (activate === 1 && address === currentUser?.address && gloabalDataPowxxermartix?.data?.x_power_global_on) {
              varient = "activate";
            }

            const slot = index + 1;

            if (varient === "empty" || varient === "activate") {
              return (
                <div   key={index} 
                // initial={{ opacity: 0, y: 50 }}
                // whileInView={{ opacity: 1, y: 0 }}
                // viewport={{ once: false, amount: 0.2 }}
                // transition={{ duration: 0.5, delay: index * 0.1 }}
                 >
                  <PackageCard
                    data={data}
                    varient={varient}
                    onActivate={async () => await ActivatePackage(slot, data.amount,"x_power_global")}
                    name={proPowerData?.name}
                    type="x_power_global"
                    loading={loadingPkg?.pkg === slot && loadingPkg?.type === "x_power_global"}
                  />
                  {showPopup && varient === "activate" && (
                    <PopupPkgMessage
                      Package={`Slot ${slot}`}
                      name={"x_global"}
                      amount={data.amount}
                      type="x_power_global"
                      onClose={handleClose}
                      varient="x_global"
                      onActivate={async () => await ActivatePackage(slot, data.amount,"x_power_global")}
                      loading={loadingPkg?.pkg === slot && loadingPkg?.type === "x_power_global"}
                    />
                  )}
                </div>
              );
            }
            else {
              return (
                <div  key={index} 
                // initial={{ opacity: 0, y: 50 }}
                // whileInView={{ opacity: 1, y: 0 }}
                // viewport={{ once: false, amount: 0.2 }} 
                // transition={{ duration: 0.5, delay: index * 0.1 }}
                 >
                  
                  <Link onClick={() => {
                    // setprogram(data);
                  }}
                    to={`/programs/x-power-global/${data.pkg}?${queryParam}`}
                  >
                    <XProPowerGlobalCard data={data} />
                  </Link>


                </div>

              );
            }
          })
        // )
        }


      </div>

      <div className="mt-[3%]">

      </div>

    </div>

  );
};


// redirectUrl = {"/programs-list/" + program?.type}


