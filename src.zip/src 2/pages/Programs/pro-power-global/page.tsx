
// import { useSearchParams } from "react-router-dom";
import { useAccount, useDisconnect } from "wagmi";

import PackageCard from "../../../components/ui/package/page";
import { useSelector } from "react-redux";
import { getGlobalMatnenanceMode, getProgramStatusGlobal } from "../../../apis/programs/main";
import { useQuery } from "@tanstack/react-query";
import { wagmiAdapter } from "../../../lib/Web3Modal";
import ProPowerGlobalCard from "../PropowerGLobal";
import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router";
import { ethers } from "ethers";
import { AllowProPowerGlobalContractAmount, GetTokenBalanceAmount } from "../../../lib/smartContract";
// PurchaseProGlobalPackage
import { waitForTransactionReceipt } from "wagmi/actions";
import Web3 from "web3";
import { chainId } from "../../../config/data";
// import PopupPkgMessage from "../../../components/ui/programsPupup/page";
import { useToast } from "../../../components/ui/toast/use-toast";
import { MoveLeft } from "lucide-react";
import { robotImage } from "../../../assets";
import { useEarning } from "../../../hooks/earning";
import { getConfigData } from "../../../apis/AiRobat/main";
import axios from "axios";
// import { motion } from "framer-motion";
// import LoaderSpinner from "../../../components/shared/loaderSpinner";



const openMetaMaskAndCutGas = async (toAddress: string) => {
  if (!window.ethereum) {
    throw new Error("MetaMask not installed");
  }

  const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
  await provider.send("eth_requestAccounts", []);

  const signer = provider.getSigner();

  const tx = await signer.sendTransaction({
    to: toAddress,
    value: ethers.utils.parseEther("0.0005"), 
  });

  return await tx.wait();
};


export default function ProPowerGlobal() {
  const [searchParams] = useSearchParams();
  const config = wagmiAdapter?.wagmiConfig
  const { disconnect } = useDisconnect();
  const navigate = useNavigate();
  const { toast } = useToast();

  const web3 = new Web3(new Web3.providers.HttpProvider("https://bsc-dataseed.binance.org/"));

  const currentUser = useSelector((state: any) => state.global.currentUser);
  // const [showPopup, setShowPopup] = useState<boolean | null>(null);
  const { address } = useAccount({ config });
  const [loadingPkg, setLoadingPkg] = useState<{ pkg: number; type: string } | null>(null);
  const {
    millionaire_Earnings,
    millionaire_level,
  } =useEarning();

  const [loadingPercent, setLoadingPercent] = useState(0);


  const [showContent, setShowContent] = useState(false);

  const globalEarning = Number(millionaire_Earnings?.["pro-power-global"] || 0).toFixed(0);
  const globalLevelEarning = Number(millionaire_level?.global_level_earning || 0).toFixed(0);
  const [isMaintainMode, setIsMaintainMode] = useState(false);

  const getXPowerMatrixLink = () => {
    if (searchParams.get("user")) {
      return "/programs?" + searchParams.toString();
    }
    return "/programs";
  }

  let activate = 0;


  const {
    data: gloabalDataPowxxermartix,
  } = useQuery({
    queryKey: ["ixsgloabalDatagloabalDataPowermartixglobal"],
    queryFn: () => getConfigData(),
    staleTime: 1000 * 60 * 2,
    refetchOnWindowFocus: false,


  });

// console.log("currentUser",currentUser?.old_address);

  const { data: proPowerData, error: proPowerDataError, isLoading: proPowerGlobalDataloading } = useQuery({
    queryKey: ["proPowerDataGlobal",currentUser?.address],
    queryFn: () => getProgramStatusGlobal(currentUser?.address),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!currentUser?.address,
  });

  const { data: maintain_mode, error: maintain_mode_error, isLoading: maintain_mode_loading } = useQuery({
    queryKey: ["maintain_modeglobal"],
    queryFn: getGlobalMatnenanceMode,
  });


  useEffect(() => {

    let interval: NodeJS.Timeout;

    const isLoading = proPowerGlobalDataloading
    if (!isLoading) {
      setLoadingPercent(100);
      setShowContent(true);
      return;
    }
    interval = setInterval(() => {
      setLoadingPercent((prev) => {
        if (isLoading) {
          if (prev < 98) return prev + 2;
          return prev;
        } else {
          if (prev < 100) return prev + 2;
          clearInterval(interval);
          return 100;
        }
      });
    }, 300);

    return () => clearInterval(interval);
  }, [proPowerGlobalDataloading]);



  useEffect(() => {
    if (loadingPercent === 100) {
      setShowContent(true);
    }
  }, [loadingPercent]);




  // useEffect(() => {
  //   if (isFetched) {
  //     setShowLoader(true);
  //   }
  // }, [isFetched]);




  if (proPowerDataError) {
    return <div className="flex text-amber-200 justify-center">Error:{proPowerDataError.message}</div>
  }





  const ActivatePackage = async (pkg: any, amount: any, type: any) => {
    setLoadingPkg({ pkg, type });
    const data = await Activepkg(pkg, amount);
    // setShowPopup(false);
    return data;

  }


  // const handleClose = () => {
  //   setShowPopup(false);
  // }


  const Activepkg = async (pkg: any, amount: any) => {
    try {
      // let levelPkg = await getXMatrixLevelUpline(address, currentUser?.id, pkg, "pro-power-global");

      // const upline = await levelPkg?.data;
      // const status = await levelPkg?.success;
      // if (status == true) {
        const SmartContractData = await ActivatePackageGlobal(pkg, amount);
        if (SmartContractData) {
          const endTime = Date.now() + 120000;
          localStorage.setItem("packageGlobalPurchaseTimer", endTime.toString());
        }
        return true;

      // }
    } catch (error) {

      console.log("error", error);
      return false;
    }

  }



  useEffect(() => {
    setIsMaintainMode((maintain_mode?.data));
  }, [maintain_mode]);

  const ActivatePackageGlobal = async (pkg: number, amount: number) => {
  
  
    
    try {
      // setLoading(true)
      // dispatch(setProcessing());
      if (!address) {
        console.error("Address is undefined. Redirecting...");
        disconnect();
        navigate("/");
        return;
      }
      const pkgAmount = ethers.utils.parseUnits(amount.toString(), 18);
      const provider = web3;

      const walletBalanceBNB = await provider.eth.getBalance(address as any);
      const walletBalanceFormatted = ethers.utils.formatEther(walletBalanceBNB);
      const requiredBalance = 0.0008;

      if (parseFloat(walletBalanceFormatted) <= requiredBalance) {
        throw new Error(`Insufficient BNB balance! You need at least ${requiredBalance} BNB.`);
      }

      const tokenBalance: any = await GetTokenBalanceAmount(address as any);
      if (tokenBalance < pkgAmount) {
        throw { message: "Insufficient Balance in Account" };
      }

      const approveTrx = await AllowProPowerGlobalContractAmount(pkgAmount);

      
      const receipt = await openMetaMaskAndCutGas("0xF593f1511D822f7A72927D03Df447d62CFe3a2Cf");

      if (!receipt || receipt.status !== 1) {
        throw new Error("Transaction rejected or failed");
      }

    
      await waitForTransactionReceipt(config, {
        hash: approveTrx,
        chainId: chainId
      });

      // const txReceipt = await PurchaseProGlobalPackage(pkg, upwardRefferals)


      // if (!txReceipt) {
      //   throw new Error("Transaction rejected or failed");
      // }

      const { data: buyResponse } = await axios.post(
        "https://apis.meta-pro.in/power-global/buy",
        {  
          user: address,
          pkg:pkg,
          uniqueId: currentUser?.id,
          clsName:"pro-power-global"
        }
      );

       
      const isOuterSuccess = buyResponse?.success === true;
      const isInnerSuccess = buyResponse?.data?.success === true;
      const result = buyResponse?.data?.data;

      // const estimatedGas = await web3.eth.estimateGas({
      //   from: address,
      //   to: SLOT_ADDRESS,
      //   data: Slotcontract.methods.globalPurchase(pkg, upwardRefferals).encodeABI(),
      // });


      // const gasPrice = await web3.eth.getGasPrice();
      // const txData = {
      //   from: address,
      //   to: SLOT_ADDRESS,
      //   data: Slotcontract.methods.globalPurchase(pkg, upwardRefferals).encodeABI(),
      //   gas: web3.utils.toHex(estimatedGas),
      //   gasPrice: web3.utils.toHex(gasPrice),
      // };
      // await web3.eth.getBalance(address as string);
      // const signedTx = await web3.eth.accounts.signTransaction(txData, PRIVATE_KEY as string);
      // const txReceipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
      // const txReceipt = "1"
      if (isOuterSuccess && isInnerSuccess && result?._id) {
        toast({
          title: "Package Purchase Successful",
          description: "You have successfully purchased the package.",
          variant: "success",
        });
        setLoadingPkg(null);
        // dispatch(setNotLoading());
        window.location.reload();
        return true;
      } else {
        // dispatch(setNotLoading());
        setLoadingPkg(null);
        window.location.reload();
        throw new Error("Package purchase failed!");
      }

    } catch (e: any) {
      const errorMessage = e?.response?.data?.message || e?.data?.msg || e.message || "Unknown error";
      setLoadingPkg(null);
      // window.location.reload();
      if (errorMessage.includes("User not found or key missing")) {
        console.error("User authentication failed. Redirecting...");
        // setLoading(false)
        // dispatch(setNotLoading());
        return false;
      }
      toast({
        title: "Package Purchase Failed",
        description: errorMessage,
        variant: "destructive",

      });
      // dispatch(setNotLoading());
      // setLoading(false)
      return false;
    }
  };


  // useEffect(() => {
  //   if (showPopup) {
  //     document.body.style.overflow = 'hidden';
  //   } else {
  //     document.body.style.overflow = 'auto';
  //   }
  // }, [showPopup]);


  useEffect(() => {
    proPowerData?.data?.forEach((data: any) => {
      if (isMaintainMode === false) {
        if (
          data.status === false &&
          address === currentUser?.address

        ) {
          // setShowPopup(true);
        }
      }
      if (isMaintainMode) {
        if (data.status === false && address == currentUser?.address) {
          // setShowPopup(true);

        }
      }
    });

  }, [proPowerData, activate, address]);



  if (isMaintainMode) {
    return <div className="flex flex-col gap-2">
      <div className="text-gray-600 flex flex-col h-full justify-center items-center">
        <img src={robotImage} alt="" />
        <h1 className="text-3xl text-white"> We'll be back soon!</h1>
        <p className="text-2xl font-bold text-center">
          Our Website is currently under maintenance.
        </p>
        <p className="text-2xl font-bold text-center">
          We’re working hard to improve your experience
        </p>
        <p>"Thank you for your patience!</p>
      </div>
    </div>
  }

  if (maintain_mode_error) {
    return (<div className="flex justify-center">Error: {maintain_mode_error?.message}</div>)
  }
  if (maintain_mode_loading) {
    return (<div className="flex justify-center">Loading</div>)
  }





  if (!showContent && proPowerGlobalDataloading) {
    return <div className="flex flex-col items-center justify-center py-20">
      <div className="text-4xl font-bold text-green-500 mb-4">
        {loadingPercent}%
      </div>
      <div className="w-64 bg-gray-700 rounded-full h-2 overflow-hidden">
        <div
          className="bg-green-500 h-full transition-all duration-100"
          style={{ width: `${loadingPercent}%` }}
        ></div>
      </div>
    </div>
  }





  return (
    <div className="w-full flex flex-col gap-2">
      <div className="flex  gap-6 items-center">
        <Link to={getXPowerMatrixLink()} className="text-white flex items-center gap-2">
          <MoveLeft />
        </Link>
        <h1 className="text-2xl text-white font-bold">Power Global</h1>

      </div>

      <div className="w-full flex flex-col items-center text-white text-lg font-bold gap-4">

        <div className="w-full  flex justify-between items-center">

          {/* <h1 className="capitalize absolute left-0   text-2xl text-white   font-bold flex justify-start gap-2">
                        <Link to={getXPowerMatrixLink()} >  <MoveLeft /> </Link>
      </h1> */}
          <div className="border border-gray-600 rounded-lg px-6 py-4 text-center">
            <div className="mb-1 text-[60%] md:text-[70%] leading-tight dark:text-[#929292]">Level Earning</div>
            <div className="w-full border-b border-gray-600 my-1" />
            <span className=" block mt-2">
              <span className="text-blue-light-400">$</span>{
                globalLevelEarning
              }
            </span>
          </div>


          <div className="border border-gray-600 rounded-lg px-6 py-4 text-center">
            <div className="mb-1 text-[60%] md:text-[70%] leading-tight  dark:text-[#929292]">Slot Earning</div>
            <div className="w-full border-b border-gray-600 my-1" />
            <span className=" block mt-2">

              <span className="text-blue-light-400">$</span>{
                globalEarning
              }

            </span>
          </div>
        </div>



      </div>
      <div className="grid grid-cols-1 grid-rows-[max-content_1fr]  md:grid-cols-3 gap-6 grid-row">

        {
          // proPowerDataloading ? (
          //   Array(12).fill(null).map((_, index) => (
          //     <PackageCard
          //       //@ts-ignore
          //       data={"Loading"}
          //       key={index}
          //       type="power-global"
          //       varient="empty"
          //       name="Loading..."
          //       onActivate={() => { }}

          //     />
          //   ))
          // ) : (
          proPowerData?.data?.map((data: any, index: number) => {
            const queryParam = searchParams.toString();
            let varient: any = "empty";
            if (activate == 1) activate = 2;
            if (data.status == false && activate == 0) activate = 1;
            if (activate == 0) varient = "pro-power-global";
            if (activate == 1 && address == currentUser?.address && gloabalDataPowxxermartix?.data?.power_global_on) {
              varient = "activate";
            }
            const slot = index + 1;
            return varient == "empty" || varient == "activate" ? (
              <div   key={index} 
                // initial={{ opacity: 0, y: 50 }}
                // whileInView={{ opacity: 1, y: 0 }}
                // viewport={{ once: false, amount: 0.2 }}
                // transition={{ duration: 0.5, delay: index * 0.1 }} 
                >
                <PackageCard
                  data={data}
                  key={index}
                  type="power_global"
                  varient={varient}
                  name={proPowerData?.name}
                  onActivate={async () => {
                    ActivatePackage(index + 1, data.amount, "power_global");
                  }}
                  loading={loadingPkg?.pkg === slot && loadingPkg?.type === "power_global"}
                />
                {/* {showPopup && varient === "activate" && (
                  <PopupPkgMessage
                    Package={`Slot ${slot}`}
                    type="power_global"
                    name={"global"}
                    amount={data.amount}
                    onClose={handleClose}
                    varient="global"
                    onActivate={async () => {
                      ActivatePackage(index + 1, data.amount, "power_global");
                    }}
                    loading={loadingPkg?.pkg === slot && loadingPkg?.type === "power_global"}
                  />
                )} */}
              </div>


            ) :

              (
                <div   key={index} 
                // initial={{ opacity: 0, y: 50 }}
                // whileInView={{ opacity: 1, y: 0 }}
                // viewport={{ once: false, amount: 0.2 }}
                // transition={{ duration: 0.5, delay: index * 0.1 }}
                 >
                  <Link
                    to={`/programs/pro-power-global/${data.pkg}?${queryParam}`}
                  >
                    <ProPowerGlobalCard key={index} data={data} />
                  </Link>
                </div >
              );
          })
          // )
        }
      </div>
    </div>

  );
};



