import Button  from "../../components/ui/button/page";
import { getBackgroundOfPackagematrx } from "../../lib/utils";

import {
  RefreshCcw,
  Users,
} from "lucide-react";
import { useState } from "react";
import { getProgramMatrixCycle_Pkg } from "../../apis/programs/main";
import { useSelector } from "react-redux";
import { useQuery } from "@tanstack/react-query";

const CurrentLine = () => {
  const [curretCycle, setCurrentCycle] = useState(-1);
  const currentUser = useSelector((state:any) => state.global.currentUser);
  // error:proPowerDataError,isLoading:proPowerDataloading 
  const {data:pkgData} = useQuery({
    queryKey: ["pkgData"],
    queryFn:() =>getProgramMatrixCycle_Pkg(1,currentUser?.address,1),
  });

  return (
    <div className="w-full flex flex-col gap-2">
      <div className="flex flex-col md:grid md:grid-cols-12  h-full gap-2">
       
        <div className="md:col-span-10 h-full w-full p-8 pb-2 border rounded-md">
        <div className="flex justify-center relative md:w-3/4 w-full mx-auto">
        

            <svg viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <style>
          {`    .line {
                stroke: black;
                stroke-width: 5 ;
              }
                .line2 {
                stroke: black;
                stroke-width: 5 ;
              }
            
                .line3 {
                stroke: black;
                stroke-width: 2 ;
              }
              .text {
                fill: white;
                font-size: 18px;
                text-anchor: middle;
                font-family: Arial, sans-serif;
                dominant-baseline: middle;
              }`}
            </style>
          </defs>

          <circle className="line3" cx="300" cy="300" r="205" fill="black" />
          <circle className="line2 " cx="300" cy="300" r="130" fill="" />
          
          <circle className="line2" cx="300" cy="300" r="60" fill="none" />

          
           <g>
        <g transform="translate(300,300)">
          <g>
            <path d="M 0,-123 A 123 123 0 0 1 123,0 L 0,0 Z"  fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[0][2].type : "")}/>
            <path d="M -123,0 A 123 123 0 0 1 0,-123 L 0,0 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[0][1].type : "")}/>
            <path d="M 0,123 A 123 123 0 0 1 -123,0 L 0,0 Z"  fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[0][0].type : "")}/>
            <path d="M 123,0 A 123 123 0 0 1 0,123 L 0,0 Z"   fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[0][3].type : "")} />
          </g>

          <line x1="0" y1="-130" x2="0" y2="-60" stroke="black" stroke-width="5" />
          <line x1="0" y1="-130" x2="0" y2="-60" stroke="black" stroke-width="5" transform="rotate(90 0 0)" />
          <line x1="0" y1="-130" x2="0" y2="-60" stroke="black" stroke-width="5" transform="rotate(180 0 0)" />
          <line x1="0" y1="-130" x2="0" y2="-60" stroke="black" stroke-width="5" transform="rotate(270 0 0)" />

        </g>
      </g>

          <circle cx="300" cy="300" r="70" fill="black" />
          

          <text x="300" y="300" className="text" font-size="18" font-weight="bold">
            You
          </text>
          <g transform="translate(300,300)">
            <g>
              <path d="M 0 -200 A 200 200 0 0 1 76 -185 L 49 -118 A 130 130 0 0 0 0 -130 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][8].type : "")}/>
              <path d="M 76 -185 A 200 200 0 0 1 141 -141 L 91 -91 A 130 130 0 0 0 49 -118 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][9].type : "")} />
              <path d="M 141 -141 A 200 200 0 0 1 185 -76 L 118 -49 A 130 130 0 0 0 91 -91 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][10].type : "")} />
              <path d="M 185 -76 A 200 200 0 0 1 200 0 L 130 0 A 130 130 0 0 0 118 -49 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][11].type : "")} />
              <path d="M 200 0 A 200 200 0 0 1 185 76 L 118 49 A 130 130 0 0 0 130 0 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][12].type : "")} />
              <path d="M 185 76 A 200 200 0 0 1 141 141 L 91 91 A 130 130 0 0 0 118 49 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][13].type : "")} />
              <path d="M 141 141 A 200 200 0 0 1 76 185 L 49 118 A 130 130 0 0 0 91 91 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][14].type : "")} />
              <path d="M 76 185 A 200 200 0 0 1 0 200 L 0 130 A 130 130 0 0 0 49 118 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][15].type : "")}/>
            </g>

        
            <g>


            <path d="M -76 185 A 200 200 0 0 0 0 200 L 0 130 A 130 130 0 0 1 -49 118 Z"    fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][0].type : "")} /> 

            <path d="M -141 141 A 200 200 0 0 0 -76 185 L -49 118 A 130 130 0 0 1 -91 91 Z"fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][1].type : "")}/>
            <path d="M -185 76 A 200 200 0 0 0 -141 141 L -91 91 A 130 130 0 0 1 -118 49 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][2].type : "")} />
            <path d="M -200 0 A 200 200 0 0 0 -185 76 L -118 49 A 130 130 0 0 1 -130 0 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][3].type : "")}/>
            <path d="M -185 -76 A 200 200 0 0 0 -200 0 L -130 0 A 130 130 0 0 1 -118 -49 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][4].type : "")} />
            <path d="M -141 -141 A 200 200 0 0 0 -185 -76 L -118 -49 A 130 130 0 0 1 -91 -91 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][5].type : "")} />
            <path d="M -76 -185 A 200 200 0 0 0 -141 -141 L -91 -91 A 130 130 0 0 1 -49 -118 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][6].type : "")} />
            <path d="M 0 -200 A 200 200 0 0 0 -76 -185 L -49 -118 A 130 130 0 0 1 0 -130 Z" fill={getBackgroundOfPackagematrx(pkgData?.data ? pkgData?.data[1][7].type : "")} />
              
          
              
            
              
            

            </g>
        <g>
        <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(0)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(22.5)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(45)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(67.5)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(90)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(112.5)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(135)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(157.5)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(180)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(202.5)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(225)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(247.5)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(270)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(292.5)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(315)" />
              <line className="line2" x1="0" y1="-200" x2="0" y2="-127" transform="rotate(337.5)" />
        </g>

            <g>
            </g>
          </g>
         </svg>


          </div>
          <div className="flex mt-5 gap-4 justify-center">
            <div>
              Partners
              <div className="flex gap-2">
                <Users />
                {pkgData?.member}{" "}
              </div>
            </div>
            <div>
              Recycle
              <div className="flex gap-2">
                <RefreshCcw />
                {pkgData?.recycle}{" "}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex w-full flex-col justify-center p-2 text-center">
        <p>Cycle</p>
        <div className="flex w-full justify-center">
          {pkgData?.prevCycle != -1 ? <Button onClick={() => setCurrentCycle(pkgData?.prevCycle)}>{pkgData?.prevCycle}</Button> : <></>}
          <Button className="text-foreground">{curretCycle == -1 ? pkgData?.recycle : curretCycle}</Button>
          {pkgData?.nextCycle != -1 ? <Button onClick={() => setCurrentCycle(pkgData?.nextCycle)}>{pkgData?.nextCycle}</Button> : <></>}
        </div>
      </div>
    </div>
  );
};

export default CurrentLine;




