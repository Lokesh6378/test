import axiosInstance from "../../utils/axios.instance";
import { GET_MPS_DONATION_AMOUNT, GET_MPS_DONATION_MAINTENANCMODE, GET_MPS_DONATION_ON_OFF, GET_MPS_DONATION_TRANSACTIONS } from "./api.path";


export let getDonationTransaction= (address:string) => {
    return axiosInstance
    .get(`${GET_MPS_DONATION_TRANSACTIONS}${address}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching investor data:", error);
        throw error;
      });
  };


  export let getDonationAmount = (address: string) => {
    return axiosInstance
    .get(`${GET_MPS_DONATION_AMOUNT}${address}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching donation amount:", error);
        throw error;
      });
  }

  export let getDonationOnOff = () => { 
    return axiosInstance
    .get(`${GET_MPS_DONATION_ON_OFF}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching donation on/off status:", error);
        throw error;
      });
  }

  export let getDonationMaintenanceMode = () => {
    return axiosInstance
    .get(`${GET_MPS_DONATION_MAINTENANCMODE}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching donation maintenance mode status:", error);
        throw error;
      });
  }
