export let GET_MPS_DONATION_TRANSACTIONS='/mps-donation/transactions?userAddress='
export let GET_MPS_DONATION_AMOUNT ='/mps-donation?userAddress='
export let GET_MPS_DONATION_ON_OFF ='/global/donate-on_off'
export let GET_MPS_DONATION_MAINTENANCMODE ='/global/donate-maintenance'
