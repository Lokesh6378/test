export let NFT_REFLERS_BUY_USER='/utility/get-mroyalty-direct-reffer?userAddress='
export let NFT_BUY_TRANSACTION='/utility/get/MNft/buy-transaction?userAddress='
export let NFT_SELL_TRANSACTION='/utility/get/MNft/sell-transaction?userAddress='
export let  Mroyalty_direct_reffe ='/utility/get-mroyalty-direct-reffer?userAddress='
export let BUYERS_LEVEL_EARNING='/utility/buy-mnft/level-earning?userAddress='
export let MNFT_LEVEL_TRANSACTION='/utility/mnft/level-transaction?address='
export let GLOBAL_NFT_MAINTENANCE ='/global/mnft-maintenance/'
export let GLOBAL_MNFT_SELL_MAINTENANCE ='/global/mnft-sell/maintenance/'
export let GLOBAL_MNFT_BUY_MAINTENANCE ='/global/mnft-buy/maintenance/'

// export let NFT_B_REFLERS_BUY_USER='/utility/get-broyalty-direct-reffer?userAddress='
export let NFT_B_BUY_TRANSACTION='/utility/get/BNft/buy-transaction?userAddress='
export let NFT_B_SELL_TRANSACTION='/utility/get/BNft/sell-transaction?userAddress='
export let Broyalty_direct_reffe ='/utility/get-broyalty-direct-reffer?userAddress='
export let BUYERS_LEVEL_EARNING_B='/utility/buy-bnft/level-earning?userAddress='
export let BNFT_LEVEL_TRANSACTION='/utility/bnft/level-transaction?address='


