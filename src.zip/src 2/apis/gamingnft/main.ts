// import axiosInstance from "../../utils/axios.instance";
// import { NFT_REFLERS_BUY_USER } from "./api.path";
// import axios from "axios";

// export let getNftMillionaireBuy= (address:string,uniqueId:any,NftName:any) => {
//     const BASE_URL = "https://3110e66083d5.ngrok-free.app/";
//     return axios
//     .get(`${BASE_URL}utility/get-mroyalty-direct-reffer?userAddress=${address}&uniqueId=${uniqueId}&NftName=${NftName}`)
//       .then((response) => {
//         return response;
//       })
//       .catch((error) => {
//         console.error("Error fetching investor data:", error);
//         throw error;
//       });
//   };


// utility/get/MNft/sell-transaction?userAddress=
// https://3110e66083d5.ngrok-free.app/utility/get/MNft/sell-transaction?userAddress=0xea87e4aeB9d69B2fa52c605855e595F3e1bE65a6
import axios from "axios";
import axiosInstance from "../../utils/axios.instance";
import { BNFT_LEVEL_TRANSACTION, Broyalty_direct_reffe, BUYERS_LEVEL_EARNING, BUYERS_LEVEL_EARNING_B, GLOBAL_MNFT_BUY_MAINTENANCE, GLOBAL_MNFT_SELL_MAINTENANCE, GLOBAL_NFT_MAINTENANCE, MNFT_LEVEL_TRANSACTION, Mroyalty_direct_reffe, NFT_B_BUY_TRANSACTION, NFT_B_SELL_TRANSACTION, NFT_BUY_TRANSACTION, NFT_SELL_TRANSACTION } from "./api.path";

// export let getNftMillionaireBuy = async (
//   address: string,
//   uniqueId: any,
//   NftName: any
// ) => {
//   const BASE_URL = "https://3110e66083d5.ngrok-free.app";

//   try {
//     const response = await axios.get(
//       `${BASE_URL}/utility/get-mroyalty-direct-reffer`,
//       {
//         params: {
//           userAddress: address,
//           uniqueId: uniqueId,
//           NftName: NftName,
//         },
//         headers: { 'ngrok-skip-browser-warning': 'true' },
//       }
//     );

//     return response.data; // ✅ sirf data return karna hai
//   } catch (error: any) {
//     console.error(
//       "Error fetching investor data:",
//       error.response?.data || error.message
//     );
//     throw error;
//   }
// };



// export let getNftMillionaireSell = async(
//   address: string,
//   uniqueId: any,
//   NftName: any
// ) => {
//   const BASE_URL = "https://3110e66083d5.ngrok-free.app";

//   try {
//     const response = await axios.get(
//       `${BASE_URL}/utility/get-mroyalty-direct-reffer`,
//       {
//         params: {
//           userAddress: address,
//           uniqueId: uniqueId,
//           NftName: NftName,
//         },
//         headers: { 'ngrok-skip-browser-warning': 'true' },
//       }
//     );

//     return response.data; // ✅ sirf data return karna hai
//   } catch (error: any) {
//     console.error(
//       "Error fetching investor data:",
//       error.response?.data || error.message
//     );
//     throw error;
//   }
// };


// export let getNftMillionaireBuy= (address:string,uniqueId:any,NftName:any) => {
//     const BASE_URL = "https://3110e66083d5.ngrok-free.app/";
//     return axios
//     .get(`${BASE_URL}utility/get-mroyalty-direct-reffer?userAddress=${address}&uniqueId=${uniqueId}&NftName=${NftName}`)
//       .then((response) => {
//         return response;
//       })
//       .catch((error) => {
//         console.error("Error fetching investor data:", error);
//         throw error;
//       });
//   };


// /?userAddress=


// export let getNftMillionaireSellTransaction = async(
//   address: string,

// ) => {
//   const BASE_URL = "https://3110e66083d5.ngrok-free.app";

//   try {
//     const response = await axios.get(
//       `${BASE_URL}/utility/get/MNft/sell-transaction`,
//       {
//         params: {
//           userAddress: address,
//         },
//         headers: { 'ngrok-skip-browser-warning': 'true' },
//       }
//     );

//     return response.data; 
//   } catch (error: any) {
//     console.error(
//       "Error fetching investor data:",
//       error.response?.data || error.message
//     );
//     throw error;
//   }
// };

// export let getNftMillionaireBuyTransaction = async(
//   address: string,

// ) => {
//   const BASE_URL = "https://3110e66083d5.ngrok-free.app";

//   try {
//     const response = await axios.get(
//       `${BASE_URL}/utility/get/MNft/buy-transaction`,
//       {
//         params: {
//           userAddress: address,
//         },
//         headers: { 'ngrok-skip-browser-warning': 'true' },
//       }
//     );

//     return response.data; 
//   } catch (error: any) {
//     console.error(
//       "Error fetching investor data:",
//       error.response?.data || error.message
//     );
//     throw error;
//   }
// };


export let getNftMillionaireConvert = async (
  userAddress: string,
  privateKey: string,
  NftName: string,
  times: any
) => {
  const BASE_URL = "https://apis.meta-pro.in";

  const payload = {
    userAddress,
    privateKey,
    NftName,
    times,
  };

  try {
    const response = await axios.post(
      `${BASE_URL}/utility/convert-millionaire-nft`,
      payload,
      {
        headers: { "ngrok-skip-browser-warning": "true" },
      }
    );

    return response.data;
  } catch (error: any) {
    console.error(
      "Error converting NFT:",
      error.response?.data || error.message
    );
    throw error;
  }
};




export let getNftMillionaireSellTransaction = (address: string) => {
  return axiosInstance
    .get(`${NFT_SELL_TRANSACTION}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};


export let getNftMillionaireBuyTransaction = (address: string) => {
  return axiosInstance
    .get(`${NFT_BUY_TRANSACTION}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export let getNftMillionaireSell = (address: string,uniqueId:any,NftName:any) => {
  return axiosInstance
    .get(`${Mroyalty_direct_reffe}${address}&uniqueId=${uniqueId}&NftName=${NftName}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};


export let getNftMillionaireBuy = (address: string,uniqueId:any,NftName:any) => {
  return axiosInstance
    .get(`${Mroyalty_direct_reffe}${address}&uniqueId=${uniqueId}&NftName=${NftName}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};


export let getLevelNFT = (address: string) => {
  return axiosInstance
    .get(`${BUYERS_LEVEL_EARNING}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};



export let getLevelNFTTransaction = (address: string,skip:any) => {
  return axiosInstance
    .get(`${MNFT_LEVEL_TRANSACTION}${address}&type=${"levelEarning"}&skip=${skip}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};



export let getNftBillionaireConvert = async (
  userAddress: string,
  privateKey: string,
  NftName: string,
  times: any
) => {
  const BASE_URL = "http://localhost:3002/";

  const payload = {
    userAddress,
    privateKey,
    NftName,
    times,
  };

  try {
    const response = await axios.post(
      `${BASE_URL}utility/convert-billionaire-nft`,
      payload,
      {
        headers: { "ngrok-skip-browser-warning": "true" },
      }
    );

    return response.data;
  } catch (error: any) {
    console.error(
      "Error converting NFT:",
      error.response?.data || error.message
    );
    throw error;
  }
};

export let getNftBillionaireSellTransaction = (address: string) => {
  return axiosInstance
    .get(`${NFT_B_SELL_TRANSACTION}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export let getNftBillionaireBuyTransaction = (address: string) => {
  return axiosInstance
    .get(`${NFT_B_BUY_TRANSACTION}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export let getNftBillionaireBuy = (address: string,uniqueId:any,NftName:any) => {
  return axiosInstance
    .get(`${Broyalty_direct_reffe}${address}&uniqueId=${uniqueId}&NftName=${NftName}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export let getLevelNFTBillionaire = (address: string) => {
  return axiosInstance
    .get(`${BUYERS_LEVEL_EARNING_B}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};



export let getLevelNFTTransactionBillionaire = (address: string,skip:any) => {
  return axiosInstance
    .get(`${BNFT_LEVEL_TRANSACTION}${address}&type=${"levelEarning"}&skip=${skip}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};




export let getGlobalNftMaintenance = () => {
  return axiosInstance
  .get(`${GLOBAL_NFT_MAINTENANCE}`)
  // .get("http://localhost:3002/global/mnft-maintenance/") 
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
}


export let getBuyNftMaintenance = () => {
  return axiosInstance
  .get(`${GLOBAL_MNFT_BUY_MAINTENANCE}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
}


export let getSEllNftMaintenance = () => {
  return axiosInstance
  .get(`${GLOBAL_MNFT_SELL_MAINTENANCE}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
}
