import { GET_ALL_STATUS_ADDRESS, GET_BILLIONAIRE_EARNINGS, GET_BILLIONAIRE_LEVEL_EARNINGS, GET_DIRECT_PARTNERS, GET_EARNING_DATA, GET_GLOABL_LAUNCH_PROGRAM, GET_GLOBAL_REGISTER_MAINTENANCE_MODE, GET_LOTTERY_ALL_DATA, GET_MILLIONAIRE_LEVEL_EARNINGS, GET_STAKING_DETAILS, GET_TOTAL_ACTIVE_BILLTONATRE, GET_TOTAL_ACTIVE_MILLIONAIRE, GET_TOTAL_INACTIVE_BILLTONATRE, GET_TOTAL_INACTIVE_MILLIONAIRE, GET_TOTAL_PATNERS, GET_TOTAL_PROFIT, GET_TRILLIONAIRE_EARNINGS, GET_TRILLIONAIRE_LEVEL_EARNINGS, GET_USER_MULTI_STATUS, GET_USER_PATNERS_BILLIONAIRE, GET_USER_TOTAL_TEAM,UPDATE_SINGLE_USER_ADDRESS } from "./api.path";

import axiosInstance from "../../utils/axios.instance";
import { getuniqueid } from "../../lib/smartContract";
export let getEarningData = (address: string) => {
  return axiosInstance
    .get(`${GET_EARNING_DATA}${address}`)
    .then((response) => {
      // console.log(".......wwwww.......",response.data)
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getTotalTeam = (address: any, uniqueId: any) => {
  return axiosInstance
    .get(`${GET_USER_TOTAL_TEAM}${address}&uniqueId=${uniqueId}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getUserTotalPatners = (address: any) => {
  return axiosInstance
    .get(`${GET_TOTAL_PATNERS}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getMillionaireLevelEarnings = (address: any) => {
  return axiosInstance
    .get(`${GET_MILLIONAIRE_LEVEL_EARNINGS}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getBillionaireLevelEarnings = (address: any) => {
  return axiosInstance
    .get(`${GET_BILLIONAIRE_LEVEL_EARNINGS}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getBillionaireEarnings = (address: any) => {
  return axiosInstance
    .get(`${GET_BILLIONAIRE_EARNINGS}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getUserPatnersBillionaire = (address: any) => {
  return axiosInstance
    .get(`${GET_USER_PATNERS_BILLIONAIRE}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};


export let getUserMultiStatus = (address: any) => {
  return axiosInstance
    .get(`${GET_USER_MULTI_STATUS}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getTotalInactiveBillionaire = (address: any, page: any) => {
  return axiosInstance
    .get(`${GET_TOTAL_INACTIVE_BILLTONATRE}${address}&page=${page}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getTotalActiveBillionaire = (address: any, page: any) => {
  return axiosInstance
    .get(`${GET_TOTAL_ACTIVE_BILLTONATRE}${address}&page=${page}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getTotalActiveMillionaire = (address: any, page: any) => {
  return axiosInstance
    .get(`${GET_TOTAL_ACTIVE_MILLIONAIRE}${address}&page=${page}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getTotalInactiveMillionaire = (address: any, page: any) => {
  return axiosInstance
    .get(`${GET_TOTAL_INACTIVE_MILLIONAIRE}${address}&page=${page}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};


export let getAllStatusAddress = (address: any) => {
  return axiosInstance
    .get(`${GET_ALL_STATUS_ADDRESS}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getGlobalRegisterMaintenanceMode = () => {
  return axiosInstance
    .get(`${GET_GLOBAL_REGISTER_MAINTENANCE_MODE}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching global register maintenance mode:", error);
      throw error;
    });
};

export let getGlobalLaunchProgram = () => {
  return axiosInstance
    .get(`${GET_GLOABL_LAUNCH_PROGRAM}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching global launch program:", error);
      throw error;
    });
};

export let getTotalProfit = async (userAddress: any) => {
  const uniqueId = await getuniqueid(userAddress);
  return axiosInstance
    .get(`${GET_TOTAL_PROFIT}${uniqueId}&address=${userAddress}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getDirectPartners = async (userAddress: any) => {
  const uniqueId = await getuniqueid(userAddress);
  return axiosInstance
    .get(`${GET_DIRECT_PARTNERS}${uniqueId}&address=${userAddress}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getLotteryAllData = async (userAddress: any) => {
  const uniqueId = await getuniqueid(userAddress);
  return axiosInstance
    .get(`${GET_LOTTERY_ALL_DATA}${uniqueId}&address=${userAddress}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getStatingDetails = async (userAddress: any) => {
  const uniqueId = await getuniqueid(userAddress);
  return axiosInstance
    .get(`${GET_STAKING_DETAILS}${uniqueId}&address=${userAddress}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let updateSingleUserData = async (oldaddress:any,new_address: any) => {
  // const uniqueId = await getuniqueid(userAddress);
  return axiosInstance
    .get(`${UPDATE_SINGLE_USER_ADDRESS}${oldaddress}&new_address=${new_address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
   
    });
  };
  

  export let getTrillionaireLevelEarnings = (address: any,uniqueId:any) => {
    return axiosInstance
      .get(`${GET_TRILLIONAIRE_LEVEL_EARNINGS}${uniqueId}&address=${address}`)
      .then((response) => {
        // console.log(".......wwwwwwwww.......",response.data)
        return response.data;
      }
      )
      .catch((error) => {
        console.error("Error fetching earnings data:", error);
        throw error;
      });
  };
  
  export let getTrillionaireEarnings = (address: any,uniqueId:any) => {
    return axiosInstance
      .get(`${GET_TRILLIONAIRE_EARNINGS}${uniqueId}&address=${address}`)
      .then((response) => {
        // console.log(".......wwwwwwwww.......",response.data)
        return response.data;
      }
      )
      .catch((error) => {
        console.error("Error fetching earnings data:", error);
        throw error;
      });
  };
