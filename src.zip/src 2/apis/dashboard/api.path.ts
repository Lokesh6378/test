export let GET_EARNING_DATA='/user/millionaire/earnings?address='
export let GET_USER_TOTAL_TEAM = "/user/total-team?address="
export let GET_TOTAL_PATNERS = "/user/level?level=1&address="
export let GET_MILLIONAIRE_LEVEL_EARNINGS = "/user/level_earning?address="
export let GET_BILLIONAIRE_LEVEL_EARNINGS = "/user/getbillionaire/userLevelEarning?address="
export let GET_BILLIONAIRE_EARNINGS = "/user/billionaire/earnings?address="
export let GET_USER_PATNERS_BILLIONAIRE = "/user/level-billionaire?level=1&address="
export let GET_USER_MULTI_STATUS="/program/all/multi/status?address="
export let GET_TOTAL_INACTIVE_BILLTONATRE ="/user/get-inactive-team-billionaire?address="
export let GET_TOTAL_ACTIVE_BILLTONATRE ="/user/get-active-team-billionaire?address="
export let GET_TOTAL_ACTIVE_MILLIONAIRE ="/user/get-active-team?address="
export let GET_TOTAL_INACTIVE_MILLIONAIRE ="/user/get-inactive-team?address="
export let GET_ALL_STATUS_ADDRESS = "/program/all/status?address="
export let GET_GLOBAL_REGISTER_MAINTENANCE_MODE = "/global/register-maintenance"
export let GET_GLOABL_LAUNCH_PROGRAM = "/global/launch-program"
export let GET_TOTAL_PROFIT='/user/total-earnings?uniqueId='
export let GET_DIRECT_PARTNERS='/user/total-direct-partners?uniqueId='
export let GET_LOTTERY_ALL_DATA='/user/get/user-lottery-details?uniqueId='
export let GET_STAKING_DETAILS = "/user/get/user-staking-details?uniqueId="
export let UPDATE_SINGLE_USER_ADDRESS='/user/update-single-user-address?old_address='

export let GET_TRILLIONAIRE_LEVEL_EARNINGS = "/user/gettrillionaire/userLevelEarning?uniqueId="
export let GET_TRILLIONAIRE_EARNINGS = "/user/trillionaire/earnings?uniqueId="
// export let GET_