export let GET_PROGRAM_PKG_PRO_POWER_MATRIX='/program/pkg/pro-power-matrix?address='
export let GET_POWER_MATRIX_MAINTENANCE_MODE="/global/matrix-maintenance"
export let GET_POWER_MATRIX_PKG_CYCLE="/program/pkg/pro-power-matrix/"
export let GET_PROGRAM_PKG_PRO_POWER_GLOBAL="/program/pkg/pro-power-global?address="
export let GET_POWER_GLOBAL_MAINTENANCE_MODE="/global/global-maintenance"
export let GET_POWER_GLOBAL_PKG_CYCLE="/program/pkg/pro-power-global/"
export let GET_BILLIONAIRE_PKG_X_POWER_GLOBAL="/billionaire/pkg/x-power-global?address="
export let GET_BILLIONAIRE_PKG_X_POWER_MATRIX="/billionaire/pkg/x-power-matrix?address="
export let GET_BILLIONAIRE_PKG_X_POWER_MATRIX_MAINTENANCE_MODE="/global/x-power-matrix-maintenance"
export let GET_BILLIONAIRE_PKG_X_POWER_GLOBAL_MAINTENANCE_MODE="/global/x-power-global-maintenance"
export let GET_BILLIONAIRE_PKG_X_POWER_MATRIX_CYCLE="/billionaire/pkg/x-power-matrix/"
export let GET_BILLIONAIRE_PKG_X_POWER_GLOBAL_CYCLE = `/billionaire/pkg/x-power-global/`;
export let GET_X_MATRIX_LEVEL_UPLINE="/user/get-uplines?userAddress="
export let GET_USER_KEY="/user/get-key?userAddress="
export let GET_USER_PARTNERS_BILLIONAIRE_LIST='/user/total-direct-partners-billionaire-list?level=1&address='
export let GET_USER_PARTNERS_MILLIONAIRE_LIST='/user/total-direct-partners-millioniare-list?level=1&address='
export let USER_MIGRRATE_POWER_MATRIX_LEVEL='/user/migrate-power-matrix-level-incomes?old_address='
export let USER_MIGRRATE_POWER_MATRIX_PKGS='/user/migrate-power-matrix-pkgs?old_address='
export let USER_MIGRRATE_POWER_MATRIX_CURRENT_CYLE='/user/migrate-power-matrix-current-cycle?old_address='
export let USER_MIGRRATE_POWER_X_MATRIX_LEVEL='/user/migrate-x-power-matrix-level-incomes?old_address='
export let USER_MIGRRATE_POWER_X_MATRIX_PKGS='/user/migrate-x-power-matrix-pkgs?old_address='
export let USER_MIGRRATE_POWER_X_MATRIX_CURRENT_CYLE='/user/migrate-x-power-matrix-current-cycle?old_address='

export let GET_PROGRAM_PKG_2PRO_POWER="/program/pkg/2x-matrix?address="
export let GET_PROGRAM_PKG_2PRO_POWER_global="/program/pkg/2x-global?address="
export let GET_TRILLIONAIRE_PKG_2_X_POWER_MATRIX="/program/pkg/2x-matrix-matrix/"
export let GET_TRILLIONAIRE_PKG_2_X_POWER_GLOBAL = "/program/pkg/2x-global/";

export let GET_TRILLIONAIRE_PKG_2_X_POWER_MATRIX_CYCLE="/program/pkg/2x-matrix-pre-cycle/"
export let GET_TRILLIONAIRE_PKG_2_X_POWER_GLOBAL_CYCLE = '/program/pkg/2x-global-prev-cycle/';



