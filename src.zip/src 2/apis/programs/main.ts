import axiosInstance from "../../utils/axios.instance";
import { GET_BILLIONAIRE_PKG_X_POWER_GLOBAL, GET_BILLIONAIRE_PKG_X_POWER_GLOBAL_CYCLE, GET_BILLIONAIRE_PKG_X_POWER_GLOBAL_MAINTENANCE_MODE, GET_BILLIONAIRE_PKG_X_POWER_MATRIX, GET_BILLIONAIRE_PKG_X_POWER_MATRIX_CYCLE, GET_BILLIONAIRE_PKG_X_POWER_MATRIX_MAINTENANCE_MODE, GET_POWER_GLOBAL_MAINTENANCE_MODE, GET_POWER_GLOBAL_PKG_CYCLE, GET_POWER_MATRIX_MAINTENANCE_MODE, GET_POWER_MATRIX_PKG_CYCLE, GET_PROGRAM_PKG_2PRO_POWER, GET_PROGRAM_PKG_2PRO_POWER_global, GET_PROGRAM_PKG_PRO_POWER_GLOBAL, GET_PROGRAM_PKG_PRO_POWER_MATRIX, GET_TRILLIONAIRE_PKG_2_X_POWER_GLOBAL, GET_TRILLIONAIRE_PKG_2_X_POWER_GLOBAL_CYCLE, GET_TRILLIONAIRE_PKG_2_X_POWER_MATRIX, GET_TRILLIONAIRE_PKG_2_X_POWER_MATRIX_CYCLE, GET_USER_KEY, GET_USER_PARTNERS_BILLIONAIRE_LIST, GET_USER_PARTNERS_MILLIONAIRE_LIST, GET_X_MATRIX_LEVEL_UPLINE, USER_MIGRRATE_POWER_MATRIX_CURRENT_CYLE, USER_MIGRRATE_POWER_MATRIX_LEVEL, USER_MIGRRATE_POWER_MATRIX_PKGS, USER_MIGRRATE_POWER_X_MATRIX_CURRENT_CYLE, USER_MIGRRATE_POWER_X_MATRIX_LEVEL, USER_MIGRRATE_POWER_X_MATRIX_PKGS } from "./api.path";


export const getProgramStatusMatrix = async (address: string) => {

    
  return axiosInstance
  .get(`${GET_PROGRAM_PKG_PRO_POWER_MATRIX}${address}`)
  .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
      })
};

export const getMatriMatnenanceMode = async () => {
  return axiosInstance
    .get(GET_POWER_MATRIX_MAINTENANCE_MODE)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching program status:", error);
      throw error;
    });
};

// export const getProgramMatrix = async (pkg: string,address: string) => {
//   return axiosInstance
//     .get(`${GET_POWER_MATRIX_PKG}${pkg}${address}`)
//     .then((response) => {
//       return response.data;
//     })
//     .catch((error) => {
//       console.error("Erroretching program status:", error);
//       throw error;
//     });
// };

// export const getProgramMatrixCycle_Pkg = async (pkg: any,address: any,cycle: any) => {
//   return axiosInstance
//     .get(`${GET_POWER_MATRIX_PKG_CYCLE}${pkg}${address}${cycle}`)
//     .then((response) => {
//       return response.data;
//     })
//     .catch((error) => {
//       console.error("Erroretching program status:", error);
//       throw error;
//     });
// };


export const getProgramMatrixCycle_Pkg = async (pkg: any,address: any, cycle: any) => {
  const url =
    cycle < 0
      ? `${GET_POWER_MATRIX_PKG_CYCLE}${pkg}?address=${address}`
      : `${GET_POWER_MATRIX_PKG_CYCLE}${pkg}?address=${address}&cycle=${cycle}`;

  try {
    const response = await axiosInstance.get(url);
    return response.data;
  } catch (error) {
    console.error("Error fetching program status:", error);
    throw error;
  }
};

export const getProgramStatusGlobal = async (address: string) => {
  return axiosInstance
  .get(`${GET_PROGRAM_PKG_PRO_POWER_GLOBAL}${address}`)
  .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
      })
};

export const getGlobalMatnenanceMode = async () => {
  return axiosInstance
    .get(GET_POWER_GLOBAL_MAINTENANCE_MODE)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching program status:", error);
      throw error;
    });
};


// export const getProgramGlobalCycle_Pkg = async (pkg: any,address: any,cycle: any) => {
//   return axiosInstance
//     .get(`${GET_POWER_GLOBAL_PKG_CYCLE}${pkg}${address}${cycle}`)
//     .then((response) => {
//       return response.data;
//     })
//     .catch((error) => {
//       console.error("Erroretching program status:", error);
//       throw error;
//     });
// };


export const getProgramGlobalCycle_Pkg = async (pkg: any,address: any, cycle: any) => {
  const url =
    cycle < 0
      ? `${GET_POWER_GLOBAL_PKG_CYCLE}${pkg}?address=${address}`
      : `${GET_POWER_GLOBAL_PKG_CYCLE}${pkg}?address=${address}&cycle=${cycle}`;

  try {
    const response = await axiosInstance.get(url);
    return response.data;
  } catch (error) {
    console.error("Error fetching program status:", error);
    throw error;
  }
};

export const getBillionaireXPowerGlobal = async (address: string) => {
  return axiosInstance
  .get(`${GET_BILLIONAIRE_PKG_X_POWER_GLOBAL}${address}`)
  .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
      })
};

export const getBillionaireXPowerMatrix = async (address: string) => {
  return axiosInstance
  .get(`${GET_BILLIONAIRE_PKG_X_POWER_MATRIX}${address}`)
  .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
      })
};

export const getBillionaireXPowerMatrixMatnenanceMode = async () => {
  return axiosInstance
    .get(GET_BILLIONAIRE_PKG_X_POWER_MATRIX_MAINTENANCE_MODE)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching program status:", error);
      throw error;
    });
};

// export const getBillionaireXPowerMatrixCycle_Pkg = async (pkg: any,address: any,cycle: any) => {
//   return axiosInstance
//     .get(`${GET_BILLIONAIRE_PKG_X_POWER_MATRIX_CYCLE}${pkg}${address}${cycle}`)
//     .then((response) => {
//       return response.data;
//     })
//     .catch((error) => {
//       console.error("Erroretching program status:", error);
//       throw error;
//     });
// };

export const getBillionaireXPowerGlobalMatnenanceMode = async () => {
  return axiosInstance
    .get(GET_BILLIONAIRE_PKG_X_POWER_GLOBAL_MAINTENANCE_MODE)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching program status:", error);
      throw error;
    });
};


export const getBillionaireXPowerMatrixCycle_Pkg = async (pkg: any,address: any, cycle: any) => {
  const url =
    cycle < 0
      ? `${GET_BILLIONAIRE_PKG_X_POWER_MATRIX_CYCLE}${pkg}?address=${address}`
      : `${GET_BILLIONAIRE_PKG_X_POWER_MATRIX_CYCLE}${pkg}?address=${address}&cycle=${cycle}`;

  try {
    const response = await axiosInstance.get(url);
    return response.data;
  } catch (error) {
    console.error("Error fetching program status:", error);
    throw error;
  }
};

export const getBillionaireXPowerGlobalCycle_Pkg = async (pkg: any,address: any, cycle: any) => {
  const url =
    cycle < 0
      ? `${GET_BILLIONAIRE_PKG_X_POWER_GLOBAL_CYCLE}${pkg}?address=${address}`
      : `${GET_BILLIONAIRE_PKG_X_POWER_GLOBAL_CYCLE}${pkg}?address=${address}&cycle=${cycle}`;

  try {
    const response = await axiosInstance.get(url);
    return response.data;
  } catch (error) {
    console.error("Error fetching program status:", error);
    throw error;
  }
};



export const getXMatrixLevelUpline = async (address: any,uniqueId:any,levelPkg:any,clsName:any) => {
  
  return axiosInstance
  .get(`${GET_X_MATRIX_LEVEL_UPLINE}${address}&uniqueId=${uniqueId}&pkg=${levelPkg}&clsName=${clsName}`)
  .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
      })
};

export const getUserKey = async (address: any, uniqueId: any) => {  
  if (typeof window === "undefined") {
    console.warn("getFromKey called on server. localStorage not available.");
    return null;
  }

  const token = localStorage.getItem('jwttoken');

  
  if (!token) {
    console.warn("JWT token not found in  Storage.");
    return null;
  }

  return axiosInstance
    .get(`${GET_USER_KEY}${address}&uniqueId=${uniqueId}`, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching user key:", error);
      throw error;
    });
};

export const getUserBillionaireList = async (address: any) => {

  return axiosInstance
    .get(`${GET_USER_PARTNERS_BILLIONAIRE_LIST}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching user key:", error);
      throw error;
    });
};

export const getUserMillionaireList = async (address: any) => {
  return axiosInstance
    .get(`${GET_USER_PARTNERS_MILLIONAIRE_LIST}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching user key:", error);
      throw error;
    });
};


export const MigratePowerMarixLevel = async (address: any,newaddress:any) => {

  return axiosInstance
    .get(`${USER_MIGRRATE_POWER_MATRIX_LEVEL}${address}&new_address=${newaddress}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching user key:", error);
      throw error;
    });
};

export const MigratePowerMarixPkgs = async (address: any,newaddress:any) => {
  return axiosInstance
    .get(`${USER_MIGRRATE_POWER_MATRIX_PKGS}${address}&new_address=${newaddress}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching user key:", error);
      throw error;
    });
};

export const MigratePowerMarixCycle = async (address: any,newaddress:any) => {
  return axiosInstance
    .get(`${USER_MIGRRATE_POWER_MATRIX_CURRENT_CYLE}${address}&new_address=${newaddress}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching user key:", error);
      throw error;
    });
};


export const MigrateXPowerMarixLevel = async (address: any,newaddress:any) => {

  return axiosInstance
    .get(`${USER_MIGRRATE_POWER_X_MATRIX_LEVEL}${address}&new_address=${newaddress}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching user key:", error);
      throw error;
    });
};

export const MigrateXPowerMarixPkgs = async (address: any,newaddress:any) => {
  return axiosInstance
    .get(`${USER_MIGRRATE_POWER_X_MATRIX_PKGS}${address}&new_address=${newaddress}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching user key:", error);
      throw error;
    });
};

export const MigrateXPowerMarixCycle = async (address: any,newaddress:any) => {
  return axiosInstance
    .get(`${USER_MIGRRATE_POWER_X_MATRIX_CURRENT_CYLE}${address}&new_address=${newaddress}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching user key:", error);
      throw error;
    });
};



export const get2ProgramStatus= async (address: string) => {
  return axiosInstance
  .get(`${GET_PROGRAM_PKG_2PRO_POWER}${address}`)
  .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
      })
};

export const get2ProgramStatusGlobal= async (address: string) => {
  return axiosInstance
  .get(`${GET_PROGRAM_PKG_2PRO_POWER_global}${address}`)
  .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
      })
};


export const getTrillionaire2XPowerMartixCycle_Pkg = async (pkg: any,address: any, cycle: any) => {
  const url =
    cycle < 0
      ? `${GET_TRILLIONAIRE_PKG_2_X_POWER_MATRIX}${pkg}?address=${address}`
      : `${GET_TRILLIONAIRE_PKG_2_X_POWER_MATRIX_CYCLE}${pkg}?address=${address}&cycle=${cycle}`;

  try {
    const response = await axiosInstance.get(url);
    return response.data;
  } catch (error) {
    console.error("Error fetching program status:", error);
    throw error;
  }
};


export const getTrillionaire2XPowerGlobalCycle_Pkg = async (
  pkg: any,
  address: any,
  cycle: any
) => {
  const url =
    cycle < 0
      ? `${GET_TRILLIONAIRE_PKG_2_X_POWER_GLOBAL}${pkg}?address=${address}`
      : `${GET_TRILLIONAIRE_PKG_2_X_POWER_GLOBAL_CYCLE}${pkg}?address=${address}&cycle=${cycle}`;

  try {
    const response = await axiosInstance.get(url);
    return response.data;
  } catch (error) {
    console.error("Error fetching program status:", error);
    throw error;
  }
};


