import axiosInstance from "../../../utils/axios.instance";
import { GET_LEVEL_BILLIONAIRE, GET_LEVEL_COUNT, GET_LEVEL_MILLIONAIRE } from "./api.path";

export let getLevelTeam = async (level: any,address:any) => {
  return axiosInstance
    .get(`${GET_LEVEL_COUNT}${level}&address=${address}`)
    .then((response: any) => {
      return response.data;
    })
    .catch((error: any) => {
      console.error("Error fetching level team data:", error);
      throw error;
    });
};

export let getLevelBillionaire = async (level: any,address:any) => {
  return axiosInstance
    .get(`${GET_LEVEL_BILLIONAIRE}${level}&address=${address}`)
    .then((response: any) => {
      return response.data;
    })
    .catch((error: any) => {
      console.error("Error fetching level team data:", error);
      throw error;
    });
};

export let getLevelMillionaire = async (level: any,address:any) => {
    return axiosInstance
      .get(`${GET_LEVEL_MILLIONAIRE}${level}&address=${address}`)
      .then((response: any) => {
        return response.data;
      })
      .catch((error: any) => {
        console.error("Error fetching level team data:", error);
        throw error;
      });
  };
