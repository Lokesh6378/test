export let GET_LEVEL_COUNT='/user/level_count?level='
export let GET_LEVEL_BILLIONAIRE='/user/level-billionaire?level='
export let GET_LEVEL_MILLIONAIRE='/user/level?level='