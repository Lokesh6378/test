export let  GET_ROYALTY_TRANSACTION ='/user/royalty/transaction?address=';
export let GET_ROYALTY_ID='/user/royaltyUsersId'
export let GET_ROYALTY_USER= '/user/royaltyUsers'
export let GET_ROYALTY_USER_TAG_TIMER = '/user/royaltyQualification?address='
export let GET_NFTQUALIFICATION='/user/nft?address='
export let GET_NFT_HOLDERS = '/utility/get-nfts-holders'
export let GET_CHART_DATA_INVESTMENT = '/graph/month-wise-invested?address='