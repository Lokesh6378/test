import axiosInstance from "../../../utils/axios.instance";
import { GET_CHART_DATA_INVESTMENT, GET_NFT_HOLDERS, GET_NFTQUALIFICATION, GET_ROYALTY_ID, GET_ROYALTY_TRANSACTION, GET_ROYALTY_USER, GET_ROYALTY_USER_TAG_TIMER } from "./api.path";

export let getRoyaltyTransaction = async (address: string) =>  {
  return axiosInstance
    .get(`${GET_ROYALTY_TRANSACTION}${address}`)
    .then((response:any) => {
      return response.data;
    })
    .catch((error:any) => {
      console.error("Erroretching program status:", error);
      throw error;
    });
};

export let getRoyaltyUsersId = async () => {
  return axiosInstance
    .get(`${GET_ROYALTY_ID}`)
    .then((response:any) => {
      return response.data;
    })
    .catch((error:any) => {
      console.error("Error fetching royalty users ID:", error);
      throw error;
    });
};

export let getRoyaltyUsers = async () => {
  return axiosInstance
    .get(`${GET_ROYALTY_USER}`)
    .then((response:any) => {
      return response.data;
    })
    .catch((error:any) => {
      console.error("Error fetching royalty users:", error);
      throw error;
    });
};

export let getRoyaltyUsersTagTimer = async (address: string) => {
  return axiosInstance
    .get(`${GET_ROYALTY_USER_TAG_TIMER}${address}`)
    .then((response:any) => {
      return response.data;
    })
    .catch((error:any) => {
      console.error("Error fetching royalty users:", error);
      throw error;
    });
};


export let getNftQualification = async (address: string) => {
  return axiosInstance
    .get(`${GET_NFTQUALIFICATION}${address}`)
    .then((response:any) => {
      return response.data;
    })
    .catch((error:any) => {
      console.error("Error fetching royalty users:", error);
      throw error;
    });
};

export let getNftHolders = async () => {
  return axiosInstance
    .get(`${GET_NFT_HOLDERS}`)
    .then((response:any) => {
      return response?.data;
    })
    .catch((error:any) => {
      console.error("Error fetching NFT holders:", error);
      throw error;
    });
};

 


const normalizeResponse = (res: any) =>
  Array.isArray(res) ? res : Array.isArray(res?.data) ? res.data : [];

export let getChartDataInvestment = async (address: any, uniqueId: string) => {
  return axiosInstance
    .get(`${GET_CHART_DATA_INVESTMENT}${address}&uniqueId=${uniqueId}`)
    .then((r) => normalizeResponse(r.data))
    .catch(() => []);
};


