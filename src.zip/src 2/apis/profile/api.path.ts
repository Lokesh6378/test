export let GET_PROGRAM_STATUS='/program/all/status?address='
export let POST_USER_PEOFILES_UPDATE= '/user/update/user-details'