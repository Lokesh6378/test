import { GET_PROGRAM_STATUS, POST_USER_PEOFILES_UPDATE } from "./api.path";
import axiosInstance from "../../utils/axios.instance";
import { GET_EARNING_DATA } from "../dashboard/api.path";

export let getPro= (address:any) => {
    return axiosInstance
      .get(`${GET_EARNING_DATA}${address}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching earnings data:", error);
        throw error; 
      });
  };

export let getProgramStatus = async (address:any) => {
  return axiosInstance
    .get(`${GET_PROGRAM_STATUS}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching program status:", error);
      throw error; 
    }); 

  };

  export const userUpdateProfile = async (data: any, config = {}) => {
 
    return axiosInstance
      .post(POST_USER_PEOFILES_UPDATE, data, config)
      .then((response) => response)
      .catch((error) => {
        console.error("Error updating user profile:", error);
        throw error;
      });
  };
  
  


