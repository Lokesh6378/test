export let GET_COIN_DATA='/api/get/coin/data?userAddress='
export let POST_START_COIN_MINING ='/api/start/coin/mining'
export let GET_LEVEL_TRANSACTION ='/api/user/coin/level-transaction?userAddress='

export let BOOSTER_BUY_REFFERS = '/utility/get-musd-direct-reffer?userAddress='
export let BOOSTERPLAN ='/utility/booster-pkg/status?userAddress=' 
export let MUSD_LEVEL_EARNING='/utility/musd/level-earning?userAddress='
export let MUSD_BOOSTER_TRANSACTION='/utility/get/booster/buy-transaction?userAddress='
export let MUSD_LEVEL_TRANSACTION='/utility/musd/level-transaction?address='
export const UPDATE_MINING_RATE = "/utility/update-mining-rate";
export let POST_COIN_MINING_DATA ='/api/get/coin/data?userAddress='


// userAddress: currentUser?.address ?? "",
// uniqueId: currentUser?.id ?? "",
// /