
import axiosInstance from "../../utils/axios.instance.mining"
import axiosInstance1 from "../../utils/axios.instance";;
import { BOOSTER_BUY_REFFERS, BOOSTERPLAN, GET_COIN_DATA, GET_LEVEL_TRANSACTION, MUSD_BOOSTER_TRANSACTION, MUSD_LEVEL_EARNING, MUSD_LEVEL_TRANSACTION, POST_COIN_MINING_DATA, POST_START_COIN_MINING, UPDATE_MINING_RATE } from "./api.path";
export let getCoinData = (address: string,uniqueId: string) => {
  return axiosInstance
    .get(`${GET_COIN_DATA}${address}&uniqueId=${uniqueId}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export  let  postAiStartCoinMining = (data: any) => {
  return axiosInstance
    .post(`${POST_START_COIN_MINING}`, data, {
      headers: {
        "Content-Type": "application/json",
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching stacking earning data:", error);
      throw error;
    });
};


export const getAiCoinMining = (userAddress: any, uniqueId: any) => {
  return axiosInstance
    .get(
      `${POST_COIN_MINING_DATA}${userAddress}&uniqueId=${uniqueId}`,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    )
    .then((response) => response.data)
    .catch((error) => {
      console.error("Error fetching mining data:", error);
      throw error;
    });
};


export let getLevelTransactions = ( address: string,uniqueId:any,limit: number,page: number) => {
  return axiosInstance
    .get(`${GET_LEVEL_TRANSACTION}${address}&uniqueId=${uniqueId}&limit=${limit}&page=${page}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};



// export let getBoosterplanBuyReffer = async (
//   address: string,
//   uniqueId: any,
// ) => {
//   const BASE_URL = "https://3110e66083d5.ngrok-free.app";
//   try {
//     const response = await axios.get(
//       `${BASE_URL}/utility/get-musd-direct-reffer`,
//       {
//         params: {
//           userAddress: address,
//           uniqueId: uniqueId,
//         },
//         headers: { 'ngrok-skip-browser-warning': 'true' },
//       }
//     );

//     return response.data; 
//   } catch (error: any) {
//     console.error(
//       "Error fetching investor data:",
//       error.response?.data || error.message
//     );
//     throw error;
//   }
// };


// export let getBoosterTransaction = async (
//   address: string,
// ) => {
//   const BASE_URL = "https://3110e66083d5.ngrok-free.app";
//   try {
//     const response = await axios.get(
//       `${BASE_URL}/utility/get/booster/buy-transaction`,
//       {
//         params: {
//           userAddress: address,
//         },
//         headers: { 'ngrok-skip-browser-warning': 'true' },
//       }
//     );

//     return response.data; 
//   } catch (error: any) {
//     console.error(
//       "Error fetching investor data:",
//       error.response?.data || error.message
//     );
//     throw error;
//   }
// };


// export let getBoosterPlan = async (address: string) => {
//   try {
//     const response = await axios.get(
//       `https://3110e66083d5.ngrok-free.app${BOOSTERPLAN}${address}`,
//    {
//     headers: { 'ngrok-skip-browser-warning': 'true' },
//    }
//     );
//     return response.data;
//   } catch (error:any) {
//     console.error("Error fetching NFT Qualification:", error?.response?.data || error.message);
//     throw error;
//   }
// };

// export let getMusdLevel = async (address: string) => {
//   try {
//     const response = await axios.get(
//       `https://3110e66083d5.ngrok-free.app${MUSD_LEVEL_EARNING}${address}`,
//    {
//     headers: { 'ngrok-skip-browser-warning': 'true' },
//    }
//     );
//     return response.data;
//   } catch (error:any) {
//     console.error("Error fetching NFT Qualification:", error?.response?.data || error.message);
//     throw error;
//   }
// };


export let getBoosterPlan = (address: string) => {
  return axiosInstance1
    .get(`${BOOSTERPLAN}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};


export let getMusdLevel = (address: string) => {
  return axiosInstance1
    .get(`${MUSD_LEVEL_EARNING}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export let getBoosterTransaction = (address: string) => {
  return axiosInstance1
    .get(`${MUSD_BOOSTER_TRANSACTION}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export let getBoosterplanBuyReffer = (address: string,uniqueId:any,planId:any) => {
  return axiosInstance1
    .get(`${BOOSTER_BUY_REFFERS}${address}&uniqueId=${uniqueId}&planId=${planId}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};


export let getLevelMusdTransaction = (address: string,skip:any) => {
  return axiosInstance1
    .get(`${MUSD_LEVEL_TRANSACTION}${address}&type=levelEarning&skip=${skip}`) 
    .then((response) => response.data)
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};


export let UpdateMiningRate = (oldAddress?: string, newAddress?: string) => {
  let url = `${UPDATE_MINING_RATE}?newAddress=${newAddress}`;

  if (oldAddress && oldAddress !== newAddress) {
    url += `&oldAddress=${oldAddress}`;
  }

  return axiosInstance1.get(url).then((response) => response.data);
};




// 