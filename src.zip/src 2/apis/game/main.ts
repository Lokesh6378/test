
import axiosInstance from "../../utils/axios.instance";
import { BLASTROO_ACHIVERS_LIST, BLASTROO_DEPOSIT_TRANSACTION, BLASTROO_EARNING, BLASTROO_MAGIC_DEPOSIT_ACTIVE_UPLINE, BLASTROO_MAGIC_LEVEL_TRANSACTION, BLASTROO_MAGIC_WITHDRAW_TRANSACTION, BLASTROO_USER_DETAILS, GET_BLASTROO_CHECK_EARNINIG, GET_BLASTROO_CHECK_EARNINIG_BY_TAG, GET_BLASTROO_EARNINIG, GET_BLASTROO_MAINTENANCMODE, GET_BLASTROO_OLD_ADDRESS, GET_BLASTROO_ON_OFF, POST_BLASTROO_MAGIC_WITHDRAW } from "./api.path";

export let BlastrooActiveUpline = async (userAddress: any, uniqueId: any, planId: any) => {
    try {
        const response = await axiosInstance.get(
            `${BLASTROO_MAGIC_DEPOSIT_ACTIVE_UPLINE}${userAddress}&uniqueId=${uniqueId}&planId=${planId}`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching Blastroo Active Upline:", error);
        throw error;
    }
}

export let BlastrooEarning = async (userAddress: string) => {
    try {
        const response = await axiosInstance.get(
            `${BLASTROO_EARNING}${userAddress}`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching Blastroo Earnings:", error);
        throw error;
    }
}

export let BlastrooDeposittransaction = async (userAddress: string) => {
    try {
        const response = await axiosInstance.get(
            `${BLASTROO_DEPOSIT_TRANSACTION}${userAddress}`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching Blastroo Earnings V2:", error);
        throw error;
    }
}

export let BlastrooAchiversList = async () => {
    try {
        const response = await axiosInstance.get(
            `${BLASTROO_ACHIVERS_LIST}`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching Blastroo Active Upline List:", error);
        throw error;
    }



}


export let BlastrooUserDetails = async (userAddress: string) => {
    try {
        const response = await axiosInstance.get(
            `${BLASTROO_USER_DETAILS}${userAddress}`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching Blastroo User Details:", error);
        throw error;
    }
}


// 

export let getBlastrooMagicWithhdrawTransaction = async (userAddress: string) => {
    try {
        const response = await axiosInstance.get(
            `${BLASTROO_MAGIC_WITHDRAW_TRANSACTION}${userAddress}`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching Booster Transactions:", error);
        throw error;
    }
}

export let getBoosterMagicLevelTransaction = async (userAddress: string) => {
    try {
        const response = await axiosInstance.get(
            `${BLASTROO_MAGIC_LEVEL_TRANSACTION}${userAddress}`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching Booster Transactions:", error);
        throw error;
    }
}


export  let  postBoosterMagicTagWithdraw = (data: any) => {
    return axiosInstance
      .post(`${POST_BLASTROO_MAGIC_WITHDRAW}`, data, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching stacking earning data:", error);
        throw error;
      });
  };


  export let getBoosterOnOff = () => { 
    return axiosInstance
    .get(`${GET_BLASTROO_ON_OFF}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching Booster on/off status:", error);
        throw error;
      });
  }

  export let getBoosterMaintenanceMode = () => {
    return axiosInstance
    .get(`${GET_BLASTROO_MAINTENANCMODE}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching Booster maintenance mode status:", error);
        throw error;
      });
  }

  export let getBlastrooEarning = (userAddress: string) => {
    return axiosInstance
    .get(`${GET_BLASTROO_EARNINIG}${userAddress}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching stacking earning data:", error);
        throw error;
      });
  }

  export let getBlastrooCheckEarningByTag = (userAddress: string,tag:any) => {
    return axiosInstance
    .get(`${GET_BLASTROO_CHECK_EARNINIG_BY_TAG}${userAddress}&tag=${tag}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching stacking earning data:", error);
        throw error;
      });
  }

  export let getBlastrooCheckEarning = (userAddress: string) => {
    return axiosInstance
    .get(`${GET_BLASTROO_CHECK_EARNINIG}${userAddress}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching stacking earning data:", error);
        throw error;
      });
  }

  export let BlastrooTotalUser = async () => {
    try {
        const response = await axiosInstance.get(
            `/user/blastroo/total-user-list`
        );
        return response.data;
    } catch (error) {
        console.error("Error fetching Blastroo Total User List:", error);
        throw error;
    }
}



export let BlastrooUserOldData = async (userAddress: string) => {
  try {
      const response = await axiosInstance.get(
          `${GET_BLASTROO_OLD_ADDRESS}${userAddress}`
      );
      return response.data;
  } catch (error) {
      console.error("Error fetching Blastroo User Details:", error);
      throw error;
  }
}
