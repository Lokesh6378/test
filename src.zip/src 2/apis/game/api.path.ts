export let BLASTROO_MAGIC_DEPOSIT_ACTIVE_UPLINE='/user/blastroo-magic-deposit-active-upline?userAddress='
export let BLASTROO_EARNING='/user/blastroo/earnings?userAddress='
export let BLASTROO_DEPOSIT_TRANSACTION='/utility/get-balstroo-magic-deposit/trx?userAddress='
export let BLASTROO_ACHIVERS_LIST ='/user/blastroo/achivers-list'
export let BLASTROO_USER_DETAILS='/user/blastroo/user-details?userAddress='
export let BLASTROO_MAGIC_WITHDRAW_TRANSACTION='/utility/get-balstroo-magic-withdraw/trx?userAddress='
export let BLASTROO_MAGIC_LEVEL_TRANSACTION='/utility/get-balstroo-magic-level/trx?userAddress='
export let POST_BLASTROO_MAGIC_WITHDRAW='/utility/withdraw-balstroo-magic-fund'
export let GET_BLASTROO_MAINTENANCMODE ='global/balstroo-maintenance'
export let GET_BLASTROO_ON_OFF ='/global/is-balstroo-active'
export let GET_BLASTROO_EARNINIG='/user/blastroo/earnings?userAddress='
export let GET_BLASTROO_CHECK_EARNINIG_BY_TAG='/utility/balstroo-check-earning-by-tag?userAddress='
export let GET_BLASTROO_CHECK_EARNINIG='/utility/balstroo-check-earning?userAddress='
export let BLASTROO_TOTAL_USER='/user/blastroo/total-user-list'
export let GET_BLASTROO_OLD_ADDRESS='/utility/migrate-blastroo-data?userAddress='


// /