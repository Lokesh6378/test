import axiosInstance from "../../utils/axios.instance";
import { GET_CHART_DATA } from "./api.path";
const normalizeResponse = (res: any) =>
    Array.isArray(res) ? res : Array.isArray(res?.data) ? res.data : [];
  

  
  export let getChartData = async (address: string, uniqueId: any) => {
    return axiosInstance
      .get(`${GET_CHART_DATA}${address}&uniqueId=${uniqueId}`)
      .then((r) => normalizeResponse(r.data))
      .catch(() => []);
  };
  