
// import axios from "axios";
import axiosInstance from "../../utils/axios.instance";
import { GET_ELIGIBLE_STAKING_OFFER_CRIITERIA, GET_ELIGIBLE_STAKING_OFFER_TOP_RANKER, GET_OFFER2, GET_OFFER_2_LIVE_WINING_AMOUNT, GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_1, GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_2, GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_2_TRANSTIONS, GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_TRANSTIONS, GTE_STAKING_OFFER_END_TIME } from "./api.path";


export let getStakingOffertimer = () => {
    return axiosInstance
      .get(`${GTE_STAKING_OFFER_END_TIME}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  }

  export let getEligibleStakingOfferTopRanker = () => {
    return axiosInstance
      .get(`${GET_ELIGIBLE_STAKING_OFFER_TOP_RANKER}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  }

  export let getEligibleStakingOfferCriteria = (userAddress: string) => {
    return axiosInstance
      .get(`${GET_ELIGIBLE_STAKING_OFFER_CRIITERIA}${userAddress}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  }


  export let getOffer2 = (address: string) => {
    return axiosInstance
      .get(`${GET_OFFER2}${address}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  }


  // export let PostOffer2LiveWiningAmount = async (
  //   address: string,
  //   amount: any,
  //   uniqueId: string,
  // ) => {
  //   const BASE_URL = "https://apis.meta-pro.in";
  
  //   const payload = {
  //     address,
  //     amount,
  //     uniqueId,
  //   };
  
  //   try {
  //     const response = await axios.post(
  //       `${BASE_URL}utility/save-airobot-offer-2/winner-list`,
  //       payload,
  //       {
  //         headers: { "ngrok-skip-browser-warning": "true" },
  //       }
  //     );
  
  //     return response.data;
  //   } catch (error: any) {
  //     console.error(
  //       "Error converting NFT:",
  //       error.response?.data || error.message
  //     );
  //     throw error;
  //   }
  // };

  export let getOffer2LiveWiningAmount = () => {
    return axiosInstance
      .get(`${GET_OFFER_2_LIVE_WINING_AMOUNT}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("No winner records found", error);
        throw error;
      });
      
  }



  export let getAiRobotOffer1Withdraw = (
    address: string,
    uniqueId: string,
    privateKey: string,


  ) => {
    // console.log("Fetching weekly withdraw for:", address);
  
    return axiosInstance
      .post(`${GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_1}`, {
        userAddress: address,
        uniqueId,
        privateKey

      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching weekly withdraw data:", error);
        throw error;
      });
  };


  export let getAiRobotOffer2Withdraw = (
    address: string,
    uniqueId: string,
    privateKey: string,


  ) => {
    // console.log("Fetching weekly withdraw for:", address);
  
    return axiosInstance
      .post(`${GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_2}`, {
        userAddress: address,
        uniqueId,
        privateKey

      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching weekly withdraw data:", error);
        throw error;
      });
  };

  // 



  export let getOfferTransaction = (address: string) => {
    return axiosInstance
      .get(`${GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_TRANSTIONS}${address}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  }

  export let getOffer2Transaction = (address: string) => {
    return axiosInstance
      .get(`${GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_2_TRANSTIONS}${address}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  }