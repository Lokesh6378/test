export let GTE_STAKING_OFFER_END_TIME='/utility/get/staking-offer-end-time'
export let GET_ELIGIBLE_STAKING_OFFER_TOP_RANKER ='/utility/get/eligible/staking-offer/top/ranker'
export let GET_ELIGIBLE_STAKING_OFFER_CRIITERIA  ='/utility/get/staking-offer-criteria?userAddress='
export let GET_OFFER2='/utility/get-offer-2?address='
export let GET_OFFER_2_LIVE_WINING_AMOUNT="/utility/get-airobot-offer-2/winner-list"
export let GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_1="/utility/withdraw-ai-robot-offer1"
export let GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_TRANSTIONS="/utility/get-weekly-withdraw/trx?userAddress="
export let GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_2="/utility/withdraw-ai-robot-offer2"
export let GET_OFFER_WITHDRAW_AI_ROBOT_OFFER_2_TRANSTIONS="/utility//get-offer-2-withdraw/trx?userAddress="
