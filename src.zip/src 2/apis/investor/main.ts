import axiosInstance from "../../utils/axios.instance";
import { GET_BILLIONAIRE_TOP_INVESTORS, GET_SELF_BILLIONAIRE_PKG, GET_SELF_BILLIONAIRE_TEAM_MEMBER, GET_SELF_MILLIONAIRE_PKG, GET_SELF_MILLIONAIRE_TEAM_MEMBER, GET_VOLID_SELF_BILLIONAIRE_DIRECT_PARTNER, GTE_MILLIONAIRE_TOP_INVESTORS } from "./api.path";


export let getInvestorMillionaire = () => {
  return axiosInstance
  .get(`${GTE_MILLIONAIRE_TOP_INVESTORS}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching investor data:", error);
      throw error;
    });
};


export let getInvestorBillionaire = () => {
  return axiosInstance
  .get(`${GET_BILLIONAIRE_TOP_INVESTORS}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching investor data:", error);
      throw error;
    });
};

export let getSelfMillionairePkg = (address: string) => {
  return axiosInstance
  .get(`${GET_SELF_MILLIONAIRE_PKG}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching investor data:", error);
      throw error;
    });
};

export let getSelfMillionaireTeamMembers = (address: string) => {
  return axiosInstance
  .get(`${GET_SELF_MILLIONAIRE_TEAM_MEMBER}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching investor data:", error);
      throw error;
    });
};

export let getSelfBillionairePkg = (address: string) => {
  return axiosInstance
  .get(`${GET_SELF_BILLIONAIRE_PKG}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching investor data:", error);
      throw error;
    });
};

export let getSelfBillionaireTeamMembers = (address: string) => {
  return axiosInstance
  .get(`${GET_SELF_BILLIONAIRE_TEAM_MEMBER}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching investor data:", error);
      throw error;
    });
};


export let getSelfBillionaireDirectMember = (address: string) => {
  return axiosInstance
  .get(`${GET_VOLID_SELF_BILLIONAIRE_DIRECT_PARTNER}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching investor data:", error);
      throw error;
    });
};