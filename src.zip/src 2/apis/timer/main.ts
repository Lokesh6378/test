import axiosInstance from "../../utils/axios.instance";
import { GET_MULTPLE_TIMER } from "./api.path";


export let getMultipleTimer = async () => {
  return axiosInstance
    .get(GET_MULTPLE_TIMER)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching multiple timers:", error);
      throw error;
    });
};