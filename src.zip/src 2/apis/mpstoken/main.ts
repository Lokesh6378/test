import axiosInstance from "../../utils/axios.instance";
import { MPS_GET_TOKEN_PRE_COIN, MPS_GET_TOKEN_PRE_USER, MPS_TRX,MPSTOKEN_direct_reffer,MPS_EARNING_TRX, MPS_TOKEN_CLAIM_TRX, MPS_TOKEN_BUTTON_FREE, MPS_TOKEN_BUTTON_PRESALE } from "./api.path";



export let getMpstransactions = async (userAddress:any) => {
  return axiosInstance
    // .get(MPS_TRX)
    .get(`${MPS_TRX}${userAddress}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching multiple timers:", error);
      throw error;
    });
};

// export let MPS_GET_TOKEN_PRE_COIN='/utility/get-token-pre-coin?userAddress='
// export let MPS_GET_TOKEN_PRE_USER='/utility/token-pre-users?userAddress='


export let getMpstokenpreCoin= async (userAddress:any) => {
  return axiosInstance
    // .get(MPS_TRX)
    .get(`${MPS_GET_TOKEN_PRE_COIN}${userAddress}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching multiple timers:", error);
      throw error;
    });
};



export let getMpstokenpreUser = async () => {
  return axiosInstance
    // .get(MPS_TRX)
    .get(`${MPS_GET_TOKEN_PRE_USER}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching multiple timers:", error);
      throw error;
    });
};






export let getMpstokenpreRef = (address: string,uniqueId:any,pkg:any) => {
  return axiosInstance
    .get(`${MPSTOKEN_direct_reffer}${address}&uniqueId=${uniqueId}&pkg=${pkg}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export let getMpsEarningtransactions = async (userAddress:any) => {
  return axiosInstance
    // .get(MPS_TRX)
    .get(`${MPS_EARNING_TRX}${userAddress}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching multiple timers:", error);
      throw error;
    });
};


export let getMpstokenClaimTrx = (address: string,uniqueId:any) => {
  return axiosInstance
    .get(`${MPS_TOKEN_CLAIM_TRX}${address}&uniqueId=${uniqueId}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export let getMpstokenButtonFree = (address: string,uniqueId:any) => {
  return axiosInstance
    .get(`${MPS_TOKEN_BUTTON_FREE}${address}&uniqueId=${uniqueId}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

export let getMpstokenClaimButtonPresale = (address: string,uniqueId:any) => {
  return axiosInstance
    .get(`${MPS_TOKEN_BUTTON_PRESALE}${address}&uniqueId=${uniqueId}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching coin data:", error);
      throw error;
    });
};

// uniqueId , pkg


