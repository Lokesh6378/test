export let MPS_TRX='/utility/mps-token-trx?userAddress='
export let MPS_GET_TOKEN_PRE_COIN='/utility/get-token-pre-coin?userAddress='
export let MPS_GET_TOKEN_PRE_USER='/utility/token-pre-users?userAddress='
export let  MPSTOKEN_direct_reffer ='/utility/get-token-direct-reffer?userAddress='
export let MPS_EARNING_TRX ='/utility/get-mps-earning-trx?address='
export let MPS_TOKEN_CLAIM_TRX ='/mps-token/claim-trx?userAddress='
export let MPS_TOKEN_BUTTON_FREE ='/mps-token/claim-button-free?userAddress='
export let MPS_TOKEN_BUTTON_PRESALE ='/mps-token/claim-button-presale?userAddress='

// export let MPS_TOKEN_CLAIM_TRX ='/mps-token/claim-free-token'
// export let MPS_TOKEN_CLAIM_TRX ='/mps-token/claim-presale-token'


// / 