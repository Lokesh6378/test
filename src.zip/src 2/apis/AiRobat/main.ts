import axios from "axios";
import axiosInstance from "../../utils/axios.instance";
import axiosInstance1 from "../../utils/axios.instance.aiRobot"
import { GET_ACTIVE_USER_IN_STAKING, GET_AI_MINING_MUSD_PKG_S, GET_AI_ROBOT_GET_CURRENT_WEEK, GET_AI_ROBOT_GET_PRE_WEEK, GET_AI_ROBOT_MUSD_MINED_DATA, GET_AI_ROBOT_STAKING_MINED_DATA, GET_AI_ROBOT_WEEKLY_USER_DETAILS, GET_AI_ROBOT_WEEKLY_WITHDRAW, GET_AI_ROBOT_WEEKLY_WITHDRAW_Trx, GET_CONFIG_DATA, GET_MPSTOKEN_COUNT, GET_MUSD_USERS_BY_PLANID, GET_SELF_ROBOT_USERADDRESS, GET_STAKING_ACTIVE_UPLINE_USER_ADDRESS, GET_STAKING_COUNT, GET_STAKING_DETAILS, GET_STAKING_EARNINGS, GET_STAKING_MULTI_STATUS, GET_STAKING_SELF_ROBAT_DIRECT_PARTNER, GET_STAKING_USERS_BY_PLANID, GET_TOP_INVESTORS, GET_TOTAL_ACTIVE_STAKING, GET_TOTAL_INACTIVE_STAKING, GET_VALID_SELF_ROBAOT_TEAM, GTE_STAKING_PATNERS, POST_AI_ROBOT_TRACK_USER_LIVE_WEEKLY } from "./api.path";

export let getStakingLevel = (level: any, address: string) => {
  const validLevel = level || 1;

  return axiosInstance
    .get(`${GTE_STAKING_PATNERS}${validLevel}&address=${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching staking partners:", error);
      throw error;
    });
};


//   export let post
// user/staking-active-upline?userAddress=${walletAddress1()}&uniqueId=${UnicID()}&planId=$planID'
export let getStakingAciveUser = (address: string, uniqueId: any, planId: any) => {
  return axiosInstance
    .get(`${GET_STAKING_ACTIVE_UPLINE_USER_ADDRESS}${address}&uniqueId=${uniqueId}&planId=${planId}`)
    .then((response) => {
      // console.log(".......wwwww.......",response.data)
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let getStackingUserPLANID = () => {
  return axiosInstance
    .get(`${GET_STAKING_USERS_BY_PLANID}`)
    .then((response) => {

      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let getStackingDetails = (uniqueId: any, address: string) => {
  return axiosInstance
    .get(`${GET_STAKING_DETAILS}${uniqueId}&address=${address}`)
    .then((response) => {
      // console.log(".......wwwww.......",response.data)
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}


export let getStackingInactiveUser = (address: string, page: any) => {
  return axiosInstance
    .get(`${GET_TOTAL_INACTIVE_STAKING}${address}&page=${page}`)
    .then((response) => {
      // console.log(".......wwwww.......",response.data)
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let getStackingActiveUser = (address: string, page: any) => {
  return axiosInstance
    .get(`${GET_TOTAL_ACTIVE_STAKING}${address}&page=${page}`)
    .then((response) => {
      // console.log(".......wwwww.......",response.data)
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let getMultiStutus = (address: string) => {
  return axiosInstance
    .get(`${GET_STAKING_MULTI_STATUS}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let postStackingTransactions = (data: any) => {
  return axios
    .post("https://mining.meta-pro.in/api/stacking/transaction", data, {
      headers: {
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": "true",
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching stacking transaction data:", error);
      throw error;
    });
};

export let postmusdTransactions = (data: any) => {
  return axios
    .post("https://mining.meta-pro.in/api/musd/transaction", data, {
      headers: {
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": "true",
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching stacking transaction data:", error);
      throw error;
    });
};

export let postAiStackingEarning = (data: any) => {
  return axios
    .post("https://mining.meta-pro.in/api/stacking/get/deposites/earnings", data, {
      headers: {
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": "true",
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching stacking earning data:", error);
      throw error;
    });
};

export let postAiStackingWithdraw = (data: any) => {
  return axios
    .post("https://mining.meta-pro.in/api/stacking/withdraw", data, {
      headers: {
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": "true",
      },

    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching stacking earning data:", error);
      throw error;
    });
};

export let getStackingLevelEarning = (address: any) => {
  return axiosInstance
    .get(`${GET_STAKING_EARNINGS}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching stacking earning data:", error);
      throw error;
    });
}

export let getConfigData = () => {
  return axiosInstance
    .get(`${GET_CONFIG_DATA}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let getStakingUserActive = (address: string) => {
  return axiosInstance
    .get(`${GET_ACTIVE_USER_IN_STAKING}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let getStakingCount = (address: string,planId:any) => {
  return axiosInstance
    .get(`${GET_STAKING_COUNT}${address}&planId=${planId}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}


export let getTopInvestors = () => {
  return axiosInstance
    .get(`${GET_TOP_INVESTORS}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let getSelfRobotUserAddress = (address: string) => {
  return axiosInstance
    .get(`${GET_SELF_ROBOT_USERADDRESS}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let getSelfRobotDirectPartner = (address: string) => {
  return axiosInstance
    .get(`${GET_STAKING_SELF_ROBAT_DIRECT_PARTNER}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}

export let getSelfRobotTotalTeam = (address: string,tag:any) => {
  return axiosInstance
    .get(`${GET_VALID_SELF_ROBAOT_TEAM}${address}&tag=${tag}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}


export let getCurrentWeekAchivers = () => {
  return axiosInstance1
    .get(`${GET_AI_ROBOT_GET_CURRENT_WEEK}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}


export let getpreWeekAchivers = () => {
  return axiosInstance1
    .get(`${GET_AI_ROBOT_GET_PRE_WEEK}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}


export  let  postgetpreLiveWeekly = (data: any) => {
  return axiosInstance1
    .post(`${POST_AI_ROBOT_TRACK_USER_LIVE_WEEKLY}`, data, {
      headers: {
        "Content-Type": "application/json",
      },
    })
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching stacking earning data:", error);
      throw error;
    });
};


export  let getAiRobotWeeklyUserDetails = (address: any) => {
  return axiosInstance1
    .get(`${GET_AI_ROBOT_WEEKLY_USER_DETAILS}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}



export let getAiRobotWeeklyWithdraw = (
  address: string,
  privateKey: string,
  uniqueId: string,
  startDate: string,
  endDate: string
) => {
  // console.log("Fetching weekly withdraw for:", address);

  return axiosInstance1
    .post(`${GET_AI_ROBOT_WEEKLY_WITHDRAW}`, {
      userAddress: address,
      privateKey,
      uniqueId,
      startDate,
      endDate,
    })
    .then((response) => {
      return response.data; // expects { success: true, data: [...] }
    })
    .catch((error) => {
      console.error("Error fetching weekly withdraw data:", error);
      throw error;
    });
};


export  let getAiRobotWeeklyWithdrawTrn = (address: any) => {
  return axiosInstance1
    .get(`${GET_AI_ROBOT_WEEKLY_WITHDRAW_Trx}${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });
}



export let getStackingMinedData = (userAddress: any, startTime: any,endTime:any,PlanId:any) => {
  return axiosInstance
    .get(`${GET_AI_ROBOT_STAKING_MINED_DATA}${userAddress}&startTime=${startTime}&endTime=${endTime}&PlanId=${PlanId}`)
    .then((response) => {
      // console.log(".......wwwww.......",response.data)
      return response.data;
    })
    .catch((error) => {
      console.error("Error fetching chart data:", error);
      throw error;
    });

  }


  export let getMusdMinedData = (userAddress: any, startTime: any,endTime:any,PlanId:any) => {
    return axiosInstance
      .get(`${GET_AI_ROBOT_MUSD_MINED_DATA}${userAddress}&startTime=${startTime}&endTime=${endTime}&PlanId=${PlanId}`)
      .then((response) => {
        // console.log(".......wwwww.......",response.data)
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  
    }


  export let postAiMusdEarning = (data: any) => {
    return axios
      .post("https://mining.meta-pro.in/api/musd/get/deposites/earnings", data, {
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true",
        },
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching stacking earning data:", error);
        throw error;
      });
  };
  
  export let postAiMusdWithdraw = (data: any) => {
    return axios
      .post("https://mining.meta-pro.in/api/musd/withdraw", data, {
        headers: {
          "Content-Type": "application/json",
          "ngrok-skip-browser-warning": "true",
        },
  
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching stacking earning data:", error);
        throw error;
      });
  };


  export  let getMiningMusdPkg = (address: any) => {
    return axiosInstance
      .get(`${GET_AI_MINING_MUSD_PKG_S}${address}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  }


  export let getMusdUserPLANID = () => {
    return axiosInstance
      .get(`${GET_MUSD_USERS_BY_PLANID}`)
      .then((response) => {
  
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  }


  export let getMpsTokenCount = (address: string,planId:any) => {
    return axiosInstance
      .get(`${GET_MPSTOKEN_COUNT}${address}&planId=${planId}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching chart data:", error);
        throw error;
      });
  }
  