export let GTE_STAKING_PATNERS='/user/level-staking?level='
export let POST_STAKING_EARNINGS='/api/staking/get/deposites/earnings'
export let GET_STAKING_ACTIVE_UPLINE_USER_ADDRESS='/user/staking-active-upline?userAddress='
export let GET_STAKING_USERS_BY_PLANID='/utility/get-staking-users-by-planId'
export let GET_STAKING_DETAILS='/user/get/user-staking-details?uniqueId='
export let GET_STAKING_TRANSACTION='/api/staking/transaction'
export let GET_TOTAL_ACTIVE_STAKING ="/user/get-active-team-staking?address="
export let GET_TOTAL_INACTIVE_STAKING ="/user/get-inactive-team-staking?address="     
export let GET_STAKING_MULTI_STATUS ="/utility/staking/multi/status?address="  
export let GET_STAKING_EARNINGS="/user/staking/royalty/earnings?address="
export let GET_CONFIG_DATA='/global/config'
export let GET_ACTIVE_USER_IN_STAKING='/user/is-staking-active?address='
export let GET_STAKING_COUNT ='/utility/get_staking_user_count?userAddress='
export let GET_TOP_INVESTORS ='/global/get/top-stack-earners'
export let GET_SELF_ROBOT_USERADDRESS  ='/utility/get/self-robot?userAddress='
export let GET_STAKING_SELF_ROBAT_DIRECT_PARTNER='/utility/get/valid-self-robot-direct-partner?userAddress='
export let GET_VALID_SELF_ROBAOT_TEAM='/utility/get/valid-self-robot-team-member?userAddress='
export let GET_AI_ROBOT_GET_CURRENT_WEEK  ="/ai-robot/get-current-week/achivers-list"
export let GET_AI_ROBOT_GET_PRE_WEEK ="/ai-robot/get-pre-week/achivers-list"
export let POST_AI_ROBOT_TRACK_USER_LIVE_WEEKLY ="/ai-robot/track-user-live-weekly-salary"
export let GET_AI_ROBOT_WEEKLY_USER_DETAILS='/ai-robot/get-weekly-user-details?userAddress='
export let GET_AI_ROBOT_WEEKLY_WITHDRAW_Trx='/ai-robot/get-weekly-withdraw/trx?userAddress='
export let GET_AI_ROBOT_WEEKLY_WITHDRAW='/ai-robot/withdraw-weekly-salary'
export let GET_AI_ROBOT_STAKING_MINED_DATA='/utility/staking-mined-by-trx?userAddress='
export let GET_AI_MINING_MUSD_PKG_S='/user/check-musd-pkg-sequance?userAddress='
export let GET_MUSD_USERS_BY_PLANID='/utility/get-musd-users-by-planId'
export let GET_AI_ROBOT_MUSD_MINED_DATA='/utility/musd-mined-by-trx?userAddress='
export let GET_MPSTOKEN_COUNT ='/utility/get-mpstoken-user-count?userAddress='


// getStackingMinedData