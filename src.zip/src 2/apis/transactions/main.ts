import axiosInstance from "../../utils/axios.instance";
import { GET_2xPOWER_MATRIX_TRANSACTION, GET_LALTEST_TRNSACTION, GET_POWER_GLOBAL_TRANSACTION, GET_POWER_MATRIX_TRANSACTION, GET_X_POWER_GLOBAL_TRANSACTION, GET_X_POWER_MATRIX_TRANSACTION } from "./api.path";

export const getMatrixTransaction = async (address: string,type:any,skip:any) => {
  return axiosInstance
    .get(`${GET_POWER_MATRIX_TRANSACTION}${address}&type=${type}&skip=${skip}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
    });
};

export const getGlobalTransaction = async (address: string,type:any,skip:any) => {
  return axiosInstance
    .get(`${GET_POWER_GLOBAL_TRANSACTION}${address}&type=${type}&skip=${skip}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
    });
};
export const getXPowerGlobalTransaction = async (address: string,type:any,skip:any) => {
  return axiosInstance
    .get(`${GET_X_POWER_GLOBAL_TRANSACTION}${address}&type=${type}&skip=${skip}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
    });
};


export const getXMatrixTransaction = async (address: string,type:any) => {
  return axiosInstance
    .get(`${GET_X_POWER_MATRIX_TRANSACTION}${address}&type=${type}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
    });
};

export let getLatestTransaction = async () => {
  return axiosInstance
    .get(GET_LALTEST_TRNSACTION)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
    });
};


export const get2XPowerGlobalTransaction = async (  uniqueId:any,address: string) => {
  return axiosInstance
    .get(`${GET_2xPOWER_MATRIX_TRANSACTION}${uniqueId}&address=${address}`)
    .then((response) => {
      return response.data;
    })
    .catch((error) => {
      console.error("Erroretching program status:", error);
      throw error;
    });
};

