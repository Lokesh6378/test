export let GET_POWER_MATRIX_TRANSACTION='/user/powermatrix/transaction?address='
export let GET_POWER_GLOBAL_TRANSACTION='/user/powerglobal/transaction?address='
export let GET_X_POWER_GLOBAL_TRANSACTION='/user/x-powerglobal/transaction?address='
export let GET_X_POWER_MATRIX_TRANSACTION='/user/x-powermatrix/transaction?address='
export let GET_LALTEST_TRNSACTION="/utility/get/latest-transaction"

export let GET_2xPOWER_MATRIX_TRANSACTION='/program/pkg/2x-trx?uniqueId='