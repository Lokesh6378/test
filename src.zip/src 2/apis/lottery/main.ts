import { GET_COUNT_IN_LOTTERY_USER, GET_LOTTERT_PARTICIPANTS_LIST, GET_LOTTERY_DATA, GET_LOTTERY_DIRECT_REFERRAL, GET_LOTTERY_RANK_DATA, GET_LOTTERY_RENK_JACKPOUT, GET_LOTTERY_RULE, GET_LOTTERY_TRANSACTION, GET_LOTTERY_WEEKLY_WINNING_AMOUNT, GET_LOTTERY_WITHDRAWAL, GET_MEGA_LOTTERY_DIRECT_REFERRAL, GET_WITHDRAW_WEEKLY_LOTTERY } from "./api.path";
import axiosInstance from "../../utils/axios.instance";
export let  getlotteryData = (address: any) => {
  return axiosInstance
    .get(`${GET_LOTTERY_DATA}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getLotteryRule = (lotteryId: any) => {
  return axiosInstance
    .get(`${GET_LOTTERY_RULE}${lotteryId}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getLotteryUserCount = (address:any,lotteryId: any) => {
  return axiosInstance
    .get(`${GET_COUNT_IN_LOTTERY_USER}${address}&lotteryId=${lotteryId}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getLotteryDirectReferral = (address: any,uniqueId:any,lotteryId: any) => {
  return axiosInstance
    .get(`${GET_LOTTERY_DIRECT_REFERRAL}${address}&uniqueId=${uniqueId}&lotteryId=${lotteryId}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};
export let getMegaLotteryDirectReferral = (address: any,uniqueId:any,lotteryId: any) => {
  return axiosInstance
    .get(`${GET_MEGA_LOTTERY_DIRECT_REFERRAL}${address}&uniqueId=${uniqueId}&lotteryId=${lotteryId}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

// lotteryUserRefsers

export let getlotteryJackport = (lotteryId: any,address: any,) => {
  return axiosInstance
    .get(`${GET_LOTTERY_RENK_JACKPOUT}${lotteryId}&userAddress=${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response?.data?.data?.rank;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};


export let getlotteryParticipantsList = (lotteryID:any) =>{
  return axiosInstance
    .get(`${GET_LOTTERT_PARTICIPANTS_LIST}${lotteryID}`)
    .then((response) => {
      return response?.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
}

export let getLotteryDataRank = (lotteryId: any) => {
  return axiosInstance
    .get(`${GET_LOTTERY_RANK_DATA}${lotteryId}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getWeeklyLotteryWithdraw = (address: any,uniqueId:any,lotteryID:any) => {
  return axiosInstance
    .get(`${GET_WITHDRAW_WEEKLY_LOTTERY}${address}&uniqueId=${uniqueId}&lotteryID=${lotteryID}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};


export let getLotteryTransaction = (address: any,) => {
  return axiosInstance
    .get(`${GET_LOTTERY_TRANSACTION}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};

export let getLotteryWithdrawal = (address: any,) => {
  return axiosInstance
    .get(`${GET_LOTTERY_WITHDRAWAL}${address}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};


export let getWeeklyLotteryWinning = (lotteryID:any,userAddress:any) => {
  return axiosInstance
    .get(`${GET_LOTTERY_WEEKLY_WINNING_AMOUNT}${lotteryID}&userAddress=${userAddress}`)
    .then((response) => {
      // console.log(".......wwwwwwwww.......",response.data)
      return response.data;
    }
    )
    .catch((error) => {
      console.error("Error fetching earnings data:", error);
      throw error;
    });
};


