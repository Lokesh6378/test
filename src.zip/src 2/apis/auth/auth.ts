
import { wagmiAdapter } from "../../lib/Web3Modal";
import axiosInstance from "../../utils/axios.instance";
import { VALIDATE_UNIQUE_ID,IS_USER_REGISTERED,GET_ADDRESS_BY_UNIQUE_ID ,REGISTER_MAINTAIN_MODE,GET_JWT_TOKEN,GLOBAL_MAINTAIN_MODE,GET_USER_DETAILS,SIGN_USER_MESSAGE,GET_VERIFY_JWT_TOKEN, POST_UPDATE_USER_ADDRESS, NEW_IS_USER_REGISTERED} from "./api.path";
import {signMessage } from "wagmi/actions";

export const validateUniqueId = (uniqueId:any) => {

    return axiosInstance.get(VALIDATE_UNIQUE_ID + uniqueId).then((response) => {
        return response.data;
    }).catch((error) => {
        throw error;
    });
}

export const isUserRegistered = (address:any) => {
    return axiosInstance.get(IS_USER_REGISTERED + address).then((response) => {
        return response.data;
    }).catch((error) => {
        throw error;
    });
}


export const getAddressByUniqueId = (uniqueId:any) => {
    return axiosInstance.get(GET_ADDRESS_BY_UNIQUE_ID + uniqueId).then((response) => {
        return response.data;
    }).catch((error) => {
        throw error;
    });
}

export const registerMaintainMode = () => {
    return axiosInstance.get(REGISTER_MAINTAIN_MODE).then((response) => {
        return response.data;
    }).catch((error) => {
        throw error;
    });
}

    export const getUserJwtToken = (address:any,sign:any) => {    
        return axiosInstance.post(GET_JWT_TOKEN, {
            address: address,
            signature: sign
        }).then(async(response) => {
            const data = await response.data;
            localStorage.setItem('jwttoken', data.token);
            localStorage.setItem("walletAddress", address.toLowerCase());
            return data.token;
        }).catch((error) => {
            throw error;
        });
    }

export const getMaintainMode = () => {
    return axiosInstance.get(GLOBAL_MAINTAIN_MODE).then((response) => {
        return response.data;
    }).catch((error) => {
        throw error;
    });
}

export const getUserDetails = (address:any,uniqueId:any) => {
    return axiosInstance.get(GET_USER_DETAILS + address + "&uniqueId=" + uniqueId).then((response) => {
        return response.data;
    }).catch((error) => {
        throw error;
    });
}

// export const signUserMessage =  (address:any) => {
//     return  axiosInstance.get(SIGN_USER_MESSAGE + address).then(async(response) => {
//         const data = response.data;   
//         const message = data.msg;
//         const trx = await signMessage(wagmiAdapter?.wagmiConfig, {
//           message: message,
//           account: address 
//         });
//         return trx;
//     }).catch((error) => {
//         throw error;
//     });
// }

export const signUserMessage = async (address: any) => {
    try {
      if (!address) throw new Error("Wallet not connected");
  
      const response = await axiosInstance.get(SIGN_USER_MESSAGE + address);
      const message = response.data.msg;
  
      const signature = await signMessage(wagmiAdapter?.wagmiConfig, {
        message,
        account: address,
      });
  
      return signature;
    } catch (error) {
      throw error;
    }
  };

export const verifyJwtToken = async (address: string): Promise<boolean> => {
    try {
      const token = localStorage.getItem("jwttoken");
      const storedAddress = localStorage.getItem("walletAddress");
  
      // ❌ no token
      if (!token) return false;
  
      // ❌ address mismatch → force re-login
      if (storedAddress !== address.toLowerCase()) {
        localStorage.removeItem("jwttoken");
        localStorage.removeItem("walletAddress");
        return false;
      }
  
      // ✅ backend verify
      const response = await axiosInstance.get(
        `${GET_VERIFY_JWT_TOKEN}${address}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
  
      return response.status === 200;
    } catch (error: any) {
      // ❌ invalid token → clear
      localStorage.removeItem("jwttoken");
      localStorage.removeItem("walletAddress");
      return false;
    }
  };




export  let  postUserAddressUpdate = (data: any) => {
    return axiosInstance
      .post(`${POST_UPDATE_USER_ADDRESS}`, data, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("Error fetching stacking earning data:", error);
        throw error;
      });
  };
  
  
//   export let getGlobalMaintain = () => {
//     return axiosInstance.get(GLOBAL_MAINTAIN_MODE).then((response) => {
//         return response.data;
//     }).catch((error) => {
//         throw error;
//     });
// }


export const isNewUserRegistered = (address:any) => {
    return axiosInstance.get(NEW_IS_USER_REGISTERED + address).then((response) => {
        return response.data;
    }).catch((error) => {
        throw error;
    });
}




