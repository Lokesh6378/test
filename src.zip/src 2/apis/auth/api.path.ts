export let VALIDATE_UNIQUE_ID = "/utility/uniqueid-to-address?uniqueId=";
export let IS_USER_REGISTERED = "/utility/is-registered?address=";
export let GET_ADDRESS_BY_UNIQUE_ID = "/utility/uniqueid-to-address?uniqueId=";
export let REGISTER_MAINTAIN_MODE='/global/register-maintenance'
export let GLOBAL_MAINTAIN_MODE = "/global/maintain";
export let GET_JWT_TOKEN = "/user/signin";
export let GET_USER_DETAILS = "/user/details?address=";
export let SIGN_USER_MESSAGE= "/user/get/wallet_message?address=";
export let GET_VERIFY_JWT_TOKEN = "/user/verifyJWT?address=";
export let POST_UPDATE_USER_ADDRESS='/admin/update-user-wallet-address'
export let NEW_IS_USER_REGISTERED='/utility/is-new-wallet-registered?address='

