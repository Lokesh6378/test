// export const BNB_CUT_PRESALE = [
//     { min: 0, max: 100, cut: 0.00003, check: 0.00004 },
//     { min: 101, max: 500, cut: 0.0002, check: 0.0003 },
//     { min: 501, max: 1000, cut: 0.0003, check: 0.0004 },
//     { min: 1001, max: 2000, cut: 0.0005, check: 0.0006 },
//     { min: 2001, max: 5000, cut: 0.0008, check: 0.0009 },
//     { min: 5001, max: 10000, cut: 0.0016, check: 0.0017 },
//     { min: 10001, max: Infinity, cut: 0.0032, check: 0.0033 },
//   ];
  
//   export const BNB_CUT_MPS = [
//     { min: 0, max: 50, cut: 0.00001, check: 0.00002 },
//     { min: 51, max: 100, cut: 0.00003, check: 0.00004 },
//     { min: 101, max: 500, cut: 0.0002, check: 0.0003 },
//     { min: 501, max: 1000, cut: 0.0008, check: 0.0009 },
//     { min: 1001, max: 2000, cut: 0.0015, check: 0.0016 },
//     { min: 2001, max: 3000, cut: 0.003, check: 0.0031 },
//     { min: 3001, max: 4000, cut: 0.004, check: 0.0041 },
//     { min: 4001, max: 6000, cut: 0.005, check: 0.0051 },
//     { min: 6001, max: 8000, cut: 0.008, check: 0.0081 },
//     { min: 8001, max: 10000, cut: 0.012, check: 0.0121 },
//     { min: 10001, max: 13000, cut: 0.016, check: 0.0161 },
//     { min: 13001, max: 20000, cut: 0.02, check: 0.0201 },
//     { min: 20001, max: 30000, cut: 0.03, check: 0.0301 },
//     { min: 30001, max: 40000, cut: 0.04, check: 0.0401 },
//     { min: 40001, max: 50000, cut: 0.05, check: 0.0501 },
//     { min: 50001, max: Infinity, cut: 0.08, check: 0.0801 },
//   ];



export const BNB_CUT_PRESALE  = [
    { min: 0, max: 100, cut: 0.00003, check: 0.00004 },
  
    { min: 101, max: 500, cut: 0.0002, check: 0.0003 },
  
    { min: 501, max: 1000, cut: 0.0003, check: 0.0004 },
  
    { min: 1001, max: 2000, cut: 0.0005, check: 0.0006 },
  
    { min: 2001, max: 5000, cut: 0.0008, check: 0.0009 },
  
    { min: 5001, max: 10000, cut: 0.0016, check: 0.0017 },
  
    { min: 10001, max: Infinity, cut: 0.0032, check: 0.0033 },
  ];
  
  
  
  export const BNB_CUT_MPS = [
    { min: 0, max: 50, cut: 0.00001, check: 0.00002 },
  
    { min: 51, max: 100, cut: 0.00003, check: 0.00004 },
  
    { min: 101, max: 500, cut: 0.0002, check: 0.0003 },
  
    { min: 501, max: 1000, cut: 0.0008, check: 0.0009 },
  
    { min: 1001, max: 2000, cut: 0.0015, check: 0.0016 },
  
    { min: 2001, max: 3000, cut: 0.003, check: 0.0031 },
  
    { min: 3001, max: 4000, cut: 0.004, check: 0.0041 },
  
    { min: 4001, max: 6000, cut: 0.005, check: 0.0051 },
  
    { min: 6001, max: 8000, cut: 0.008, check: 0.0081 },
  
    { min: 8001, max: 10000, cut: 0.012, check: 0.0121 },
  
    { min: 10001, max: 13000, cut: 0.016, check: 0.0161 },
  
    { min: 13001, max: 20000, cut: 0.02, check: 0.0201 },
  
    { min: 20001, max: 30000, cut: 0.03, check: 0.0301 },
  
    { min: 30001, max: 40000, cut: 0.04, check: 0.0401 },
  
    { min: 40001, max: 50000, cut: 0.05, check: 0.0501 },
  
    { min: 50001, max: Infinity, cut: 0.08, check: 0.0801 },
  ];
  