export const getBnbCutKey = (
    type: "free" | "presale"
  ) => {
  
    return type === "free"
      ? "mps_free_bnb_cut"
      : "mps_presale_bnb_cut";
  };
  
  export const saveBnbCut = (
    type: "free" | "presale",
    txHash: string
  ) => {
  
    localStorage.setItem(
      getBnbCutKey(type),
      JSON.stringify({
        txHash,
        time: Date.now(),
      })
    );
  };
  
  export const getSavedBnbCut = (
    type: "free" | "presale"
  ) => {
  
    const data = localStorage.getItem(
      getBnbCutKey(type)
    );
  
    if (!data) return null;
  
    return JSON.parse(data);
  };
  
  export const clearBnbCut = (
    type: "free" | "presale"
  ) => {
  
    localStorage.removeItem(
      getBnbCutKey(type)
    );
  };