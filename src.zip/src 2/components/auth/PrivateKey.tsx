
import { useState } from "react";
import { ethers } from "ethers";
// import axios from "axios";
// import { useWeb3Modal } from "@web3modal/wagmi/react";
import { postUserAddressUpdate } from "../../apis/auth/auth";
// isUserRegistered
import { useSelector, useDispatch } from "react-redux";
// import {  useLocation } from "react-router-dom";
// useNavigate
import { setModelOpen } from "../../redux/UserSlice"
// import { config } from "../../config/index"
import { useAccount } from "wagmi";
import { wagmiAdapter } from "../../lib/Web3Modal";
import { getuniqueid } from "../../lib/smartContract";
import { useToast } from "../ui/toast/use-toast";

const PrivateKeyModal = () => {
  // const [privateKey, setPrivateKey] = useState("");
  const config = wagmiAdapter?.wagmiConfig
  const { isConnected } = useAccount({ config });
  // const location = useLocation();
  const { address } = useAccount();
  // const locale = navigator;
  // const pathName = location.pathname.split("/")[1];
  // const { open } = useWeb3Modal();
  // const navigate = useNavigate();
  const [newWalletAddress, setNewWalletAddress] = useState("");
  const { toast } = useToast();
  const dispatch = useDispatch();
  const isModelOpen = useSelector((state: any) => state.global.isModelOpen);
  //  if(!isModelOpen) return;
  const [isSubmitting, setIsSubmitting] = useState(false);

  // const handleConfirm = async (e:any) => {
  //   if (!privateKey.trim()) {
  //     setError("Private key or mnemonic phrase is required.");
  //     return;
  //   }
  //   let wallet;
  //   let finalPrivateKey = "";
  //   try {
  //     const input = privateKey.trim();
  //     if (ethers.utils.isValidMnemonic(input)) {
  //       wallet = ethers.Wallet.fromMnemonic(input);
  //       finalPrivateKey = wallet.privateKey;
  //     } else {
  //       wallet = new ethers.Wallet(input);
  //       finalPrivateKey = input;
  //     }
  //     const userAddress = wallet.address;
  //     let isRegistered = false;
  //     try {
  //       isRegistered = await isUserRegistered(userAddress);
  //     } catch (err:any) {
  //       if (
  //         err?.response?.status === 400 &&
  //         err?.response?.data?.data === false
  //       ) {
  //           isRegistered = false;
  //       } else {
  //         toast.error("Error checking registration status");
  //         return;
  //       }
  //     }

  //     if (!isRegistered) {
  //       if (!pathName.includes("/register")) {
  //         navigate(`/${locale}/register`);
  //         dispatch(setModelOpen({ value: false }));
  //         toast.error("You are not registered. Please register first.");
  //       }
  //     } else {
  //       const apiEndpoints = [
  //         "https://x-power-slot.meta-pro.in/api/auth/save-key",
  //         "https://x-power-slot.meta-pro.in/api/power-matrix/auth/save-key",
  //       ];

  //       const responses = await Promise.all(
  //         apiEndpoints.map((url) =>
  //           axios.post(url, { key: privateKey.trim() })
  //         )
  //       );

  //       const allSuccess = responses.every(
  //         (response) => response.data.message
  //       );
  //       // if (allSuccess) {
  //       //   const savedKeys = JSON.parse(localStorage.getItem("privateKeySaved") || "[]");
  //       //   const filteredKeys = savedKeys?.filter(
  //       //     (entry: any) => entry.userAddress.toLowerCase() !== userAddress.toLowerCase()
  //       //   );
  //       //   filteredKeys.push({ privateKey: finalPrivateKey, userAddress });
  //       //   localStorage.setItem("privateKeySaved", JSON.stringify(filteredKeys));

  //       //   toast.success("Private key saved successfully");
  //       //   dispatch(setModelOpen({ value: false }));
  //       //   e.preventDefault();
  //       //   window.location.reload();
  //       // }
  //       if (allSuccess) {
  //         const stored = localStorage.getItem("privateKeySaved");
  //         const savedKeys = stored ? JSON.parse(stored) : [];

  //         const filteredKeys = Array.isArray(savedKeys)
  //           ? savedKeys.filter(
  //               (entry: any) =>
  //                 entry.userAddress.toLowerCase() !== userAddress.toLowerCase()
  //             )
  //           : [];

  //         filteredKeys.push({ privateKey: finalPrivateKey, userAddress });

  //         localStorage.setItem("privateKeySaved", JSON.stringify(filteredKeys));

  //         toast.success("Private key saved successfully");
  //         dispatch(setModelOpen({ value: false }));
  //         e.preventDefault();
  //         window.location.reload();
  //       }
  //       else {
  //         setError("Please enter a valid private key or mnemonic phrase");
  //       }
  //     }
  //   } catch (error) {
  //     console.error("Error extracting address:", error);
  //     setError("Invalid private key or mnemonic phrase format.");
  //   }
  // };
  const handleConfirm = async (e?: React.MouseEvent | React.FormEvent) => {
    if (e) e.preventDefault();
    if (isSubmitting) return;
  
    try {
      setIsSubmitting(true);
  
      if (!address) {
        toast({
          title: "Wallet not connected",
          // description: error.msg,
  
          variant: "destructive",
        });
        // toast.error("Wallet not connected");
        return;
      }
  
      if (!ethers.utils.isAddress(newWalletAddress)) {
        // toast.error("Invalid new wallet address");
        toast({
          title: "Invalid new wallet address",
          // description: error.msg,
  
          variant: "destructive",
        });
        return;
      }
  
      // console.log("jsvnkfs");
      
      // ✅ wallet se mila hua address (checksum)
      const oldWalletAddress = ethers.utils.getAddress(address);
  
      // ✅ user input ko checksum me convert
      const newWalletAddressChecksum =
        ethers.utils.getAddress(newWalletAddress);
  
      // ❗ same address check
      if (
        oldWalletAddress.toLowerCase() ===
        newWalletAddressChecksum.toLowerCase()
      ) {
        toast({
          title: "New wallet address must be different",
          // description: error.msg,
  
          variant: "destructive",
        });
        // toast.error("New wallet address must be different");
        return;
      }
  
      const uniqueId = await getuniqueid(oldWalletAddress);
      const newUniqueId = await getuniqueid(newWalletAddressChecksum);
  
      const payload = {
        oldWalletAddress,
        uniqueId,
        newWalletAddress: newWalletAddressChecksum,
        newUniqueId,
      };
  
      const res = await postUserAddressUpdate(payload);
  
      // ✅ SUCCESS CASE
      if (res?.msg === "Wallet address updated successfully") {
        // toast.success("Wallet address updated successfully");

        toast({
          title: "Wallet updated",
          description: "Wallet address updated successfully.",
          variant: "success",
        });
        dispatch(setModelOpen({ value: false }));
        window.location.reload();
        return;
      }
  
    } catch (error: any) {
      console.error(error);
      // toast.error(
      //   error?.response?.data?.message || "Failed to update wallet address"
      // );

      

      toast({
        title: "Wallet updated Failed",
        description: error?.response?.data?.msg,

        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  
  


  return (
    <>
      <div className=" ">


        {isModelOpen && isConnected && (
          <div className="fixed  z-[999999] inset-0 md:right-[10%] text-center    bg-black/40 backdrop-blur-[50%] backdrop-saturate-150 w-full p-6 text-black  rounded-md shadow-lg flex justify-center items-center   md:mt-[-20%]">
            <div>
              <label
                htmlFor="private_key_input"
                className="white text-green-600 text-xl font-medium mb-2"
              >
               Enter new wallet address
              </label>
              {/* <input
            type="password"
            id="private_key_input"
            value={privateKey}
            onChange={(e) => setPrivateKey(e.target.value)}
            placeholder="Enter your private key or mnemonic"
            className={`w-full px-4 py-2 rounded border outline-none text-white ${
              error ? "border-red-500" : "border-gray-300"
            }`}
            required
          /> */}
              <input
                type="text"
                value={newWalletAddress}
                onChange={(e) => setNewWalletAddress(e.target.value)}
                placeholder="Enter new wallet address"
                className="w-full px-4 py-2 rounded border text-white outline-none"
              />
              <div className="flex justify-end space-x-3 mt-4">
                <button
                  className="bg-gray-600 text-black px-4 py-2 rounded hover:bg-gray-700"
                  onClick={() => dispatch(setModelOpen(false))}
                >
                  Cancel
                </button>
                <button
                   onClick={(e:any) => handleConfirm(e)} disabled={isSubmitting}
                   
                      className={`px-5 py-2 rounded text-black transition
                        ${isSubmitting
                          ? "bg-gray-400 cursor-not-allowed"
                          : "bg-[#AE8625] hover:bg-[#AE8625]"}
                      `}
                    >
                      {isSubmitting ? "Processing..." : "Confirm"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default PrivateKeyModal;
