// This is the refactored component with Tailwind CSS replacing Bootstrap styles.
// All logic remains unchanged, only classNames and layout structures are adapted.

import { useEffect, useState } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { useAccount } from "wagmi";
import { RegisterUser } from "../../lib/smartContract";
import { waitForTransactionReceipt } from "@wagmi/core";
import { config } from "../../config/index";
import { chainId } from "../../config/data";
// import signUp from "../assets/images/auth/colorful-3d-expanding-ball.gif";
import ConnectButton from "../shared/ConnectButton";
// import "../assets/css/style.css"; /
import { isUserRegistered, validateUniqueId, getAddressByUniqueId, registerMaintainMode, isNewUserRegistered } from "../../apis/auth/auth";
import { register2, robotImage } from "../../assets";
import { useToast } from "../ui/toast/use-toast";
import { useQuery } from "@tanstack/react-query";
import { getConfigData } from "../../apis/AiRobat/main";
function Register() {

  const {
    data: gloabalData,
  } = useQuery({
    queryKey: ["isgloabalData"],
    queryFn: () => getConfigData(),
    staleTime: 1000 * 60 * 2,
    refetchOnWindowFocus: false,
  });

  const id = gloabalData?.data?.new_main_id

  // console.log("gloabalData",gloabalData?.data?.new_main_id);
  // new_main_id
  const [referral, setReferral] = useState(id);
  const [upLine, setUpLine] = useState<any>('');
  const [haveUpline, setHaveUpline] = useState(false);
  const [showNextButton, setShowNextButton] = useState(false);
  const [isMaintainMode, setIsMaintainMode] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [isRegisteredData, setIsRegistereddata] = useState<any>(false);
  const [timerActive, setTimerActive] = useState(false);
  const [remainingTime, setRemainingTime] = useState(0);
  // const [show, setShow] = useState(false);
  // const [haveUpline] = useState(null);
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const { isConnected, address } = useAccount();
  const navigate = useNavigate();
  const location = useLocation();

  const [isRegistering, setIsRegistering] = useState(false);






  const handleValidateUniqueId = async (userRef: any) => {
    try {
      const result = await validateUniqueId(userRef);
      if (result) {
        // toast.success("Upline Found");
        toast({
          title: "Upline Found",
          description: "success",
          variant: "success",
        })
        // console.log("Upline Found", userRef);

        setReferral(userRef);
        setOpen(false);
      }
    } catch (error: any) {
      const errorMessage = error.message;
      toast({
        title: "Invalid referral ID",
        description: errorMessage,
        variant: "destructive",
      })
      // toast.error("Invalid referral ID");
    }
  };


  const handleIsUserRegistered = async (userAddress: any) => {
    try {
      const registered = await isUserRegistered(userAddress);
      const isregistred = await isNewUserRegistered(userAddress);

      setIsRegistereddata(registered);
      if (registered.data === true && isregistred.data) {
        setShowNextButton(true);
        // setIsRegistered(false);

      } else {
        setIsRegistered(true);
      }
    } catch (error: any) {
      if (error.response?.status === 400 && error.response?.data?.data === false) {
        setIsRegistered(true);
        setShowNextButton(false);
      }
    }
  };


  useEffect(() => {
    if (isConnected) handleIsUserRegistered(address);
  }, [isConnected]);

  useEffect(() => {
    (async () => {
      try {
        const isMaintaining = await registerMaintainMode();

        if (isMaintaining) {
          setIsMaintainMode(isMaintaining?.data);
        }
      } catch (error) {
        console.error("Error fetching maintain mode status:", error);
      }
    })();
  }, []);

  // useEffect(() => {
  //   const params = new URLSearchParams(location.search);
  //   const userRef = params.get("ref");
  //   // e.preventDefault();    
  //   if (userRef) {
  //     setHaveUpline(true);
  //     handleValidateUniqueId(userRef)
  //   }
  //   else {
  //     setOpen(true);
  //   }
  // }, [location]);
  // useEffect(() => {
  //   if (address) startCountdown();
  // }, [address]);


  useEffect(() => {
    const run = async () => {
      const params = new URLSearchParams(location.search);
      const userRef = params.get("ref");

      if (!userRef) {
        setOpen(true);
        return;
      }

      try {
        setHaveUpline(true);
        handleValidateUniqueId(userRef)
        // 🔹 uniqueId → address
        const previewAddress = await getAddressByUniqueId(userRef);

        // 🔹 check user status using ADDRESS
        const registered = await isUserRegistered(previewAddress?.data);

        // console.log("registered via ref:", registered);

        // ❌ OLD WALLET MATCHED → NOT AUTHORIZED
        if (registered?.isOldWalletBlocked === true) {
          toast({
            title: "User not authorized",
            description: "This referral cannot be used for registration.",
            variant: "destructive",
          });


          setIsRegistered(false);
          setShowNextButton(false);
          return;
        }

        // ✅ referral valid
        handleValidateUniqueId(userRef);

      } catch (err) {
        console.error("Referral validation failed:", err);
        toast({
          title: "Invalid referral",
          description: "Referral ID is not valid",
          variant: "destructive",
        });
        // setShow(true)
        setOpen(true);
      }
    };

    run();
  }, [location.search]);




  const startCountdown = () => {
    const stored = localStorage.getItem("registerData");
    if (!stored) return;
    const { registerTime, address: storedAddress } = JSON.parse(stored);
    if (storedAddress !== address) return;
    let countdown = Math.max(0, Math.floor((registerTime - Date.now()) / 1000));
    if (countdown > 0) {
      setTimerActive(true);
      setRemainingTime(countdown);
      const interval = setInterval(() => {
        countdown--;
        if (countdown <= 0) {
          clearInterval(interval);
          setTimerActive(false);
          localStorage.removeItem("registerData");
          window.location.reload();
        } else {
          setRemainingTime(countdown);
        }
      }, 1000);
    }
  };

  const registerUserOnSmartContract = async () => {
    try {
      // setIsRegistering(true);
      let refAddress = await getAddressByUniqueId(referral);
      refAddress = refAddress.data;
      const txHash = await RegisterUser(refAddress);
      const receipt = await waitForTransactionReceipt(config, {
        hash: txHash,
        chainId,
      });
      if (receipt.status === "success") {
        setIsRegistering(false);
        localStorage.setItem("registerData", JSON.stringify({ registerTime: Date.now() + 120000, address }));
        startCountdown();
      } else {
        setIsRegistering(false);
        console.log("Transaction failed");
      }
    } catch (err) {
      setIsRegistering(false);
      console.log("Registration failed", err);
    }
  };

  const handleRegister = async (e: any) => {
    e.preventDefault();
    if (timerActive) return;
    setIsRegistering(true);
    try {
      const registered = await isUserRegistered(address);



      if (registered.registered === true) {
        setShowNextButton(true);

        toast({
          title: "You are already registered",
        })
        navigate("/dashboard");
        return;
      }
      else {

        await registerUserOnSmartContract();
      }
    } catch (error: any) {
      if (error.response?.status === 400 && error.response?.status === 304 && error.response?.data?.data === false) {
        await registerUserOnSmartContract();
      }
    }
  };


  // console.log("isRegisteredData",isRegisteredData?.oldWalletMatched);


  if (isMaintainMode) {
    return (
      <div className="flex  h-[100vh]  pt-2 overflow-y-auto flex-col gap-2">
        <div className="text-gray-600 flex flex-col h-full justify-center items-center">
          <img src={robotImage} height={200} width={200} alt="" />
          <h1 className="text-xl md:text-3xl text-white"> We'll be back soon!</h1>
          <p className=" text-xl md:text-2xl font-bold text-center">
            Our Website is currently under maintenance.
          </p>
          <p className="text-xl md:text-2xl font-bold text-center">
            We’re working hard to improve your experience
          </p>
          <p>"Thank you for your patience!</p>
        </div>
      </div>
    );
  }

  const NextStage = () => {
    if (isConnected) navigate("/dashboard");
    else navigate("/");
  };

  return (
    <>
      <div className="w-full flex flex-col md:flex-row ">
        {/* Left Side - Image */}
        <div className="w-full md:w-1/2  md:h-screen hidden md:flex items-center justify-center ">
          <img
            src={register2}
            alt="Login"
            className="object-cover"
          />
        </div>

        {/* Right Side - Login Section */}
        <div className="w-full md:w-1/2 flex  mt-[20%] md:mt-[0] items-center justify-center  px-4 py-10">
          {/* <div className="relative bg-[#191b24] rounded-lg p-6 w-full max-w-sm h-[190px]"> */}
          <div className={`relative bg-transparent border-1 border-gray-600 rounded-lg p-6 w-full max-w-sm ${isConnected ? 'h-[250px]' : 'h-[250px]'} transition-all duration-300`}>

            {/* Login/Register Switch */}
            <div className="absolute inset-x-0 top-[-17px] flex justify-around ">
              <Link
                to="/register"
                className="py-2 px-4 me-2 text-sm font-semibold rounded-md border border-gray-600 bg-yellow-400 text-black"
              >   Register

              </Link>
              <Link
                to="/"
                className="py-2 px-4 text-sm font-semibold bg-black rounded-md border  border-gray-600 text-white hover:bg-yellow-400 hover:text-black"
              >
                Login
              </Link>
            </div>



            <form className="mt-3 space-y-6">
              <div className="space-y-3">
                <label className="block text-white text-sm font-medium">Referral ID
                  <span className="text-xs ps-1 text-gray-400">
                    {referral === "9421052696" ? "(This is Meta Pro Main ID)" : ""}
                  </span>
                </label>
                <div className="relative" >
                  <input
                    type="text"
                    className=" w-full p-2 rounded bg-gray-800 text-[#808080]"
                    placeholder="Referral ID"
                    value={referral}
                    disabled={!!location.search.includes("ref")}
                    required
                  />
                  {/* <button type="button" className=" absolute top-3 right-2 text-[#b5b5b5] underline text-sm" onClick={(e) => {setOpen(true);e.preventDefault();}}>
              
                      <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                          strokeWidth={1.5}
                          stroke="currentColor"
                          className="w-4 h-4"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M16.862 4.487a2.25 2.25 0 113.182 3.182L7.5 20.25H4.5v-3L16.862 4.487z"
                          />
                          </svg>
                      </button> */}
                </div>

                <div className="flex justify-center gap-2 items-center mt-4 text-[#86ff00] ">
                  <div className="" >
                    <ConnectButton variant="address" className="text-black py-1 px-2 rounded bg-[#86ff00] " />
                  </div>
                  {isConnected && <span className="text-black py-1 px-2 rounded bg-[#86ff00]">Connected</span>}
                </div>
                {/* 
                {isRegistered && !isRegisteredData?.registered && !isRegisteredData?.isOldWalletBlocked  && (
                  <div className="flex justify-center items-center" >
                    <button
                      type="submit"
                      className="px-2 py-2 bg-[#86ff00] rounded text-white"
                      onClick={handleRegister}
                      disabled={!isConnected || timerActive}
                    >
                      {timerActive ? `${remainingTime} sec` : "Register"}
                    </button>
                  </div>
                )} */}

                {isRegistered &&
                  !isRegisteredData?.registered &&
                  !isRegisteredData?.isOldWalletBlocked && (
                    <div className="flex justify-center items-center">
                      <button
                        type="submit"
                        className={`px-4 py-2 rounded text-black 
                  ${timerActive || isRegistering
                                      ? "bg-gray-400 cursor-not-allowed"
                                      : "bg-[#86ff00]"
                                    }`}
                        onClick={handleRegister}
                        disabled={!isConnected || timerActive || isRegistering}
                      >
                        {timerActive
                          ? `${remainingTime} sec`
                          : isRegistering
                            ? "Registering..."
                            : "Register"}
                      </button>
                    </div>
                  )}



                {showNextButton && (
                  <div className="flex justify-center mt-[22%] items-center" >
                    <button
                      type="button"
                      onClick={NextStage}
                      className="mt-0 py-2 px-3  bg-[#86ff00] text-black rounded"
                    >
                      Enter
                    </button>
                  </div>
                )}
              </div>
            </form>


            {/* toast({
              title: "Package Purchase Failed",
              description: errorMessage,
              variant: "destructive",
            }); */}




          </div>

          {open && (
            <div className="absolute inset-0 flex items-center justify-center z-50 bg-" >
              <div className="p-6 rounded-lg shadow-lg w-[350px] max-w-md border bg-black backdrop-blur-md ">
                <div className="flex justify-between items-center mb-4">
                  <h5 className="text-white text-lg font-semibold">Register User</h5>
                  <button className="text-black" onClick={() => setOpen(false)}>×</button>
                </div>
                <div>
                  <p className="text-white mb-2">Do you already have Upline?</p>


                  <div className="flex gap-4">
                    <button
                      className="w-1/2 py-2 text-white border-1  border-gray-600 rounded"
                      disabled={haveUpline}
                      onClick={() => {
                        setHaveUpline(true)
                        // if (upLine.length > 5) handleValidateUniqueId(upLine) ;
                      }}
                    >Yes</button>
                    <button
                      className="w-1/2 py-2 bg-transparent text-white border-1  border-gray-600 rounded"
                      onClick={() => {
                        setReferral(id);
                        setOpen(false);
                      }}
                    >No</button>



                  </div>
                  {
                    haveUpline && (
                      <input
                        type="text"
                        className="w-full p-2 mb-4  mt-[5%] rounded border border-[#86ff00] text-white"
                        placeholder="Upline ID"
                        value={upLine}
                        onChange={(e) => setUpLine(e.target.value)}
                      />
                    )
                  }
                </div>
                <div className="mt-4 flex justify-end">
                  <button
                    className="py-2 px-4  bg-[#86ff00] text-black rounded-lg"
                    disabled={upLine.length <= 5}
                    onClick={() => {
                      // if (haveUpline && !tempReferal) return;
                      // setReferral(tempReferal || "9421052696");

                      if (upLine.length > 5) handleValidateUniqueId(upLine)
                    }}
                  >Register</button>
                </div>
              </div>
            </div>
          )}

        </div>

        <div className="w-full md:w-1/1  h-[30vh] flex md:hidden items-center   justify-center ">
          <img
            src={register2}
            alt="Login"
            className="object-cover w-[220px] h-[220px]  rounded-full"
          />
        </div>
      </div>

    </>
  );
}

export default Register;
