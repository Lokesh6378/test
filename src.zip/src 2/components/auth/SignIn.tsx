import { useEffect, useState } from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";

import { useAccount } from "wagmi";
import { loginConcept, robotImage } from "../../assets";

import ConnectButton from "../shared/ConnectButton";
import PrivateKeyModal from "./PrivateKey";
import { wagmiAdapter } from "../../lib/Web3Modal";
import { setModelOpen } from "../../redux/UserSlice";
import { useDispatch } from "react-redux";
import { isUserRegistered } from "../../apis/auth/auth";
// isNewUserRegistered
import { getConfigData } from "../../apis/AiRobat/main";

import { useQuery } from "@tanstack/react-query";


const bypassMaintainModeAddresses = [
  "0xE32A0f9332b903F9B381EFF55bA23Edc15d32184".toLowerCase(),
  "0x69C00Ad7Ad6B17dd78057b4187476Ff2E8696bDf".toLowerCase(),
  "0x91050Ef95935069E9cB6e8D7834B42e0135D5F18".toLowerCase(),
  "0x6CDd0623f096aa4F5Aae3853A1183f3Ce0b7616b".toLowerCase(),
  "0xD3d34bD4F7a72737911A46E050F878F14697E65E".toLowerCase(),
  "0x7b250D249CED0ACc451E359f14c598a9A8fF2479".toLowerCase(),
  "0x999457Be993F884ffbC056313F9A13a5181a5b6c".toLowerCase()
];

export default function Login() {
  const navigate = useNavigate();
  const config = wagmiAdapter.wagmiConfig;
  const { isConnected, address } = useAccount({ config });
  const dispatch = useDispatch();
  // const [privateKeySaved, setPrivateKeySaved] = useState<boolean>(false);
  type UserStatus = {
    registered: boolean;
    walletUpdated: boolean;
    msg?: string;
  };

  const [isRegistered, setIsRegistered] = useState<UserStatus | any>(null);
  const [checkingUser, setCheckingUser] = useState(false);

  const {
    data: gloabalData,
  } = useQuery({
    queryKey: ["isgloabalData"],
    queryFn: () => getConfigData(),
    staleTime: 1000 * 60 * 2,
    refetchOnWindowFocus: false,
  });


  const datashow = gloabalData?.data?.login_next_button_show;

  const isBypassUser =
    address &&
    bypassMaintainModeAddresses.includes(address.toLowerCase());


  const isAllowedUser = datashow || isBypassUser;

  const location = useLocation();
  const pathName = location.pathname.split("/")[1];
  const Nextstage = () => {
    if (isConnected) {
      navigate("/dashboard");
    } else {
      navigate("/");
    }
  };

  function setModel() {
    if (pathName !== "register") {
      dispatch(setModelOpen(true));
    } else {
      <div className=" text-white">
        <appkit-button />
      </div>
    }

  }


  // useEffect(() => {
  //   if (typeof window === "undefined" || !address) return;

  //   const checkUser = async () => {
  //     try {
  //       // const registered = await isUserRegistered(userAddress);
  //       const saved = await isNewUserRegistered(address);
  //       setPrivateKeySaved(saved?.data);
  //     } catch (err) {
  //       console.error("Error checking user:", err);
  //       setPrivateKeySaved(false);
  //     }
  //   };

  //   checkUser();
  // }, [address]);



  useEffect(() => {
    if (!address) return;
    const checkUserStatus = async () => {
      try {
        setCheckingUser(true);
        const res = await isUserRegistered(address);
        // EXPECTING: { registered, walletUpdated, msg }
        setIsRegistered(res);
      } catch (err) {
        console.error(err);
        setIsRegistered(null);
      } finally {
        setCheckingUser(false);
      }
    };
    checkUserStatus();
  }, [address]);

  // newWallet

  //   const isdata =
  //   typeof isRegistered === "boolean"
  //     ? isRegistered
  //     : isRegistered?.data ?? false;
  //       // console.log("isdata",isdata);
  // const user =isdata?.registered

  // console.log("isdata",isRegistered);


  const registered = isRegistered?.registered === true;
  const walletUpdated = isRegistered?.walletUpdated === true;
  const userCanLoginOrNot = isRegistered?.isLoggedIn === true;
  const isOldWalletBlocked = isRegistered?.isOldWalletBlocked



  if (gloabalData?.data?.login_maintenance_mode) {
    return (
      <div className="flex  h-[100vh]  pt-2 overflow-y-auto flex-col gap-2">
        <div className="text-gray-600 flex flex-col h-full justify-center items-center">
          <img src={robotImage} height={200} width={200} alt="" />
          <h1 className="text-xl md:text-3xl text-white"> We'll be back soon!</h1>
          <p className=" text-xl md:text-2xl font-bold text-center">
            Our Website is currently under maintenance.
          </p>
          <p className="text-xl md:text-2xl font-bold text-center">
            We’re working hard to improve your experience
          </p>
          <p>"Thank you for your patience!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full min-h-screen flex flex-col md:flex-row">

      {/* Left Side - Image */}
      <div className="w-full md:w-1/2 h-[50vh] md:h-screen hidden md:flex items-center justify-center">
        <img src={loginConcept} alt="Login" className="object-cover" />
      </div>

      {/* Right Side */}
      <div className="w-full md:w-1/2 flex items-center mt-[30%] md:mt-0 justify-center">
        <div className="items-center rounded-lg p-6 w-full max-w-sm border border-gray-600 bg-transparent h-[220px]">

          {/* Login/Register Switch */}
          <div className="flex justify-around items-center p-2">
            <Link
              to="/"
              className="py-2 px-4 font-bold mt-[-20%] text-sm rounded-md border border-gray-600 bg-orange-400 text-white"
            >
              Login
            </Link>
            <Link
              to="/register"
              className="py-2 px-4 mt-[-20%] text-sm font-semibold rounded-md border border-gray-600 text-white hover:bg-orange-400 hover:text-black"
            >
              Register
            </Link>
          </div>

          {/* Wallet Status */}
          {isConnected ? (
            <div className="flex justify-center mt-6 gap-3">
              <ConnectButton
                variant="address"
                className="px-5 py-2 bg-[#86ff00] rounded text-black"
              />
              <div className="py-2 px-4 bg-[#86ff00] text-sm rounded-md text-black">
                Connected
              </div>
            </div>
          ) : (
            <div className="pt-20 flex justify-center items-center gap-4">
              <ConnectButton
                variant="address"
                className="px-5 py-2 bg-[#d6ffa8] rounded text-black"
              />
            </div>
          )}

          {/* ❌ Connected but NOT registered */}
          {/* {isConnected && !registered && (
            <div className="">
              <div>User not registered. Please register to continue.</div>
              <Link to={`/register`} style={{ color: "#008000", textDecoration: "underline" }}>
                Go to Register
              </Link>
            </div>
          )}   */}

          {isConnected &&
            !checkingUser &&
            isRegistered !== null &&
            isRegistered?.registered === false && (
              <div>
                <div>User not registered. Please register to continue.</div>
                <Link
                  to="/register"
                  style={{ color: "#008000", textDecoration: "underline" }}
                >
                  Go to Register
                </Link>
              </div>
            )}


          {isConnected && isOldWalletBlocked && (
            <div className="mt-6 text-center text-red-500 text-sm">
              Old wallet has been removed. Please login using new wallet
            </div>
          )}



          {/* 🔐 Connected + registered=false + privateKey NOT saved */}
          {isConnected &&
            walletUpdated === false &&
            !userCanLoginOrNot && registered && isAllowedUser && (
              <div className="mt-6 flex justify-center">
                <button
                  onClick={setModel}
                  className="py-2 px-4 bg-[#86ff00] text-black rounded-md"
                >
                  Next
                </button>
              </div>
            )}
          {/* ✅ Connected + private key saved (fallback case) */}
          {isConnected &&
            registered &&
            userCanLoginOrNot &&
            walletUpdated === true &&
            (
              <div className="mt-[15%] flex justify-center">
                <button
                  onClick={Nextstage}
                  className="py-2 px-5 text-sm rounded-md bg-[#86ff00]"
                >
                  {checkingUser ? "Processing..." : "Enter"}
                </button>
              </div>
            )}
        </div>
      </div>

      <PrivateKeyModal />

      {/* Mobile Image */}
      <div className="w-full md:w-1/2  h-[40vh] flex md:hidden items-center justify-center">
        <img src={loginConcept} alt="Login" className="object-cover" />
      </div>

    </div>

  );
}
