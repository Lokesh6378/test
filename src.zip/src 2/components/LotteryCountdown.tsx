import React from "react";
import { useLotteryCountdown } from "../customHooks/useLotteryCountdown";

interface LotteryCountdownProps {
  lotteryID: string;
  lotteryWillCloseAt: string;
}

const Circle = ({ value, max, label }: { value: number; max: number; label: string }) => {
  const radius = 22;
  const circumference = 2 * Math.PI * radius;


  const progress = (value / max) * circumference;


  return (
    <div className="flex flex-col items-center mx-2">
      <svg className="w-15 h-15 ">
        <circle
          cx="32"
          cy="32"
          r={radius}
          
          stroke="#ccc"

          strokeWidth="4"
          fill="none"
          
        />
        <circle
        className="stroke-blue-light-400"
          cx="32"
          cy="32"
          r={radius}
          // stroke="#006525"
          strokeWidth="3"
          // fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={progress-circumference }
          transform="rotate(-90 32 32)" 
     
        />
        <text
          x="32"
          y="38"
          textAnchor="middle"
          fill="#fff"
          fontSize="14"
          fontStyle={"bold"}
          
        >
            {String(value).padStart(2, "0")}
        </text>
      </svg>
      <span className="text-white text-sm mt-1">{label}</span>
    </div>
  );
};

const LotteryCountdown: React.FC<LotteryCountdownProps> = ({
  lotteryWillCloseAt,
  lotteryID
}) => {
  const { data: countDown } = useLotteryCountdown(lotteryID, lotteryWillCloseAt);

  const time = countDown?.[lotteryID];

  if (!time || time === "Closed") {
    return (
      <div className="text-center text-red-500 text-xl font-semibold">
       
      </div>
    );
  }

  const [d, h, m, s] = time.split(" ").map(Number);


  
  return (
    <div className="space-y-4">
      <h1 className="text-blue-light-400 text-3xl text-center  ml-[2%]">Will be completed within:</h1>
      <div className="flex  justify-center  text-3xl mt-3">
        <Circle value={d} max={30} label="Days" />
        <Circle value={h} max={24} label="Hrs" />
        <Circle value={m} max={60} label="Min" />
        <Circle value={s} max={60} label="Sec" />
      </div>
    </div>
  );
};

export default LotteryCountdown;
