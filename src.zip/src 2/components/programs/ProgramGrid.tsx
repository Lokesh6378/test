import ProgramCard from "../../pages/Programs/ProgramsCard";


interface Props {
  programs: any[];
  activeProgram: any;
}

export default function ProgramGrid({
  programs,
  activeProgram,
}: Props) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {programs?.map((program: any, index: number) => (
        <ProgramCard
          key={index}
          status={program.status}
          programName={program.title}
          redirectUrl={`/programs/${program.type}`}
          levelData={{
            count: program.levelCount,
            active: activeProgram?.[program.type] || 0,
          }}
        />
      ))}
    </div>
  );
}