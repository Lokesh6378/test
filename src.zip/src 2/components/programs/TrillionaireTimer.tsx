const unitLabels = {
    days: "Days",
    hours: "Hrs",
    minutes: "Min",
    seconds: "Sec",
  };
  
  interface Props {
    timerText: string;
    timeLeft: any;
  }
  
  export default function TrillionaireTimer({
    timerText,
    timeLeft,
  }: Props) {
    if (!timeLeft) return null;
  
    return (
      <div className="flex flex-col items-center text-center mb-6">
        <p className="text-green-400 text-xl mb-1">{timerText}</p>
  
        <div className="flex gap-2 text-white font-semibold text-md md:text-xl">
          {["days", "hours", "minutes", "seconds"].map((unit) => (
            <div key={unit} className="flex flex-col items-center">
              <span className="border border-green-400 p-2 h-15 w-15 rounded-full flex items-center justify-center">
                {timeLeft[unit]}
              </span>
  
              <span className="text-xs text-green-300">
                {unitLabels[unit as keyof typeof unitLabels]}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  }