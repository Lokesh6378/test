interface Props {
    activePlanTab: "MILLIONAIRE" | "BILLIONAIRE" | "TRILLIONAIRE";
    setActivePlanTab: (
      value: "MILLIONAIRE" | "BILLIONAIRE" | "TRILLIONAIRE"
    ) => void;
  }
  
  export default function ProgramTabs({
    activePlanTab,
    setActivePlanTab,
  }: Props) {
    return (
      <div className="flex justify-around text">
        {["MILLIONAIRE", "BILLIONAIRE", "TRILLIONAIRE"].map((plan) => (
          <button
            key={plan}
            onClick={() => setActivePlanTab(plan as any)}
            className={`px-4 py-2 rounded-full font-semibold border text-[85%] transition-all ${
              activePlanTab === plan
                ? "bg-blue-light-400"
                : "border-blue-light-400 border text-white"
            }`}
          >
            {plan}
          </button>
        ))}
      </div>
    );
  }